package jp.co.oxygen.design.poc.document.library.portlet.filters;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.servlet.BaseFilter;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Component;

@Component(
        immediate = true,
        property = {
                "servlet-filter-name=DeleteCommentsPortletFilters",
                "url-pattern=/view_file/*",
                "dispatcher=REQUEST"
        },
        service = Filter.class
)
public class DeleteCommentsPortletFilters extends BaseFilter {

    @Override
    protected void processFilter(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws IOException, ServletException {

        String uri = request.getRequestURI();

        if (uri != null && uri.contains("/view_file/")) {
            request.setAttribute("disableComments", Boolean.TRUE);
        }

        filterChain.doFilter(request, response);
    }

    @Override
    protected Log getLog() {
        return null;
    }
}