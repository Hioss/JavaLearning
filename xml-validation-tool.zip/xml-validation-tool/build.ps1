# XML 比較ツールをビルドし、成功時に生成 JAR の場所を表示します。
$ErrorActionPreference = "Stop"
mvn clean test package
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Build succeeded: target/xml-validation-tool.jar"
