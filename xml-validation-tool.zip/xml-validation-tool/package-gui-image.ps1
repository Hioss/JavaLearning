# Swing GUI と実行用ランタイムを Windows アプリイメージとしてまとめます。
$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot

mvn clean test package
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$distDir = Join-Path $projectRoot "dist-image"
if (Test-Path $distDir) {
    Remove-Item -LiteralPath $distDir -Recurse -Force
}
New-Item -ItemType Directory -Path $distDir | Out-Null

$jpackageArgs = @(
    "--type", "app-image",
    "--name", "xml-validation-tool",
    "--input", "target",
    "--main-jar", "xml-validation-tool.jar",
    "--main-class", "com.xmltool.validator.gui.XmlValidationSwingApplication",
    "--dest", "dist-image",
    "--java-options", "-Dfile.encoding=UTF-8"
)

& jpackage @jpackageArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "App image created under dist-image"

