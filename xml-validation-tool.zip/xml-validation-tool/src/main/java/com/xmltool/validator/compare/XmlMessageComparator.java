package com.xmltool.validator.compare;

import com.xmltool.validator.config.CompareConfig;
import com.xmltool.validator.model.ComparisonReport;
import com.xmltool.validator.model.DifferenceItem;
import com.xmltool.validator.schema.TypedValueComparator;
import com.xmltool.validator.schema.TypeInference;
import com.xmltool.validator.schema.XsdSupport;
import org.w3c.dom.Node;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.*;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 2 つの XML メッセージを比較し、差分レポートを生成します。
 *
 * <p>XMLUnit を利用してノード比較を行い、設定に応じて空白、コメント、
 * XPath 除外、型推定などを適用します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class XmlMessageComparator {
    /** 比較動作を制御する設定です。 */
    private final CompareConfig config;
    /** XSD 検証と型解決を提供する補助オブジェクトです。 */
    private final XsdSupport xsdSupport;

    /**
     * 比較器を初期化します。
     *
     * @param config 比較設定
     * @param xsdSupport XSD サポート。未使用時は null
     */
    public XmlMessageComparator(CompareConfig config, XsdSupport xsdSupport) {
        this.config = config;
        this.xsdSupport = xsdSupport;
    }

    /**
     * 現行 XML と新版 XML を比較し、差分レポートを返します。
     *
     * @param currentXml 現行 XML
     * @param newXml 新版 XML
     * @return 比較レポート
     */
    public ComparisonReport compare(Path currentXml, Path newXml) {
        DiffBuilder builder = DiffBuilder.compare(currentXml.toFile()).withTest(newXml.toFile())
                .withNodeMatcher(new DefaultNodeMatcher(ElementSelectors.byName))
                .withDifferenceEvaluator(this::evaluateDifference);

        if (config.isCheckForIdentical()) builder.checkForIdentical();
        else builder.checkForSimilar();
        if (config.isIgnoreWhitespace()) builder.ignoreWhitespace();
        if (config.isNormalizeWhitespace()) builder.normalizeWhitespace();
        if (config.isIgnoreComments()) builder.ignoreComments();

        Diff diff = builder.build();
        List<DifferenceItem> items = new ArrayList<>();
        for (Difference difference : diff.getDifferences()) {
            Comparison c = difference.getComparison();
            String currentXPath = c.getControlDetails().getXPath();
            String newXPath = c.getTestDetails().getXPath();
            String currentValue = valueToString(c.getControlDetails().getValue());
            String newValue = valueToString(c.getTestDetails().getValue());
            String type = resolveDataType(currentXPath, newXPath, currentValue, newValue);
            String source = xsdSupport != null && xsdSupport.resolveType(firstNonNull(currentXPath, newXPath)) != null
                    ? "XSD" : "INFERRED";

            items.add(new DifferenceItem(
                    c.getType().name(), currentXPath, newXPath, type, source,
                    currentValue, newValue, describeDifference(c, currentValue, newValue)));
        }

        ComparisonReport report = new ComparisonReport();
        report.setCurrentFile(currentXml.toAbsolutePath().toString());
        report.setNewFile(newXml.toAbsolutePath().toString());
        report.setResult(items.isEmpty() ? "SAME" : "DIFFERENT");
        report.setDifferences(items);
        report.setDifferenceCount(items.size());
        return report;
    }

    /**
     * XMLUnit の差分評価を補正します。
     *
     * @param comparison 比較対象
     * @param outcome XMLUnit が返した比較結果
     * @return 補正後の比較結果
     */
    private ComparisonResult evaluateDifference(Comparison comparison, ComparisonResult outcome) {
        if (outcome == ComparisonResult.EQUAL) return outcome;
        String currentXPath = comparison.getControlDetails().getXPath();
        String newXPath = comparison.getTestDetails().getXPath();
        // 除外対象の XPath は差分があっても同等扱いにします。
        if (matchesIgnored(currentXPath) || matchesIgnored(newXPath)) return ComparisonResult.SIMILAR;

        if (config.isTrimText() && comparison.getType() == ComparisonType.TEXT_VALUE) {
            String a = valueToString(comparison.getControlDetails().getValue());
            String b = valueToString(comparison.getTestDetails().getValue());
            // 前後空白だけが異なる場合は差分として扱いません。
            if (a != null && b != null && a.trim().equals(b.trim())) return ComparisonResult.SIMILAR;

            String type = resolveDataType(currentXPath, newXPath, a, b);
            // 数値や日時は文字列表現ではなく、論理的な同値性で比較します。
            if (TypedValueComparator.areEquivalent(type, a, b)) return ComparisonResult.SIMILAR;
        }
        return outcome;
    }

    /**
     * 指定 XPath が除外設定に一致するか判定します。
     *
     * @param xpath 判定対象 XPath
     * @return 除外対象の場合は true
     */
    private boolean matchesIgnored(String xpath) {
        if (xpath == null) return false;
        for (String pattern : config.getIgnoreXpaths()) {
            if (xpath.equals(pattern) || xpath.matches(pattern)) return true;
        }
        return false;
    }

    /**
     * 比較値をログ・レポート用の文字列へ変換します。
     *
     * @param value 元の値
     * @return 文字列表現
     */
    private static String valueToString(Object value) {
        if (value == null) return null;
        if (value instanceof Node) {
            Node n = (Node) value;
            // テキストノードは値、要素ノードはノード名を採用します。
            return n.getNodeValue() != null ? n.getNodeValue() : n.getNodeName();
        }
        return String.valueOf(value);
    }

    /**
     * 2 値のうち null でない先頭値を返します。
     *
     * @param a 候補 1
     * @param b 候補 2
     * @return null でない値。両方 null の場合は null
     */
    private static String firstNonNull(String a, String b) { return a != null ? a : b; }

    /**
     * 比較対象のデータ型を、XSD の型情報、両方の値からの型推定、
     * 片方の値からの型推定の優先順で解決します。
     *
     * @param currentXPath 現行 XML 側の XPath
     * @param newXPath 新版 XML 側の XPath
     * @param currentValue 現行 XML 側の値
     * @param newValue 新版 XML 側の値
     * @return 比較とレポート表示に使用する型名
     */
    private String resolveDataType(String currentXPath, String newXPath, String currentValue, String newValue) {
        String xsdType = xsdSupport == null ? null : xsdSupport.resolveType(firstNonNull(currentXPath, newXPath));
        if (xsdType != null) return TypedValueComparator.normalizeType(xsdType);
        String inferred = TypedValueComparator.inferComparableType(currentValue, newValue);
        return inferred == null ? TypeInference.infer(firstNonNull(currentValue, newValue)) : inferred;
    }

    /**
     * XMLUnit の差分種別を、利用者が確認しやすい日本語の説明へ変換します。
     *
     * @param comparison XMLUnit の比較情報
     * @param currentValue 現行 XML 側の表示値
     * @param newValue 新版 XML 側の表示値
     * @return レポートへ出力する差分説明
     */
    private String describeDifference(Comparison comparison, String currentValue, String newValue) {
        ComparisonType type = comparison.getType();
        String target = firstNonNull(comparison.getControlDetails().getXPath(), comparison.getTestDetails().getXPath());
        switch (type) {
            case TEXT_VALUE:
                return "テキスト値が異なります。対象: " + nullSafe(target)
                        + "、現行値: " + nullSafe(currentValue)
                        + "、新版値: " + nullSafe(newValue);
            case ATTR_VALUE:
                return "属性値が異なります。対象: " + nullSafe(target)
                        + "、現行値: " + nullSafe(currentValue)
                        + "、新版値: " + nullSafe(newValue);
            case CHILD_NODELIST_LENGTH:
                return "子ノード数が異なります。対象: " + nullSafe(target);
            case CHILD_LOOKUP:
            case CHILD_NODELIST_SEQUENCE:
                return "子要素の構造または順序が異なります。対象: " + nullSafe(target);
            case NODE_TYPE:
                return "ノード種別が異なります。対象: " + nullSafe(target);
            case ELEMENT_TAG_NAME:
                return "要素名が異なります。現行: " + nullSafe(currentValue) + "、新版: " + nullSafe(newValue);
            case ATTR_NAME_LOOKUP:
            case ATTR_VALUE_EXPLICITLY_SPECIFIED:
                return "属性の構成が異なります。対象: " + nullSafe(target);
            default:
                return "差分を検出しました。種別: " + type.name()
                        + "、対象: " + nullSafe(target)
                        + (Objects.equals(currentValue, newValue) ? "" :
                        "、現行値: " + nullSafe(currentValue) + "、新版値: " + nullSafe(newValue));
        }
    }

    private static String nullSafe(String value) {
        return value == null ? "(なし)" : value;
    }
}

