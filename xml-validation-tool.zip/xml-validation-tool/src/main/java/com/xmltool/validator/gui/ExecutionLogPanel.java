package com.xmltool.validator.gui;

import net.miginfocom.swing.MigLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.time.format.DateTimeFormatter;

/**
 * ログレベルに応じて色分けした実行ログを表示するカードです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class ExecutionLogPanel extends RoundedPanel {
    private final JTextPane textPane = new JTextPane();
    private final JButton clearLogButton = new JButton("ログをクリア");
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    public ExecutionLogPanel() {
        super(12, UiConstants.CARD_BACKGROUND, UiConstants.CARD_BORDER);
        setLayout(new BorderLayout());
        setBorder(UiConstants.cardBorder());
        setPreferredSize(new Dimension(0, 610));
        add(createHeader(), BorderLayout.NORTH);
        add(createScrollPane(), BorderLayout.CENTER);
    }

    public JButton getClearLogButton() { return clearLogButton; }

    public void clear() {
        textPane.setText("");
    }

    public void append(LogMessage logMessage) {
        StyledDocument document = textPane.getStyledDocument();
        appendText(document, "[" + logMessage.getTimestamp().format(timeFormatter) + "] ", UiConstants.TIMESTAMP, true);
        appendText(document, logMessage.getMessage() + System.lineSeparator(), resolveColor(logMessage.getLevel()), false);
        textPane.setCaretPosition(document.getLength());
    }

    private JPanel createHeader() {
        JPanel panel = new JPanel(new MigLayout("insets 0, fillx", "[]push[]", "[]"));
        panel.setOpaque(false);
        JLabel title = new JLabel("実行ログ");
        title.setFont(UiConstants.titleFont());
        title.setForeground(UiConstants.PRIMARY);
        clearLogButton.setFont(UiConstants.buttonFont());
        clearLogButton.putClientProperty("JButton.buttonType", "roundRect");
        clearLogButton.setPreferredSize(new Dimension(120, 32));
        clearLogButton.setMinimumSize(new Dimension(120, 32));
        panel.add(title);
        panel.add(clearLogButton, "w 120!, h 32!");
        return panel;
    }

    private JScrollPane createScrollPane() {
        textPane.setEditable(false);
        textPane.setBackground(UiConstants.LOG_BACKGROUND);
        textPane.setForeground(UiConstants.LOG_FOREGROUND);
        textPane.setFont(UiConstants.logFont());
        textPane.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JScrollPane scrollPane = new JScrollPane(textPane);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 0));
        return scrollPane;
    }

    private void appendText(StyledDocument document, String text, Color color, boolean bold) {
        SimpleAttributeSet attr = new SimpleAttributeSet();
        StyleConstants.setForeground(attr, color);
        StyleConstants.setBold(attr, bold);
        StyleConstants.setFontFamily(attr, UiConstants.logFont().getFamily());
        StyleConstants.setFontSize(attr, UiConstants.logFont().getSize());
        try {
            document.insertString(document.getLength(), text, attr);
        } catch (Exception ignored) {
            // ログ描画失敗時は画面継続を優先します。
        }
    }

    private Color resolveColor(LogLevel level) {
        switch (level) {
            case SUCCESS:
                return UiConstants.SUCCESS;
            case WARNING:
                return UiConstants.WARNING;
            case ERROR:
                return UiConstants.ERROR;
            default:
                return UiConstants.LOG_FOREGROUND;
        }
    }
}

