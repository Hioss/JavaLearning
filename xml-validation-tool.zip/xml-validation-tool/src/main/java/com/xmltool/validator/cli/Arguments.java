package com.xmltool.validator.cli;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * コマンドライン引数を保持し、取得するための簡易ラッパーです。
 *
 * <p>{@code --key value} 形式の引数を想定し、必須引数と任意引数の取得を提供します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class Arguments {
    /** 解析済みの引数値です。キーには {@code --} を除いた名称を保持します。 */
    private final Map<String, String> values = new HashMap<>();
    /** ヘルプ表示要求の有無です。 */
    private boolean help;

    /**
     * コマンドライン引数を解析します。
     *
     * @param args 生のコマンドライン引数
     * @return 解析済み引数オブジェクト
     */
    public static Arguments parse(String[] args) {
        Arguments a = new Arguments();
        for (int i = 0; i < args.length; i++) {
            String token = args[i];
            if ("--help".equals(token) || "-h".equals(token)) { a.help = true; continue; }
            // 本ツールはロングオプション形式のみを受け付けます。
            if (!token.startsWith("--")) throw new IllegalArgumentException("不明な引数です: " + token);
            if (i + 1 >= args.length) throw new IllegalArgumentException("引数の値が不足しています: " + token);
            a.values.put(token.substring(2), args[++i]);
        }
        return a;
    }

    /**
     * ヘルプ表示要求の有無を返します。
     *
     * @return ヘルプ表示要求の場合は true
     */
    public boolean isHelp() { return help; }

    /**
     * 必須パス引数を取得します。
     *
     * @param name 引数名
     * @return Path オブジェクト
     */
    public Path requiredPath(String name) {
        String v = values.get(name);
        if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException("必須引数がありません --" + name);
        return Paths.get(v);
    }

    /**
     * 任意パス引数を取得します。
     *
     * @param name 引数名
     * @return 値が未指定の場合は null
     */
    public Path optionalPath(String name) {
        String v = values.get(name);
        return v == null || v.trim().isEmpty() ? null : Paths.get(v);
    }
}

