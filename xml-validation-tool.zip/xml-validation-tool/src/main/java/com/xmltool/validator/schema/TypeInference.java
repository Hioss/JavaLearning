package com.xmltool.validator.schema;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;

/**
 * 文字列値から論理的なデータ型を推定します。
 *
 * <p>真偽値、整数、小数、日付、日時の順に判定し、
 * いずれにも該当しない場合は string を返します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public final class TypeInference {
    private TypeInference() {}

    /**
     * 値文字列からデータ型を推定します。
     *
     * @param value 判定対象文字列
     * @return 推定された型名
     */
    public static String infer(String value) {
        if (value == null) return null;
        String v = value.trim();
        if (v.isEmpty()) return "string";
        if ("true".equalsIgnoreCase(v) || "false".equalsIgnoreCase(v)) return "boolean";
        // 判定順序はより限定的な型から一般的な型へ進めます。
        try { Integer.parseInt(v); return "integer"; } catch (NumberFormatException ignored) {}
        try { new BigDecimal(v); return "decimal"; } catch (NumberFormatException ignored) {}
        try { LocalDate.parse(v); return "date"; } catch (DateTimeParseException ignored) {}
        try { OffsetDateTime.parse(v); return "dateTime"; } catch (DateTimeParseException ignored) {}
        try { LocalDateTime.parse(v); return "dateTime"; } catch (DateTimeParseException ignored) {}
        return "string";
    }
}

