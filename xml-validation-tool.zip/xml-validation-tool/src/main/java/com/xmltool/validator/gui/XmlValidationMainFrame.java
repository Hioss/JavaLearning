package com.xmltool.validator.gui;

import net.miginfocom.swing.MigLayout;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.prefs.Preferences;

/**
 * XML メッセージ検証ツールのメインウィンドウです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class XmlValidationMainFrame extends JFrame {
    private static final String LAST_DIRECTORY_KEY = "lastChooserDirectory";
    private final FileSettingsPanel fileSettingsPanel = new FileSettingsPanel();
    private final ExecutionLogPanel executionLogPanel = new ExecutionLogPanel();
    private final BottomActionPanel bottomActionPanel = new BottomActionPanel();
    private final Preferences preferences = Preferences.userNodeForPackage(XmlValidationMainFrame.class);

    public XmlValidationMainFrame() {
        initializeFrame();
        initializeLayout();
        initializeEvents();
    }

    private void initializeFrame() {
        setTitle("XMLメッセージ検証ツール");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 950));
        // 1920 x 1080 の画面内へ余裕を持って収まる初期サイズにします。
        setSize(1400, 950);
        setLocationRelativeTo(null);
        getRootPane().setDefaultButton(bottomActionPanel.getExecuteButton());
    }

    private void initializeLayout() {
        JPanel root = new JPanel(new BorderLayout(0, 12));
        root.setBackground(UiConstants.APP_BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(16, 16, 12, 16));

        JPanel center = new JPanel(new MigLayout("fill, insets 0, gap 0 12", "[grow]", "[][grow]"));
        center.setOpaque(false);
        center.add(fileSettingsPanel, "growx, wrap");
        center.add(executionLogPanel, "grow");

        root.add(center, BorderLayout.CENTER);
        root.add(bottomActionPanel, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private void initializeEvents() {
        wireBrowse("current");
        wireBrowse("new");
        wireBrowse("xsd");
        wireBrowse("config");
        wireBrowse("json");
        wireBrowse("csv");
        wireBrowse("html");
        wireBrowse("outputDir");

        bottomActionPanel.getExecuteButton().addActionListener(e -> executeComparison());
        bottomActionPanel.getClearButton().addActionListener(e -> clearAll());
        bottomActionPanel.getOpenOutputButton().addActionListener(e -> openOutputLocation());
        bottomActionPanel.getOpenHtmlButton().addActionListener(e -> openHtmlReport());
        bottomActionPanel.getLoadSettingsButton().addActionListener(e -> loadSettingsFile());
        executionLogPanel.getClearLogButton().addActionListener(e -> executionLogPanel.clear());

        bottomActionPanel.getOpenOutputButton().setEnabled(false);
        bottomActionPanel.getOpenHtmlButton().setEnabled(false);
        bottomActionPanel.updateStatus(StatusType.IDLE, "未実行");
    }

    private void wireBrowse(String key) {
        PathInputRow row = fileSettingsPanel.getRow(key);
        row.getBrowseButton().addActionListener(e -> choosePath(row));
        row.getPathField().getDocument().addDocumentListener(SimpleDocumentListener.onChange(this::refreshOutputButtons));
    }

    private void choosePath(PathInputRow row) {
        JFileChooser chooser = new JFileChooser();
        applyLastDirectory(chooser);
        chooser.setFileSelectionMode(resolveSelectionMode(row.getSelectionMode()));
        String currentValue = row.getValue();
        if (currentValue != null && !currentValue.trim().isEmpty()) {
            chooser.setSelectedFile(new File(currentValue.trim()));
        }
        int result = row.getSelectionMode() == PathSelectionMode.SAVE_FILE
                ? chooser.showSaveDialog(this) : chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            rememberDirectory(chooser.getSelectedFile());
            row.setValue(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private int resolveSelectionMode(PathSelectionMode mode) {
        switch (mode) {
            case FILE:
            case SAVE_FILE:
                return JFileChooser.FILES_ONLY;
            case DIRECTORY:
                return JFileChooser.DIRECTORIES_ONLY;
            default:
                return JFileChooser.FILES_AND_DIRECTORIES;
        }
    }

    private void executeComparison() {
        try {
            GuiExecutionOptions options = fileSettingsPanel.collectOptions();
            List<String> errors = validate(options);
            if (!errors.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "入力内容を確認してください。\n\n・" + String.join("\n・", errors),
                        "入力エラー",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            String[] args = GuiArgumentBuilder.build(options);
            executionLogPanel.clear();
            appendLog("実行開始", LogLevel.INFO);
            appendLog("モード：" + resolveModeLabel(options), LogLevel.INFO);
            appendLog("------------------------------------------------------------", LogLevel.INFO);
            setRunning(true);

            SwingExecutionWorker worker = new SwingExecutionWorker(
                    args,
                    executionLogPanel::append,
                    this::handleExecutionFinished);
            worker.execute();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "入力エラー", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void handleExecutionFinished(int exitCode) {
        SwingUtilities.invokeLater(() -> {
            StatusType type = exitCode == 0 ? StatusType.SUCCESS : (exitCode == 1 ? StatusType.DIFFERENT : StatusType.ERROR);
            String message = exitCode == 0 ? "完了（終了コード 0）"
                    : exitCode == 1 ? "完了（終了コード 1）" : "失敗（終了コード " + exitCode + "）";
            bottomActionPanel.updateStatus(type, message);
            appendLog("------------------------------------------------------------", LogLevel.INFO);
            appendLog("実行完了：終了コード " + exitCode, exitCode == 0 ? LogLevel.SUCCESS : LogLevel.ERROR);
            setRunning(false);
            refreshOutputButtons();
        });
    }

    private void setRunning(boolean running) {
        bottomActionPanel.getExecuteButton().setEnabled(!running);
        bottomActionPanel.getExecuteButton().setText(running ? "実行中..." : "実行");
        bottomActionPanel.getClearButton().setEnabled(!running);
        if (running) {
            bottomActionPanel.updateStatus(StatusType.RUNNING, "実行中...");
        }
    }

    private void clearAll() {
        fileSettingsPanel.clear();
        executionLogPanel.clear();
        bottomActionPanel.updateStatus(StatusType.IDLE, "未実行");
        refreshOutputButtons();
    }

    /**
     * 8 行形式の設定読込ファイルを読み込み、各入力欄へ反映します。
     *
     * <p>空行を除いた先頭 8 行を、現行 XML、新版 XML、XSD、比較設定、
     * JSON、CSV、HTML、出力ディレクトリの順で扱います。</p>
     */
    private void loadSettingsFile() {
        JFileChooser chooser = new JFileChooser();
        applyLastDirectory(chooser);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setDialogTitle("設定読込ファイルを選択");
        int result = chooser.showOpenDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) return;

        Path file = chooser.getSelectedFile().toPath();
        rememberDirectory(file.toFile());
        try {
            List<String> lines = Files.readAllLines(file).stream()
                    .map(String::trim)
                    .filter(line -> !line.isEmpty())
                    .collect(Collectors.toList());
            if (lines.size() < 8) {
                JOptionPane.showMessageDialog(this,
                        "設定読込ファイルには 8 行以上のパスが必要です。",
                        "読込エラー",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            GuiExecutionOptions options = new GuiExecutionOptions();
            options.setCurrentPath(lines.get(0));
            options.setNewPath(lines.get(1));
            options.setXsdPath(lines.get(2));
            options.setConfigPath(lines.get(3));
            options.setJsonPath(lines.get(4));
            options.setCsvPath(lines.get(5));
            options.setHtmlPath(lines.get(6));
            options.setOutputDir(lines.get(7));
            fileSettingsPanel.applyOptions(options);
            refreshOutputButtons();
            appendLog("設定ファイルを読み込みました: " + file.toAbsolutePath(), LogLevel.INFO);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "設定読込ファイルを読み込めませんでした。",
                    "読込エラー",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openOutputLocation() {
        Path location = resolveOutputLocation();
        if (location == null) {
            JOptionPane.showMessageDialog(this, "開く出力先が見つかりません。", "情報", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        openPath(location);
    }

    private void openHtmlReport() {
        Path html = resolveHtmlReport();
        if (html == null) {
            JOptionPane.showMessageDialog(this, "HTML レポートが見つかりません。", "情報", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            Desktop.getDesktop().browse(html.toUri());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "HTML レポートを開けませんでした。", "エラー", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openPath(Path path) {
        try {
            Desktop.getDesktop().open(path.toFile());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "出力先を開けませんでした。", "エラー", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshOutputButtons() {
        bottomActionPanel.getOpenOutputButton().setEnabled(resolveOutputLocation() != null);
        bottomActionPanel.getOpenHtmlButton().setEnabled(resolveHtmlReport() != null);
    }

    private Path resolveOutputLocation() {
        GuiExecutionOptions options = fileSettingsPanel.collectOptions();
        if (!isBlank(options.getOutputDir())) {
            Path dir = Path.of(options.getOutputDir().trim());
            return Files.isDirectory(dir) ? dir : null;
        }
        if (!isBlank(options.getHtmlPath())) {
            Path parent = Path.of(options.getHtmlPath().trim()).toAbsolutePath().getParent();
            return parent != null && Files.exists(parent) ? parent : null;
        }
        if (!isBlank(options.getJsonPath())) {
            Path parent = Path.of(options.getJsonPath().trim()).toAbsolutePath().getParent();
            return parent != null && Files.exists(parent) ? parent : null;
        }
        return null;
    }

    private Path resolveHtmlReport() {
        GuiExecutionOptions options = fileSettingsPanel.collectOptions();
        if (!isBlank(options.getHtmlPath())) {
            Path html = Path.of(options.getHtmlPath().trim());
            return Files.isRegularFile(html) ? html : null;
        }
        if (!isBlank(options.getOutputDir())) {
            Path batchHtml = Path.of(options.getOutputDir().trim()).resolve("batch-summary.html");
            return Files.isRegularFile(batchHtml) ? batchHtml : null;
        }
        return null;
    }

    private List<String> validate(GuiExecutionOptions options) {
        List<String> errors = new ArrayList<>();
        if (isBlank(options.getCurrentPath())) errors.add("現行XMLまたはディレクトリが指定されていません。");
        if (isBlank(options.getNewPath())) errors.add("新版XMLまたはディレクトリが指定されていません。");
        validateExisting(errors, options.getCurrentPath(), "現行XMLまたはディレクトリ");
        validateExisting(errors, options.getNewPath(), "新版XMLまたはディレクトリ");
        validateOptionalFile(errors, options.getXsdPath(), "XSDファイル");
        validateOptionalFile(errors, options.getConfigPath(), "設定ファイル");
        return errors;
    }

    private void validateExisting(List<String> errors, String value, String label) {
        if (!isBlank(value) && !Files.exists(Path.of(value.trim()))) {
            errors.add(label + " が存在しません。");
        }
    }

    private void validateOptionalFile(List<String> errors, String value, String label) {
        if (!isBlank(value) && !Files.isRegularFile(Path.of(value.trim()))) {
            errors.add(label + " が存在しません。");
        }
    }

    private void appendLog(String text, LogLevel level) {
        executionLogPanel.append(new LogMessage(LocalTime.now(), text, level));
    }

    private String resolveModeLabel(GuiExecutionOptions options) {
        if (!isBlank(options.getCurrentPath()) && !isBlank(options.getNewPath())) {
            Path current = Path.of(options.getCurrentPath().trim());
            Path newer = Path.of(options.getNewPath().trim());
            if (Files.isDirectory(current) && Files.isDirectory(newer)) {
                return "ディレクトリ一括比較";
            }
        }
        return "単一ファイル比較";
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    /**
     * 前回使用したディレクトリをファイル選択ダイアログへ反映します。
     *
     * @param chooser 対象のファイル選択ダイアログ
     */
    private void applyLastDirectory(JFileChooser chooser) {
        String lastDirectory = preferences.get(LAST_DIRECTORY_KEY, null);
        if (lastDirectory == null || lastDirectory.trim().isEmpty()) return;
        File dir = new File(lastDirectory);
        if (dir.isDirectory()) {
            chooser.setCurrentDirectory(dir);
        }
    }

    /**
     * 選択ファイルの親ディレクトリを次回用に保存します。
     *
     * @param selected 選択されたファイルまたはディレクトリ
     */
    private void rememberDirectory(File selected) {
        if (selected == null) return;
        File dir = selected.isDirectory() ? selected : selected.getParentFile();
        if (dir != null && dir.isDirectory()) {
            preferences.put(LAST_DIRECTORY_KEY, dir.getAbsolutePath());
        }
    }
}

