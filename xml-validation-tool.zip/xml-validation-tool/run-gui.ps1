# Swing GUI 版を直接起動します。
$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot

mvn -q -DskipTests package
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& java -cp target/xml-validation-tool.jar com.xmltool.validator.gui.XmlValidationSwingApplication

