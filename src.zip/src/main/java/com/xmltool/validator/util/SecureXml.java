package com.xmltool.validator.util;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * XML 解析時の安全設定をまとめたユーティリティです。
 *
 * <p>XXE などのリスクを低減するため、DOCTYPE や外部参照を無効化した
 * {@link DocumentBuilderFactory} を生成します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public final class SecureXml {
    private SecureXml() {}

    /**
     * 安全な XML パーサー設定を持つ {@link DocumentBuilderFactory} を生成します。
     *
     * @return セキュア設定済み DocumentBuilderFactory
     */
    public static DocumentBuilderFactory newDocumentBuilderFactory() {
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setNamespaceAware(true);
            f.setXIncludeAware(false);
            f.setExpandEntityReferences(false);
            // 外部エンティティや DOCTYPE を禁止し、外部参照経由の攻撃を防ぎます。
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            f.setFeature("http://xml.org/sax/features/external-general-entities", false);
            f.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            return f;
        } catch (Exception e) {
            throw new IllegalStateException("安全なXMLパーサーを作成できません", e);
        }
    }
}

