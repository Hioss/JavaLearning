package com.xmltool.validator.model;

/**
 * 単一差分の詳細情報を表すモデルです。
 *
 * <p>差分種別、XPath、型、前後値、および説明文を保持します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class DifferenceItem {
    /** XMLUnit が判定した差分種別です。 */
    private String differenceType;
    /** 現行 XML 側の XPath です。 */
    private String currentXPath;
    /** 新版 XML 側の XPath です。 */
    private String newXPath;
    /** 差分値に対応するデータ型です。 */
    private String dataType;
    /** データ型の取得元です。XSD または推定値です。 */
    private String dataTypeSource;
    /** 現行 XML 側の値です。 */
    private String currentValue;
    /** 新版 XML 側の値です。 */
    private String newValue;
    /** 差分内容の説明です。 */
    private String description;

    /** デフォルトコンストラクタです。 */
    public DifferenceItem() {}

    /**
     * 差分詳細を初期化します。
     *
     * @param differenceType 差分種別
     * @param currentXPath 現行 XML 側 XPath
     * @param newXPath 新版 XML 側 XPath
     * @param dataType データ型
     * @param dataTypeSource データ型の取得元
     * @param currentValue 現行 XML 側値
     * @param newValue 新版 XML 側値
     * @param description 差分説明
     */
    public DifferenceItem(String differenceType, String currentXPath, String newXPath,
                          String dataType, String dataTypeSource,
                          String currentValue, String newValue, String description) {
        this.differenceType = differenceType;
        this.currentXPath = currentXPath;
        this.newXPath = newXPath;
        this.dataType = dataType;
        this.dataTypeSource = dataTypeSource;
        this.currentValue = currentValue;
        this.newValue = newValue;
        this.description = description;
    }

    /** @return 差分種別 */
    public String getDifferenceType() { return differenceType; }
    /** @param differenceType 差分種別 */
    public void setDifferenceType(String differenceType) { this.differenceType = differenceType; }
    /** @return 現行 XML 側 XPath */
    public String getCurrentXPath() { return currentXPath; }
    /** @param currentXPath 現行 XML 側 XPath */
    public void setCurrentXPath(String currentXPath) { this.currentXPath = currentXPath; }
    /** @return 新版 XML 側 XPath */
    public String getNewXPath() { return newXPath; }
    /** @param newXPath 新版 XML 側 XPath */
    public void setNewXPath(String newXPath) { this.newXPath = newXPath; }
    /** @return データ型 */
    public String getDataType() { return dataType; }
    /** @param dataType データ型 */
    public void setDataType(String dataType) { this.dataType = dataType; }
    /** @return データ型の取得元 */
    public String getDataTypeSource() { return dataTypeSource; }
    /** @param dataTypeSource データ型の取得元 */
    public void setDataTypeSource(String dataTypeSource) { this.dataTypeSource = dataTypeSource; }
    /** @return 現行 XML 側値 */
    public String getCurrentValue() { return currentValue; }
    /** @param currentValue 現行 XML 側値 */
    public void setCurrentValue(String currentValue) { this.currentValue = currentValue; }
    /** @return 新版 XML 側値 */
    public String getNewValue() { return newValue; }
    /** @param newValue 新版 XML 側値 */
    public void setNewValue(String newValue) { this.newValue = newValue; }
    /** @return 差分説明 */
    public String getDescription() { return description; }
    /** @param description 差分説明 */
    public void setDescription(String description) { this.description = description; }
}

