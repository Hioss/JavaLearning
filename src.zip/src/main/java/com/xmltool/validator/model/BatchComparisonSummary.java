package com.xmltool.validator.model;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * ディレクトリ一括比較の結果全体を保持します。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class BatchComparisonSummary {
    private String generatedAt = OffsetDateTime.now().toString();
    private String currentDirectory;
    private String newDirectory;
    private String xsdFile;
    private int totalFiles;
    private int sameFiles;
    private int differentFiles;
    private List<BatchComparisonEntry> entries = new ArrayList<>();

    public String getGeneratedAt() { return generatedAt; }
    public void setGeneratedAt(String generatedAt) { this.generatedAt = generatedAt; }
    public String getCurrentDirectory() { return currentDirectory; }
    public void setCurrentDirectory(String currentDirectory) { this.currentDirectory = currentDirectory; }
    public String getNewDirectory() { return newDirectory; }
    public void setNewDirectory(String newDirectory) { this.newDirectory = newDirectory; }
    public String getXsdFile() { return xsdFile; }
    public void setXsdFile(String xsdFile) { this.xsdFile = xsdFile; }
    public int getTotalFiles() { return totalFiles; }
    public void setTotalFiles(int totalFiles) { this.totalFiles = totalFiles; }
    public int getSameFiles() { return sameFiles; }
    public void setSameFiles(int sameFiles) { this.sameFiles = sameFiles; }
    public int getDifferentFiles() { return differentFiles; }
    public void setDifferentFiles(int differentFiles) { this.differentFiles = differentFiles; }
    public List<BatchComparisonEntry> getEntries() { return entries; }
    public void setEntries(List<BatchComparisonEntry> entries) { this.entries = entries; }
}

