package com.xmltool.validator.model;

/**
 * バッチ比較における 1 ファイル分の結果要約です。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class BatchComparisonEntry {
    private String relativePath;
    private String result;
    private int differenceCount;
    private String jsonReport;
    private String csvReport;
    private String htmlReport;

    public String getRelativePath() { return relativePath; }
    public void setRelativePath(String relativePath) { this.relativePath = relativePath; }
    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }
    public int getDifferenceCount() { return differenceCount; }
    public void setDifferenceCount(int differenceCount) { this.differenceCount = differenceCount; }
    public String getJsonReport() { return jsonReport; }
    public void setJsonReport(String jsonReport) { this.jsonReport = jsonReport; }
    public String getCsvReport() { return csvReport; }
    public void setCsvReport(String csvReport) { this.csvReport = csvReport; }
    public String getHtmlReport() { return htmlReport; }
    public void setHtmlReport(String htmlReport) { this.htmlReport = htmlReport; }
}

