package com.xmltool.validator.model;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * XML 比較結果全体を表すレポートモデルです。
 *
 * <p>比較結果、対象ファイル、差分件数、警告、差分明細を保持します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class ComparisonReport {
    /** 全体比較結果です。例: SAME / DIFFERENT */
    private String result;
    /** レポート生成日時です。 */
    private String generatedAt = OffsetDateTime.now().toString();
    /** 現行 XML ファイルパスです。 */
    private String currentFile;
    /** 新版 XML ファイルパスです。 */
    private String newFile;
    /** 使用した XSD ファイルパスです。 */
    private String xsdFile;
    /** 差分件数です。 */
    private int differenceCount;
    /** 処理中に発生した警告一覧です。 */
    private List<String> warnings = new ArrayList<>();
    /** 差分明細一覧です。 */
    private List<DifferenceItem> differences = new ArrayList<>();

    /** @return 全体比較結果 */
    public String getResult() { return result; }
    /** @param result 全体比較結果 */
    public void setResult(String result) { this.result = result; }
    /** @return レポート生成日時 */
    public String getGeneratedAt() { return generatedAt; }
    /** @param generatedAt レポート生成日時 */
    public void setGeneratedAt(String generatedAt) { this.generatedAt = generatedAt; }
    /** @return 現行 XML ファイルパス */
    public String getCurrentFile() { return currentFile; }
    /** @param currentFile 現行 XML ファイルパス */
    public void setCurrentFile(String currentFile) { this.currentFile = currentFile; }
    /** @return 新版 XML ファイルパス */
    public String getNewFile() { return newFile; }
    /** @param newFile 新版 XML ファイルパス */
    public void setNewFile(String newFile) { this.newFile = newFile; }
    /** @return XSD ファイルパス */
    public String getXsdFile() { return xsdFile; }
    /** @param xsdFile XSD ファイルパス */
    public void setXsdFile(String xsdFile) { this.xsdFile = xsdFile; }
    /** @return 差分件数 */
    public int getDifferenceCount() { return differenceCount; }
    /** @param differenceCount 差分件数 */
    public void setDifferenceCount(int differenceCount) { this.differenceCount = differenceCount; }
    /** @return 警告一覧 */
    public List<String> getWarnings() { return warnings; }
    /** @param warnings 警告一覧 */
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
    /** @return 差分明細一覧 */
    public List<DifferenceItem> getDifferences() { return differences; }
    /** @param differences 差分明細一覧 */
    public void setDifferences(List<DifferenceItem> differences) { this.differences = differences; }
}

