package com.xmltool.validator.output;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.xmltool.validator.model.BatchComparisonEntry;
import com.xmltool.validator.model.BatchComparisonSummary;
import com.xmltool.validator.model.ComparisonReport;
import com.xmltool.validator.model.DifferenceItem;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 比較レポートを外部ファイルへ出力します。
 *
 * <p>現在は JSON と CSV の 2 形式をサポートします。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public final class ReportWriter {
    private ReportWriter() {}

    /**
     * レポートを JSON 形式で出力します。
     *
     * @param report 比較レポート
     * @param output 出力先
     * @throws IOException 出力に失敗した場合
     */
    public static void writeJson(ComparisonReport report, Path output) throws IOException {
        newMapper().writeValue(output.toFile(), report);
    }

    /**
     * 任意のオブジェクトを JSON 形式で出力します。
     *
     * @param value 出力対象
     * @param output 出力先
     * @throws IOException 出力に失敗した場合
     */
    public static void writeJson(Object value, Path output) throws IOException {
        newMapper().writeValue(output.toFile(), value);
    }

    /**
     * レポートを CSV 形式で出力します。
     *
     * @param report 比較レポート
     * @param output 出力先
     * @throws IOException 出力に失敗した場合
     */
    public static void writeCsv(ComparisonReport report, Path output) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            // Excel 等での文字化け回避のため UTF-8 BOM を付与します。
            w.write('\ufeff');
            w.write("差分種別,現行XPath,新版XPath,データ型,型の取得元,現行値,新版値,差分説明\n");
            for (DifferenceItem d : report.getDifferences()) {
                w.write(csv(d.getDifferenceType()) + ',' + csv(d.getCurrentXPath()) + ',' +
                        csv(d.getNewXPath()) + ',' + csv(d.getDataType()) + ',' +
                        csv(d.getDataTypeSource()) + ',' + csv(d.getCurrentValue()) + ',' +
                        csv(d.getNewValue()) + ',' + csv(d.getDescription()) + "\n");
            }
        }
    }

    /**
     * 単一比較レポートを HTML 形式で出力します。
     *
     * @param report 比較レポート
     * @param output 出力先
     * @throws IOException 出力に失敗した場合
     */
    public static void writeHtml(ComparisonReport report, Path output) throws IOException {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html><html lang=\"ja\"><head><meta charset=\"UTF-8\">")
                .append("<title>XML差分レポート</title>")
                .append(style())
                .append("</head><body>")
                .append("<h1>XML差分レポート</h1>")
                .append("<div class=\"summary\">")
                .append("<p><strong>比較結果:</strong> ").append(escape(displayResult(report.getResult()))).append("</p>")
                .append("<p><strong>差分件数:</strong> ").append(report.getDifferenceCount()).append("</p>")
                .append("<p><strong>現行XML:</strong> ").append(escape(report.getCurrentFile())).append("</p>")
                .append("<p><strong>新版XML:</strong> ").append(escape(report.getNewFile())).append("</p>");
        if (report.getXsdFile() != null) {
            html.append("<p><strong>XSD:</strong> ").append(escape(report.getXsdFile())).append("</p>");
        }
        html.append("</div>");

        html.append("<table><thead><tr>")
                .append("<th class=\"sequence-column\">番号</th>")
                .append("<th>差分種別</th><th>現行XPath</th><th>新版XPath</th><th>データ型</th>")
                .append("<th>型の取得元</th><th>現行値</th><th>新版値</th><th>差分説明</th>")
                .append("</tr></thead><tbody>");
        int sequence = 1;
        for (DifferenceItem item : report.getDifferences()) {
            String rowKey = "row-" + Math.abs((item.getCurrentXPath() + "|" + item.getNewXPath() + "|" + item.getDescription()).hashCode());
            html.append("<tr>")
                    .append("<td class=\"sequence-column\">").append(sequence++).append("</td>")
                    .append(td(item.getDifferenceType()))
                    .append(xpathTd(item.getCurrentXPath(), item.getCurrentValue(), "current", rowKey))
                    .append(xpathTd(item.getNewXPath(), item.getNewValue(), "new", rowKey))
                    .append(td(item.getDataType()))
                    .append(td(item.getDataTypeSource()))
                    .append(td(item.getCurrentValue()))
                    .append(td(item.getNewValue()))
                    .append(td(item.getDescription()))
                    .append("</tr>");
        }
        if (report.getDifferences().isEmpty()) {
            html.append("<tr><td colspan=\"9\">差分はありません。</td></tr>");
        }
        html.append("</tbody></table>")
                .append(script())
                .append("</body></html>");
        Files.writeString(output, html.toString(), StandardCharsets.UTF_8);
    }

    /**
     * バッチ比較結果を CSV 形式で出力します。
     *
     * @param summary バッチ比較要約
     * @param output 出力先
     * @throws IOException 出力に失敗した場合
     */
    public static void writeBatchCsv(BatchComparisonSummary summary, Path output) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            w.write('\ufeff');
            w.write("相対パス,結果,差分件数,JSONレポート,CSVレポート,HTMLレポート\n");
            for (BatchComparisonEntry entry : summary.getEntries()) {
                w.write(csv(entry.getRelativePath()) + ',' + csv(displayResult(entry.getResult())) + ',' +
                        csv(String.valueOf(entry.getDifferenceCount())) + ',' + csv(entry.getJsonReport()) + ',' +
                        csv(entry.getCsvReport()) + ',' + csv(entry.getHtmlReport()) + "\n");
            }
        }
    }

    /**
     * バッチ比較結果を HTML 形式で出力します。
     *
     * @param summary バッチ比較要約
     * @param output 出力先
     * @throws IOException 出力に失敗した場合
     */
    public static void writeBatchHtml(BatchComparisonSummary summary, Path output) throws IOException {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html><html lang=\"ja\"><head><meta charset=\"UTF-8\">")
                .append("<title>バッチ差分レポート</title>")
                .append(style())
                .append("</head><body>")
                .append("<h1>バッチ差分レポート</h1>")
                .append("<div class=\"summary\">")
                .append("<p><strong>対象件数:</strong> ").append(summary.getTotalFiles()).append("</p>")
                .append("<p><strong>一致件数:</strong> ").append(summary.getSameFiles()).append("</p>")
                .append("<p><strong>差分件数:</strong> ").append(summary.getDifferentFiles()).append("</p>")
                .append("<p><strong>現行ディレクトリ:</strong> ").append(escape(summary.getCurrentDirectory())).append("</p>")
                .append("<p><strong>新版ディレクトリ:</strong> ").append(escape(summary.getNewDirectory())).append("</p>")
                .append("</div>")
                .append("<table><thead><tr><th class=\"sequence-column\">番号</th><th>相対パス</th><th>結果</th><th>差分件数</th><th>HTML</th><th>JSON</th><th>CSV</th></tr></thead><tbody>");
        int sequence = 1;
        for (BatchComparisonEntry entry : summary.getEntries()) {
            html.append("<tr>")
                    .append("<td class=\"sequence-column\">").append(sequence++).append("</td>")
                    .append(td(entry.getRelativePath()))
                    .append(td(displayResult(entry.getResult())))
                    .append(td(String.valueOf(entry.getDifferenceCount())))
                    .append("<td><a href=\"").append(escape(entry.getHtmlReport())).append("\">詳細</a></td>")
                    .append("<td><a href=\"").append(escape(entry.getJsonReport())).append("\">JSON</a></td>")
                    .append("<td><a href=\"").append(escape(entry.getCsvReport())).append("\">CSV</a></td>")
                    .append("</tr>");
        }
        html.append("</tbody></table></body></html>");
        Files.writeString(output, html.toString(), StandardCharsets.UTF_8);
    }

    /**
     * 文字列を CSV セルとして安全にエスケープします。
     *
     * @param s 元文字列
     * @return CSV 用に引用符で囲んだ文字列
     */
    private static String csv(String s) {
        if (s == null) return "";
        return '"' + s.replace("\"", "\"\"") + '"';
    }

    private static ObjectMapper newMapper() {
        return new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    }

    private static String td(String value) {
        return "<td>" + escape(value) + "</td>";
    }

    /**
     * 内部結果コードを帳票表示用の日本語へ変換します。
     *
     * @param result 内部結果コード
     * @return 日本語表示
     */
    private static String displayResult(String result) {
        if ("SAME".equals(result)) return "一致";
        if ("DIFFERENT".equals(result)) return "差分あり";
        return result;
    }

    private static String xpathTd(String xpath, String value, String prefix, String groupKey) {
        if (xpath == null || xpath.trim().isEmpty()) {
            return td(xpath);
        }
        String[] segments = xpath.split("/");
        String[] normalized = java.util.Arrays.stream(segments)
                .filter(segment -> segment != null && !segment.isEmpty())
                .toArray(String[]::new);
        if (normalized.length == 0) {
            return td(xpath);
        }

        String id = prefix + "-xpath-" + Math.abs(xpath.hashCode()) + "-" + Math.abs((prefix + xpath).hashCode());
        String accentClass = "current".equals(prefix) ? "xpath-value-current" : "xpath-value-new";
        StringBuilder html = new StringBuilder();
        html.append("<td class=\"xpath-cell\"><div class=\"xpath-viewer\" id=\"").append(id).append("\">")
                .append("<button type=\"button\" class=\"xpath-toggle\" onclick=\"toggleXPathGroup('")
                .append(groupKey)
                .append("', '")
                .append(id)
                .append("')\">")
                .append("<span class=\"xpath-collapsed\">&#9654; ").append(escape(xpath)).append("</span>")
                .append("<span class=\"xpath-expanded\"><span class=\"xpath-branch-toggle\" data-state=\"expanded\" onclick=\"toggleXPathNode(event,this)\">&#9660;</span>")
                .append("<span class=\"xpath-segment\">").append(escape(normalized[0])).append("</span></span>")
                .append("</button>")
                .append("<div class=\"xpath-tree\" data-group=\"").append(groupKey).append("\">");

        for (int i = 1; i < normalized.length - 1; i++) {
            html.append("<div class=\"xpath-node\" style=\"padding-left:")
                    .append(i * 18)
                    .append("px\" data-level=\"")
                    .append(i)
                    .append("\">")
                    .append("<span class=\"xpath-branch-toggle\" data-level=\"")
                    .append(i)
                    .append("\" data-state=\"expanded\" onclick=\"toggleXPathNodeGroup(event,'")
                    .append(groupKey)
                    .append("',")
                    .append(i)
                    .append(")\">&#9660;</span>")
                    .append("<span class=\"xpath-segment\">").append(escape(normalized[i])).append("</span>")
                    .append("</div>");
        }

        int lastIndex = normalized.length - 1;
        html.append("<div class=\"xpath-node xpath-leaf\" style=\"padding-left:")
                .append(lastIndex * 18)
                .append("px\" data-level=\"")
                .append(lastIndex)
                .append("\">")
                .append("<span class=\"xpath-segment\">").append(escape(normalized[lastIndex])).append("</span>");
        if (value != null && !value.isEmpty()) {
            html.append("<span class=\"xpath-value ").append(accentClass).append("\">")
                    .append(escape(value))
                    .append("</span>");
        }
        html.append("</div>");

        html.append("</div></div></td>");
        return html.toString();
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    private static String style() {
        return "<style>" +
                "body{font-family:Segoe UI,Meiryo,sans-serif;margin:24px;color:#1f2937;}" +
                "table{border-collapse:collapse;width:100%;margin-top:16px;}" +
                "th,td{border:1px solid #d1d5db;padding:8px;vertical-align:top;text-align:left;}" +
                "th{background:#f3f4f6;}" +
                ".sequence-column{width:56px;text-align:center;white-space:nowrap;}" +
                ".summary{background:#f9fafb;border:1px solid #e5e7eb;padding:16px;border-radius:8px;}" +
                "a{color:#2563eb;text-decoration:none;}" +
                ".xpath-cell{min-width:260px;}" +
                ".xpath-viewer{font-family:Consolas,'Courier New',monospace;font-size:13px;line-height:1.5;}" +
                ".xpath-toggle{background:none;border:none;padding:0;color:#2563eb;cursor:pointer;font:inherit;text-align:left;}" +
                ".xpath-toggle:hover{text-decoration:underline;}" +
                ".xpath-expanded{display:none;color:#1f2937;}" +
                ".xpath-tree{display:none;margin-top:2px;color:#1f2937;}" +
                ".xpath-node{white-space:nowrap;}" +
                ".xpath-node.is-collapsed + .xpath-node{display:none;}" +
                ".xpath-branch-toggle{display:inline-block;width:12px;color:#1f2937;cursor:pointer;user-select:none;}" +
                ".xpath-segment{color:#1f2937;}" +
                ".xpath-value{margin-left:8px;font-weight:600;}" +
                ".xpath-value-current{color:#2563eb;}" +
                ".xpath-value-new{color:#dc2626;}" +
                ".xpath-leaf .xpath-segment{margin-left:12px;}" +
                ".xpath-viewer.is-expanded .xpath-collapsed{display:none;}" +
                ".xpath-viewer.is-expanded .xpath-expanded{display:inline;}" +
                ".xpath-viewer.is-expanded .xpath-tree{display:block;}" +
                "</style>";
    }

    private static String script() {
        return "<script>" +
                "function toggleXPathGroup(groupKey,id){" +
                "var group=document.querySelectorAll('[data-group=\"'+groupKey+'\"]');" +
                "var root=document.getElementById(id);" +
                "if(!root){return;}" +
                "var expand=!root.classList.contains('is-expanded');" +
                "document.querySelectorAll('.xpath-viewer').forEach(function(viewer){" +
                "if(groupKey===viewer.querySelector('.xpath-tree')?.getAttribute('data-group')){" +
                "viewer.classList.toggle('is-expanded',expand);" +
                "resetXPathNodes(viewer,expand);" +
                "}" +
                "});" +
                "group.forEach(function(tree){" +
                "tree.style.display=expand?'block':'none';" +
                "});" +
                "document.querySelectorAll('.xpath-viewer').forEach(function(viewer){" +
                "var tree=viewer.querySelector('.xpath-tree');" +
                "if(tree&&tree.getAttribute('data-group')===groupKey){" +
                "viewer.classList.toggle('is-expanded',expand);" +
                "}" +
                "});" +
                "}" +
                "function resetXPathNodes(viewer,expand){" +
                "viewer.querySelectorAll('.xpath-branch-toggle').forEach(function(toggle){" +
                "if(toggle.closest('.xpath-toggle')){toggle.innerHTML='&#9660;';toggle.setAttribute('data-state','expanded');return;}" +
                "toggle.innerHTML='&#9660;';toggle.setAttribute('data-state','expanded');" +
                "});" +
                "viewer.querySelectorAll('.xpath-node').forEach(function(node){node.style.display=expand?'block':'none';});" +
                "if(expand){viewer.querySelectorAll('.xpath-node').forEach(function(node){node.style.display='block';});}" +
                "}" +
                "function toggleXPathNodeGroup(event,groupKey,level){" +
                "event.stopPropagation();" +
                "document.querySelectorAll('.xpath-tree[data-group=\"'+groupKey+'\"]').forEach(function(tree){" +
                "toggleXPathNodeWithinTree(tree,level);" +
                "});" +
                "}" +
                "function toggleXPathNodeWithinTree(tree,level){" +
                "var toggle=tree.querySelector('.xpath-branch-toggle[data-level=\"'+level+'\"]');" +
                "var node=tree.querySelector('.xpath-node[data-level=\"'+level+'\"]');" +
                "if(!toggle||!node){return;}" +
                "var nodes=Array.prototype.slice.call(tree.querySelectorAll('.xpath-node'));" +
                "var index=nodes.indexOf(node);" +
                "if(index<0){return;}" +
                "var baseLevel=parseInt(node.getAttribute('data-level'),10);" +
                "var collapse=toggle.getAttribute('data-state')!=='collapsed';" +
                "toggle.setAttribute('data-state',collapse?'collapsed':'expanded');" +
                "toggle.innerHTML=collapse?'&#9654;':'&#9660;';" +
                "for(var i=index+1;i<nodes.length;i++){" +
                "var child=nodes[i];" +
                "var childLevel=parseInt(child.getAttribute('data-level'),10);" +
                "if(childLevel<=baseLevel){break;}" +
                "if(collapse){" +
                "child.style.display='none';" +
                "}else{" +
                "var hiddenByAncestor=false;" +
                "for(var j=baseLevel+1;j<childLevel;j++){" +
                "var ancestorToggle=tree.querySelector('.xpath-branch-toggle[data-level=\"'+j+'\"]');" +
                "if(ancestorToggle&&ancestorToggle.getAttribute('data-state')==='collapsed'){hiddenByAncestor=true;break;}" +
                "}" +
                "child.style.display=hiddenByAncestor?'none':'block';" +
                "}" +
                "}" +
                "}" +
                "</script>";
    }
}

