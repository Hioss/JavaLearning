package com.xmltool.validator.batch;

import com.xmltool.validator.compare.XmlMessageComparator;
import com.xmltool.validator.model.BatchComparisonEntry;
import com.xmltool.validator.model.BatchComparisonSummary;
import com.xmltool.validator.model.ComparisonReport;
import com.xmltool.validator.model.DifferenceItem;
import com.xmltool.validator.output.ReportWriter;
import com.xmltool.validator.schema.XsdSupport;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * ディレクトリ単位の一括 XML 比較を実行します。
 *
 * <p>相対パスで XML ファイルを対応付けし、個別レポートと集約レポートを生成します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class BatchComparisonRunner {
    private final XmlMessageComparator comparator;
    private final XsdSupport xsdSupport;

    public BatchComparisonRunner(XmlMessageComparator comparator, XsdSupport xsdSupport) {
        this.comparator = comparator;
        this.xsdSupport = xsdSupport;
    }

    public BatchComparisonSummary compareDirectories(Path currentDir, Path newDir, Path outputDir) throws Exception {
        Files.createDirectories(outputDir);
        Path reportsDir = outputDir.resolve("files");
        Files.createDirectories(reportsDir);

        Set<String> relativePaths = new TreeSet<>();
        relativePaths.addAll(listRelativeXmlPaths(currentDir));
        relativePaths.addAll(listRelativeXmlPaths(newDir));

        BatchComparisonSummary summary = new BatchComparisonSummary();
        summary.setCurrentDirectory(currentDir.toAbsolutePath().toString());
        summary.setNewDirectory(newDir.toAbsolutePath().toString());
        if (xsdSupport != null) summary.setXsdFile("configured");

        List<BatchComparisonEntry> entries = new ArrayList<>();
        for (String relative : relativePaths) {
            Path currentFile = currentDir.resolve(relative);
            Path newFile = newDir.resolve(relative);
            ComparisonReport report;
            if (Files.isRegularFile(currentFile) && Files.isRegularFile(newFile)) {
                if (xsdSupport != null) {
                    xsdSupport.validate(currentFile);
                    xsdSupport.validate(newFile);
                }
                report = comparator.compare(currentFile, newFile);
                if (xsdSupport != null) report.setXsdFile(summary.getXsdFile());
            } else {
                report = createMissingFileReport(relative, currentFile, newFile);
            }

            Path reportBase = reportsDir.resolve(relative).normalize();
            Path jsonPath = replaceExtension(reportBase, ".json");
            Path csvPath = replaceExtension(reportBase, ".csv");
            Path htmlPath = replaceExtension(reportBase, ".html");
            createParentDirectories(jsonPath, csvPath, htmlPath);

            ReportWriter.writeJson(report, jsonPath);
            ReportWriter.writeCsv(report, csvPath);
            ReportWriter.writeHtml(report, htmlPath);

            BatchComparisonEntry entry = new BatchComparisonEntry();
            entry.setRelativePath(relative.replace('\\', '/'));
            entry.setResult(report.getResult());
            entry.setDifferenceCount(report.getDifferenceCount());
            entry.setJsonReport(outputDir.relativize(jsonPath).toString().replace('\\', '/'));
            entry.setCsvReport(outputDir.relativize(csvPath).toString().replace('\\', '/'));
            entry.setHtmlReport(outputDir.relativize(htmlPath).toString().replace('\\', '/'));
            entries.add(entry);
        }

        int sameCount = (int) entries.stream().filter(e -> "SAME".equals(e.getResult())).count();
        summary.setEntries(entries);
        summary.setTotalFiles(entries.size());
        summary.setSameFiles(sameCount);
        summary.setDifferentFiles(entries.size() - sameCount);

        ReportWriter.writeJson(summary, outputDir.resolve("batch-summary.json"));
        ReportWriter.writeBatchCsv(summary, outputDir.resolve("batch-summary.csv"));
        ReportWriter.writeBatchHtml(summary, outputDir.resolve("batch-summary.html"));
        return summary;
    }

    private static Set<String> listRelativeXmlPaths(Path root) throws IOException {
        try (Stream<Path> stream = Files.walk(root)) {
            return stream
                    .filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().toLowerCase().endsWith(".xml"))
                    .map(root::relativize)
                    .map(Path::toString)
                    .collect(Collectors.toCollection(TreeSet::new));
        }
    }

    private static ComparisonReport createMissingFileReport(String relative, Path currentFile, Path newFile) {
        ComparisonReport report = new ComparisonReport();
        report.setCurrentFile(currentFile.toAbsolutePath().toString());
        report.setNewFile(newFile.toAbsolutePath().toString());
        report.setResult("DIFFERENT");
        report.setDifferenceCount(1);
        List<DifferenceItem> items = new ArrayList<>();
        String message;
        if (!Files.isRegularFile(currentFile) && !Files.isRegularFile(newFile)) {
            message = "両方のディレクトリに対象ファイルが存在しません: " + relative;
        } else if (!Files.isRegularFile(currentFile)) {
            message = "現行ディレクトリにファイルが存在しません: " + relative;
        } else {
            message = "新版ディレクトリにファイルが存在しません: " + relative;
        }
        items.add(new DifferenceItem(
                "FILE_MISSING",
                relative,
                relative,
                "string",
                "INFERRED",
                Files.isRegularFile(currentFile) ? currentFile.toAbsolutePath().toString() : null,
                Files.isRegularFile(newFile) ? newFile.toAbsolutePath().toString() : null,
                message));
        report.setDifferences(items);
        return report;
    }

    private static Path replaceExtension(Path path, String extension) {
        String fileName = path.getFileName().toString();
        int dot = fileName.lastIndexOf('.');
        String baseName = dot >= 0 ? fileName.substring(0, dot) : fileName;
        Path parent = path.getParent();
        return parent == null ? Path.of(baseName + extension) : parent.resolve(baseName + extension);
    }

    private static void createParentDirectories(Path... paths) throws IOException {
        for (Path path : paths) {
            Path parent = path.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
        }
    }
}

