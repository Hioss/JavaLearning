package com.xmltool.validator.gui;

import com.xmltool.validator.XmlValidationApplication;

import javax.swing.SwingWorker;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.function.Consumer;

/**
 * XML 比較処理をバックグラウンドで実行する SwingWorker です。
 *
 * <p>標準出力と標準エラー出力を一時的に捕捉し、ログ表示へ転送します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class SwingExecutionWorker extends SwingWorker<Integer, LogMessage> {
    private final String[] args;
    private final Consumer<Integer> finishedConsumer;
    private final Consumer<LogMessage> logConsumer;

    public SwingExecutionWorker(String[] args, Consumer<LogMessage> logConsumer, Consumer<Integer> finishedConsumer) {
        this.args = args;
        this.finishedConsumer = finishedConsumer;
        this.logConsumer = logConsumer;
        PrintStream logStream = new PrintStream(new LogOutputStream(this::publishLine), true, StandardCharsets.UTF_8);
        this.redirectedOut = logStream;
        this.redirectedErr = logStream;
    }

    private final PrintStream redirectedOut;
    private final PrintStream redirectedErr;

    @Override
    protected Integer doInBackground() {
        PrintStream originalOut = System.out;
        PrintStream originalErr = System.err;
        try {
            System.setOut(redirectedOut);
            System.setErr(redirectedErr);
            return XmlValidationApplication.run(args);
        } finally {
            System.setOut(originalOut);
            System.setErr(originalErr);
            redirectedOut.flush();
            redirectedErr.flush();
        }
    }

    @Override
    protected void process(java.util.List<LogMessage> chunks) {
        chunks.forEach(logConsumer);
    }

    @Override
    protected void done() {
        try {
            finishedConsumer.accept(get());
        } catch (Exception e) {
            finishedConsumer.accept(9);
        }
    }

    /**
     * 標準出力を行単位のログへ変換する出力ストリームです。
     */
    private static class LogOutputStream extends OutputStream {
        private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        private final Consumer<String> lineConsumer;

        LogOutputStream(Consumer<String> lineConsumer) {
            this.lineConsumer = lineConsumer;
        }

        @Override
        public void write(int b) throws IOException {
            buffer.write(b);
            if (b == '\n') {
                flush();
            }
        }

        @Override
        public void flush() {
            if (buffer.size() == 0) return;
            String text = new String(buffer.toByteArray(), StandardCharsets.UTF_8)
                    .replace("\r", "")
                    .trim();
            buffer.reset();
            if (!text.isEmpty()) lineConsumer.accept(text);
        }
    }

    private void publishLine(String line) {
        if (line.startsWith("at ") || line.startsWith("\tat ")) return;
        LogLevel level = resolveLevel(line);
        publish(new LogMessage(LocalTime.now(), line, level));
    }

    private LogLevel resolveLevel(String line) {
        if (line.contains("実行に失敗") || line.contains("エラー") || line.contains("Exception")) return LogLevel.ERROR;
        if (line.contains("DIFFERENT") || line.contains("終了コード 1")) return LogLevel.WARNING;
        if (line.contains("SAME") || line.contains("終了コード 0")) return LogLevel.SUCCESS;
        return LogLevel.INFO;
    }
}

