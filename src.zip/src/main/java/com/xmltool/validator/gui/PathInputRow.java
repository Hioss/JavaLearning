package com.xmltool.validator.gui;

import net.miginfocom.swing.MigLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.TransferHandler;
import java.awt.Dimension;
import java.awt.datatransfer.DataFlavor;
import java.io.File;
import java.util.List;

/**
 * パス入力欄、ラベル、参照ボタンをまとめた 1 行コンポーネントです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class PathInputRow extends JPanel {
    private final JTextField pathField = new JTextField();
    private final JButton browseButton = new JButton("参照");
    private final PathSelectionMode selectionMode;

    public PathInputRow(String title, PathSelectionMode selectionMode) {
        this.selectionMode = selectionMode;
        setOpaque(false);
        // Keep the longest Japanese label visible while giving more horizontal space to the path field.
        setLayout(new MigLayout("insets 0, gapx 12, filly", "[190!] [grow] [110!]", "[40!]"));

        JLabel label = new JLabel(title);
        label.setFont(UiConstants.baseFont().deriveFont(java.awt.Font.BOLD, 14f));
        label.setForeground(UiConstants.TEXT_PRIMARY);

        pathField.setFont(UiConstants.baseFont());
        pathField.putClientProperty("JComponent.roundRect", true);
        pathField.putClientProperty("JTextField.placeholderText", title);
        pathField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UiConstants.INPUT_BORDER),
                BorderFactory.createEmptyBorder(0, 12, 0, 12)));
        pathField.setToolTipText(title);
        pathField.getDocument().addDocumentListener(SimpleDocumentListener.onChange(this::refreshToolTip));
        pathField.setTransferHandler(new FileDropTransferHandler());

        browseButton.setFont(UiConstants.buttonFont());
        browseButton.putClientProperty("JButton.buttonType", "roundRect");
        browseButton.setFocusPainted(false);
        browseButton.setPreferredSize(new Dimension(110, 40));
        browseButton.setToolTipText(title + " を選択します。");

        add(label, "growx");
        add(pathField, "growx");
        add(browseButton, "growx");
    }

    public JTextField getPathField() { return pathField; }
    public JButton getBrowseButton() { return browseButton; }
    public PathSelectionMode getSelectionMode() { return selectionMode; }

    public String getValue() { return pathField.getText(); }
    public void setValue(String value) {
        pathField.setText(value == null ? "" : value);
        refreshToolTip();
    }

    public void clear() {
        setValue("");
    }

    private void refreshToolTip() {
        String value = pathField.getText();
        pathField.setToolTipText(value == null || value.isBlank() ? null : value);
    }

    /**
     * パス入力欄へドラッグ&ドロップされたファイルまたはディレクトリを受け付けます。
     */
    private final class FileDropTransferHandler extends TransferHandler {
        @Override
        public boolean canImport(TransferSupport support) {
            if (!support.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                return false;
            }
            support.setDropAction(COPY);
            return true;
        }

        @Override
        public boolean importData(TransferSupport support) {
            if (!canImport(support)) {
                return false;
            }
            try {
                Object transferData = support.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                if (!(transferData instanceof List<?>)) {
                    return false;
                }
                List<?> files = (List<?>) transferData;
                if (files.isEmpty()) {
                    return false;
                }
                Object first = files.get(0);
                if (!(first instanceof File)) {
                    return false;
                }
                File file = (File) first;
                if (!isAccepted(file)) {
                    return false;
                }
                setValue(file.getAbsolutePath());
                return true;
            } catch (Exception ex) {
                return false;
            }
        }

        /**
         * 入力欄ごとの選択モードに応じて受け入れ可否を判定します。
         *
         * @param file ドロップ対象
         * @return 受け入れ可能な場合は true
         */
        private boolean isAccepted(File file) {
            switch (selectionMode) {
                case FILE:
                case SAVE_FILE:
                    return file.isFile();
                case DIRECTORY:
                    return file.isDirectory();
                case FILE_OR_DIRECTORY:
                    return file.exists();
                default:
                    return false;
            }
        }
    }
}

