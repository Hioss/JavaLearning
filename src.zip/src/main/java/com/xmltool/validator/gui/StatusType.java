package com.xmltool.validator.gui;

/**
 * 画面下部に表示する実行状態です。
 *
 * <p>作成者: ZSJ 程</p>
 */
public enum StatusType {
    IDLE,
    RUNNING,
    SUCCESS,
    DIFFERENT,
    ERROR
}

