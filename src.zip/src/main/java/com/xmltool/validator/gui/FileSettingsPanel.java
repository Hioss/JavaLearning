package com.xmltool.validator.gui;

import net.miginfocom.swing.MigLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * ファイル設定カードです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class FileSettingsPanel extends RoundedPanel {
    private final Map<String, PathInputRow> rows = new LinkedHashMap<>();

    public FileSettingsPanel() {
        super(12, UiConstants.CARD_BACKGROUND, UiConstants.CARD_BORDER);
        setLayout(new BorderLayout());
        setBorder(UiConstants.cardBorder());

        add(createHeader(), BorderLayout.NORTH);
        add(createContent(), BorderLayout.CENTER);
    }

    public PathInputRow getRow(String key) {
        return rows.get(key);
    }

    public GuiExecutionOptions collectOptions() {
        GuiExecutionOptions options = new GuiExecutionOptions();
        options.setCurrentPath(getRow("current").getValue());
        options.setNewPath(getRow("new").getValue());
        options.setXsdPath(getRow("xsd").getValue());
        options.setConfigPath(getRow("config").getValue());
        options.setJsonPath(getRow("json").getValue());
        options.setCsvPath(getRow("csv").getValue());
        options.setHtmlPath(getRow("html").getValue());
        options.setOutputDir(getRow("outputDir").getValue());
        return options;
    }

    /**
     * 読み込んだ設定値を各入力欄へ反映します。
     *
     * @param options 反映対象の設定値
     */
    public void applyOptions(GuiExecutionOptions options) {
        getRow("current").setValue(options.getCurrentPath());
        getRow("new").setValue(options.getNewPath());
        getRow("xsd").setValue(options.getXsdPath());
        getRow("config").setValue(options.getConfigPath());
        getRow("json").setValue(options.getJsonPath());
        getRow("csv").setValue(options.getCsvPath());
        getRow("html").setValue(options.getHtmlPath());
        getRow("outputDir").setValue(options.getOutputDir());
    }

    public void clear() {
        rows.values().forEach(PathInputRow::clear);
    }

    private JPanel createHeader() {
        JPanel panel = new JPanel(new MigLayout("insets 0", "[grow]", "[]"));
        panel.setOpaque(false);
        JLabel title = new JLabel("ファイル設定");
        title.setFont(UiConstants.titleFont());
        title.setForeground(UiConstants.PRIMARY);
        panel.add(title, "growx");
        return panel;
    }

    private JPanel createContent() {
        JPanel panel = new JPanel(new MigLayout("insets 16 0 0 0, gapy 14, fillx", "[grow]", "[][][][][][][][]"));
        panel.setOpaque(false);
        register(panel, "current", "現行XML / ディレクトリ", PathSelectionMode.FILE_OR_DIRECTORY);
        register(panel, "new", "新版XML / ディレクトリ", PathSelectionMode.FILE_OR_DIRECTORY);
        register(panel, "xsd", "XSD", PathSelectionMode.FILE);
        register(panel, "config", "設定ファイル", PathSelectionMode.FILE);
        register(panel, "json", "JSON出力", PathSelectionMode.SAVE_FILE);
        register(panel, "csv", "CSV出力", PathSelectionMode.SAVE_FILE);
        register(panel, "html", "HTML出力", PathSelectionMode.SAVE_FILE);
        register(panel, "outputDir", "出力ディレクトリ", PathSelectionMode.DIRECTORY);
        return panel;
    }

    private void register(JPanel panel, String key, String title, PathSelectionMode mode) {
        PathInputRow row = new PathInputRow(title, mode);
        rows.put(key, row);
        panel.add(row, "growx, wrap");
    }
}

