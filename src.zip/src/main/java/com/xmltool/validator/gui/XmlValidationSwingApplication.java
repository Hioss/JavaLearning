package com.xmltool.validator.gui;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import com.formdev.flatlaf.FlatLightLaf;

/**
 * Swing 版 XML メッセージ検証ツールの起動クラスです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class XmlValidationSwingApplication {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            setLookAndFeel();
            XmlValidationMainFrame frame = new XmlValidationMainFrame();
            frame.setVisible(true);
        });
    }

    private static void setLookAndFeel() {
        try {
            FlatLightLaf.setup();
            UIManager.put("Component.arc", 10);
            UIManager.put("Button.arc", 10);
            UIManager.put("TextComponent.arc", 8);
            UIManager.put("ScrollBar.width", 12);
            UIManager.put("Component.focusWidth", 1);
            UIManager.put("Component.innerFocusWidth", 0);
            UIManager.put("Component.arrowType", "triangle");
            UIManager.put("Button.background", java.awt.Color.WHITE);
            UIManager.put("Button.foreground", UiConstants.TEXT_PRIMARY);
            UIManager.put("TextField.font", UiConstants.baseFont());
            UIManager.put("Label.font", UiConstants.baseFont());
            UIManager.put("Button.font", UiConstants.buttonFont());
        } catch (Exception ignored) {
            // LAF の適用に失敗しても GUI は既定テーマで継続します。
        }
    }
}

