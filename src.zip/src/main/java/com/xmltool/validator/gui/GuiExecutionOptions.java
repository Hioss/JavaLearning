package com.xmltool.validator.gui;

/**
 * Swing 画面で入力された実行オプションを保持します。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class GuiExecutionOptions {
    private String currentPath;
    private String newPath;
    private String xsdPath;
    private String configPath;
    private String jsonPath;
    private String csvPath;
    private String htmlPath;
    private String outputDir;

    public String getCurrentPath() { return currentPath; }
    public void setCurrentPath(String currentPath) { this.currentPath = currentPath; }
    public String getNewPath() { return newPath; }
    public void setNewPath(String newPath) { this.newPath = newPath; }
    public String getXsdPath() { return xsdPath; }
    public void setXsdPath(String xsdPath) { this.xsdPath = xsdPath; }
    public String getConfigPath() { return configPath; }
    public void setConfigPath(String configPath) { this.configPath = configPath; }
    public String getJsonPath() { return jsonPath; }
    public void setJsonPath(String jsonPath) { this.jsonPath = jsonPath; }
    public String getCsvPath() { return csvPath; }
    public void setCsvPath(String csvPath) { this.csvPath = csvPath; }
    public String getHtmlPath() { return htmlPath; }
    public void setHtmlPath(String htmlPath) { this.htmlPath = htmlPath; }
    public String getOutputDir() { return outputDir; }
    public void setOutputDir(String outputDir) { this.outputDir = outputDir; }
}

