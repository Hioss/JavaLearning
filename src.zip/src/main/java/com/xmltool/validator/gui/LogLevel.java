package com.xmltool.validator.gui;

/**
 * ログ表示色を切り替えるためのレベルです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public enum LogLevel {
    INFO,
    SUCCESS,
    WARNING,
    ERROR
}

