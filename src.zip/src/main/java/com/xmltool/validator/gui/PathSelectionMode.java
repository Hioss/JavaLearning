package com.xmltool.validator.gui;

/**
 * 参照ボタンが使用する選択モードです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public enum PathSelectionMode {
    FILE,
    DIRECTORY,
    FILE_OR_DIRECTORY,
    SAVE_FILE
}

