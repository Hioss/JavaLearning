package com.xmltool.validator.gui;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * ラムダ式で利用しやすい DocumentListener の簡易実装です。
 *
 * <p>作成者: ZSJ 程</p>
 */
public interface SimpleDocumentListener extends DocumentListener {
    /**
     * 文書更新時の共通処理です。
     */
    void onUpdate();

    @Override
    default void insertUpdate(DocumentEvent e) { onUpdate(); }

    @Override
    default void removeUpdate(DocumentEvent e) { onUpdate(); }

    @Override
    default void changedUpdate(DocumentEvent e) { onUpdate(); }

    /**
     * Runnable から簡易リスナーを生成します。
     *
     * @param runnable 実行処理
     * @return DocumentListener
     */
    static SimpleDocumentListener onChange(Runnable runnable) {
        return runnable::run;
    }
}

