package com.xmltool.validator.gui;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/**
 * 軽量な角丸カード背景を描画するパネルです。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class RoundedPanel extends JPanel {
    private final int arc;
    private final Color fillColor;
    private final Color borderColor;

    public RoundedPanel(int arc, Color fillColor, Color borderColor) {
        this.arc = arc;
        this.fillColor = fillColor;
        this.borderColor = borderColor;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(fillColor);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
        g2.setColor(borderColor);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
        g2.dispose();
        super.paintComponent(g);
    }
}

