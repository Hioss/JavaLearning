package com.xmltool.validator.gui;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Swing 入力内容をコマンドライン引数配列へ変換します。
 *
 * <p>GUI と CLI の実行形式を揃えるため、最終的に {@code XmlValidationApplication.run(args)}
 * へ渡す引数配列を構築します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public final class GuiArgumentBuilder {
    private GuiArgumentBuilder() {}

    /**
     * 入力値を検証し、CLI と同形式の引数配列を生成します。
     *
     * @param options GUI 入力値
     * @return 実行用引数配列
     */
    public static String[] build(GuiExecutionOptions options) {
        String current = requireValue(options.getCurrentPath(), "現行XMLまたはディレクトリを指定してください。");
        String newer = requireValue(options.getNewPath(), "新版XMLまたはディレクトリを指定してください。");

        Path currentPath = Path.of(current);
        Path newPath = Path.of(newer);
        boolean currentExists = Files.exists(currentPath);
        boolean newExists = Files.exists(newPath);
        if (!currentExists) {
            throw new IllegalArgumentException("現行XMLまたはディレクトリが存在しません。");
        }
        if (!newExists) {
            throw new IllegalArgumentException("新版XMLまたはディレクトリが存在しません。");
        }

        boolean currentDirectory = Files.isDirectory(currentPath);
        boolean newDirectory = Files.isDirectory(newPath);
        if (currentDirectory != newDirectory) {
            throw new IllegalArgumentException("現行と新版は両方ともファイル、または両方ともディレクトリで指定してください。");
        }

        if (!currentDirectory) {
            ensureOptionalFile(options.getXsdPath(), "XSD");
            ensureOptionalFile(options.getConfigPath(), "設定ファイル");
        } else if (!isBlank(options.getOutputDir()) && !isBlank(options.getJsonPath())) {
            throw new IllegalArgumentException("ディレクトリ一括比較では JSON 出力先ではなく出力ディレクトリを指定してください。");
        }

        List<String> args = new ArrayList<>();
        add(args, "--current", current);
        add(args, "--new", newer);
        addOptional(args, "--xsd", options.getXsdPath());
        addOptional(args, "--config", options.getConfigPath());

        if (currentDirectory) {
            addOptional(args, "--outputDir", options.getOutputDir());
        } else {
            addOptional(args, "--json", options.getJsonPath());
            addOptional(args, "--csv", options.getCsvPath());
            addOptional(args, "--html", options.getHtmlPath());
        }
        return args.toArray(new String[0]);
    }

    private static String requireValue(String value, String message) {
        if (isBlank(value)) throw new IllegalArgumentException(message);
        return value.trim();
    }

    private static void ensureOptionalFile(String value, String label) {
        if (isBlank(value)) return;
        if (!Files.isRegularFile(Path.of(value.trim()))) {
            throw new IllegalArgumentException(label + " が存在しないか、読み取れません。");
        }
    }

    private static void add(List<String> args, String key, String value) {
        args.add(key);
        args.add(value);
    }

    private static void addOptional(List<String> args, String key, String value) {
        if (isBlank(value)) return;
        add(args, key, value.trim());
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}

