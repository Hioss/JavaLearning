package com.xmltool.validator.gui;

import net.miginfocom.swing.MigLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;

/**
 * 画面下部の状態表示と操作ボタンをまとめます。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class BottomActionPanel extends JPanel {
    private final JLabel statusLabel = new JLabel("ステータス：未実行");
    private final JButton openOutputButton = new JButton("出力先を開く");
    private final JButton openHtmlButton = new JButton("HTMLレポートを開く");
    private final JButton loadSettingsButton = new JButton("設定読込");
    private final JButton clearButton = new JButton("クリア");
    private final JButton executeButton = new JButton("実行");

    public BottomActionPanel() {
        setOpaque(false);
        setLayout(new BorderLayout());

        JPanel left = new JPanel(new MigLayout("insets 0, fillx", "[260!, grow]", "[]"));
        left.setOpaque(false);
        statusLabel.setFont(UiConstants.baseFont());
        statusLabel.setForeground(UiConstants.TEXT_PRIMARY);
        left.add(statusLabel, "growx");

        JPanel right = new JPanel(new MigLayout("insets 0, gapx 8", "[][][][][]", "40!"));
        right.setOpaque(false);
        configureSecondaryButton(openOutputButton);
        configureSecondaryButton(openHtmlButton);
        configureSecondaryButton(loadSettingsButton);
        configureSecondaryButton(clearButton);
        executeButton.setFont(UiConstants.buttonFont().deriveFont(java.awt.Font.BOLD));
        executeButton.putClientProperty("JButton.buttonType", "roundRect");
        executeButton.putClientProperty("JButton.background", UiConstants.PRIMARY);
        executeButton.putClientProperty("JButton.foreground", java.awt.Color.WHITE);
        right.add(openOutputButton, "w 160!");
        right.add(openHtmlButton, "w 180!");
        right.add(loadSettingsButton, "w 120!");
        right.add(clearButton, "w 110!");
        right.add(executeButton, "w 120!");

        add(left, BorderLayout.WEST);
        add(right, BorderLayout.EAST);
    }

    public JButton getOpenOutputButton() { return openOutputButton; }
    public JButton getOpenHtmlButton() { return openHtmlButton; }
    public JButton getLoadSettingsButton() { return loadSettingsButton; }
    public JButton getClearButton() { return clearButton; }
    public JButton getExecuteButton() { return executeButton; }

    public void updateStatus(StatusType type, String message) {
        statusLabel.setText("ステータス：" + message);
        switch (type) {
            case SUCCESS:
                statusLabel.setForeground(UiConstants.SUCCESS);
                break;
            case DIFFERENT:
                statusLabel.setForeground(UiConstants.WARNING);
                break;
            case ERROR:
                statusLabel.setForeground(UiConstants.ERROR);
                break;
            case RUNNING:
                statusLabel.setForeground(UiConstants.PRIMARY);
                break;
            default:
                statusLabel.setForeground(UiConstants.TEXT_PRIMARY);
        }
    }

    private void configureSecondaryButton(JButton button) {
        button.setFont(UiConstants.buttonFont());
        button.putClientProperty("JButton.buttonType", "roundRect");
    }
}

