package com.xmltool.validator.gui;

import java.time.LocalTime;

/**
 * 画面へ表示する 1 行分のログ情報です。
 *
 * <p>作成者: ZSJ 程</p>
 */
public class LogMessage {
    private final LocalTime timestamp;
    private final String message;
    private final LogLevel level;

    public LogMessage(LocalTime timestamp, String message, LogLevel level) {
        this.timestamp = timestamp;
        this.message = message;
        this.level = level;
    }

    public LocalTime getTimestamp() { return timestamp; }
    public String getMessage() { return message; }
    public LogLevel getLevel() { return level; }
}

