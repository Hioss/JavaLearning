package com.xmltool.validator.gui;

import javax.swing.BorderFactory;
import javax.swing.UIManager;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Font;

/**
 * Swing 画面で共通利用する色、フォント、余白定義をまとめます。
 *
 * <p>作成者: ZSJ 程</p>
 */
public final class UiConstants {
    public static final Color APP_BACKGROUND = Color.decode("#F5F8FC");
    public static final Color CARD_BACKGROUND = Color.WHITE;
    public static final Color CARD_BORDER = Color.decode("#D8E2F0");
    public static final Color PRIMARY = Color.decode("#2563EB");
    public static final Color PRIMARY_HOVER = Color.decode("#1D4ED8");
    public static final Color TEXT_PRIMARY = Color.decode("#1F2937");
    public static final Color TEXT_SECONDARY = Color.decode("#64748B");
    public static final Color INPUT_BORDER = Color.decode("#CBD5E1");
    public static final Color SUCCESS = Color.decode("#16A34A");
    public static final Color WARNING = Color.decode("#D97706");
    public static final Color ERROR = Color.decode("#DC2626");
    public static final Color LOG_BACKGROUND = Color.decode("#1F2937");
    public static final Color LOG_FOREGROUND = Color.decode("#E5E7EB");
    public static final Color TIMESTAMP = Color.decode("#94A3B8");
    public static final Color ICON_XML = Color.decode("#E0F2FE");
    public static final Color ICON_XSD = Color.decode("#EDE9FE");
    public static final Color ICON_CONFIG = Color.decode("#FFEDD5");
    public static final Color ICON_JSON = Color.decode("#FEE2E2");
    public static final Color ICON_CSV = Color.decode("#DCFCE7");
    public static final Color ICON_HTML = Color.decode("#DBEAFE");
    public static final Color ICON_OUTPUT = Color.decode("#E0E7FF");

    private UiConstants() {}

    /**
     * 通常フォントを返します。
     *
     * @return 標準フォント
     */
    public static Font baseFont() {
        return preferredFont(Font.PLAIN, 14f);
    }

    /**
     * タイトル用フォントを返します。
     *
     * @return 太字フォント
     */
    public static Font titleFont() {
        return preferredFont(Font.BOLD, 16f);
    }

    /**
     * ボタン用フォントを返します。
     *
     * @return ボタンフォント
     */
    public static Font buttonFont() {
        return preferredFont(Font.PLAIN, 14f);
    }

    /**
     * 等幅ログフォントを返します。
     *
     * @return ログ用フォント
     */
    public static Font logFont() {
        return new Font(Font.MONOSPACED, Font.PLAIN, 13);
    }

    /**
     * カード外枠を返します。
     *
     * @return カード境界線
     */
    public static Border cardBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CARD_BORDER),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
        );
    }

    private static Font preferredFont(int style, float size) {
        Font ui = new Font("Yu Gothic UI", style, Math.round(size));
        if ("Dialog".equalsIgnoreCase(ui.getFamily())) {
            ui = new Font("Meiryo", style, Math.round(size));
        }
        if ("Dialog".equalsIgnoreCase(ui.getFamily())) {
            Font fallback = UIManager.getFont("Label.font");
            return fallback == null ? new Font(Font.SANS_SERIF, style, Math.round(size))
                    : fallback.deriveFont(style, size);
        }
        return ui;
    }
}

