package com.xmltool.validator.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * 比較設定ファイルを読み込み、{@link CompareConfig} を生成します。
 *
 * <p>作成者: ZSJ 程</p>
 */
public final class CompareConfigLoader {
    private CompareConfigLoader() {}

    /**
     * 設定ファイルを読み込みます。
     *
     * @param path properties ファイルパス。null の場合は既定設定を返します
     * @return 比較設定
     * @throws IOException 設定ファイルの読み込みに失敗した場合
     */
    public static CompareConfig load(Path path) throws IOException {
        if (path == null) return new CompareConfig();
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            p.load(in);
        }
        return CompareConfig.from(p);
    }
}

