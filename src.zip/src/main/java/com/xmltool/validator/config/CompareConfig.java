package com.xmltool.validator.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * XML 比較処理で使用する設定値を保持します。
 *
 * <p>properties ファイルから読み込まれる各種フラグと、
 * 差分無視対象の XPath 一覧を管理します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class CompareConfig {
    /** 要素間空白を無視するか。 */
    private boolean ignoreWhitespace = true;
    /** XML コメントを無視するか。 */
    private boolean ignoreComments = true;
    /** 連続空白を正規化するか。 */
    private boolean normalizeWhitespace = false;
    /** テキスト前後空白を無視するか。 */
    private boolean trimText = true;
    /** 類似比較ではなく完全一致比較を行うか。 */
    private boolean checkForIdentical = false;
    /** 比較対象から除外する XPath または正規表現の一覧です。 */
    private List<String> ignoreXpaths = new ArrayList<>();

    /**
     * properties から設定オブジェクトを生成します。
     *
     * @param p 読み込み済み properties
     * @return 設定オブジェクト
     */
    public static CompareConfig from(Properties p) {
        CompareConfig c = new CompareConfig();
        c.ignoreWhitespace = bool(p, "ignoreWhitespace", true);
        c.ignoreComments = bool(p, "ignoreComments", true);
        c.normalizeWhitespace = bool(p, "normalizeWhitespace", false);
        c.trimText = bool(p, "trimText", true);
        c.checkForIdentical = bool(p, "checkForIdentical", false);
        String ignores = p.getProperty("ignoreXpaths", "").trim();
        if (!ignores.isEmpty()) {
            // セミコロン区切りで複数の XPath / 正規表現を受け付けます。
            for (String s : ignores.split(";")) {
                if (!s.trim().isEmpty()) c.ignoreXpaths.add(s.trim());
            }
        }
        return c;
    }

    /**
     * 真偽値設定を取得します。
     *
     * @param p properties
     * @param key キー名
     * @param def 既定値
     * @return 真偽値
     */
    private static boolean bool(Properties p, String key, boolean def) {
        return Boolean.parseBoolean(p.getProperty(key, String.valueOf(def)));
    }

    /** @return 要素間空白を無視する場合は true */
    public boolean isIgnoreWhitespace() { return ignoreWhitespace; }
    /** @return コメントを無視する場合は true */
    public boolean isIgnoreComments() { return ignoreComments; }
    /** @return 空白正規化を行う場合は true */
    public boolean isNormalizeWhitespace() { return normalizeWhitespace; }
    /** @return 前後空白を無視する場合は true */
    public boolean isTrimText() { return trimText; }
    /** @return 完全一致比較を行う場合は true */
    public boolean isCheckForIdentical() { return checkForIdentical; }
    /** @return 除外 XPath 一覧 */
    public List<String> getIgnoreXpaths() { return ignoreXpaths; }
}

