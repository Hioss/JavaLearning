package com.xmltool.validator;

import com.xmltool.validator.batch.BatchComparisonRunner;
import com.xmltool.validator.cli.Arguments;
import com.xmltool.validator.compare.XmlMessageComparator;
import com.xmltool.validator.config.CompareConfig;
import com.xmltool.validator.config.CompareConfigLoader;
import com.xmltool.validator.model.BatchComparisonSummary;
import com.xmltool.validator.model.ComparisonReport;
import com.xmltool.validator.output.ReportWriter;
import com.xmltool.validator.schema.XsdSupport;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * XML メッセージ比較ツールのエントリーポイントです。
 *
 * <p>コマンドライン引数の解析、入力ファイルの存在確認、比較処理の実行、
 * レポート出力、および終了コードの制御を担当します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class XmlValidationApplication {
    /**
     * アプリケーションを起動します。
     *
     * @param args コマンドライン引数
     */
    public static void main(String[] args) {
        int code = run(args);
        if (code != 0) System.exit(code);
    }

    /**
     * 引数に基づいて比較処理を実行し、終了コードを返します。
     *
     * @param args コマンドライン引数
     * @return 終了コード
     */
    public static int run(String[] args) {
        try {
            Arguments arguments = Arguments.parse(args);
            if (arguments.isHelp()) { printHelp(); return 0; }

            // 必須・任意引数を用途別に取得します。
            Path current = arguments.requiredPath("current");
            Path newer = arguments.requiredPath("new");
            Path xsd = arguments.optionalPath("xsd");
            Path configPath = arguments.optionalPath("config");
            Path json = arguments.optionalPath("json");
            Path csv = arguments.optionalPath("csv");
            Path html = arguments.optionalPath("html");
            Path outputDir = arguments.optionalPath("outputDir");

            // 入力ファイルは実行前に存在性と可読性を検証します。
            if (xsd != null) checkReadable(xsd, "XSD");
            if (configPath != null) checkReadable(configPath, "設定ファイル");

            CompareConfig config = CompareConfigLoader.load(configPath);
            XsdSupport xsdSupport = xsd == null ? null : new XsdSupport(xsd);

            if (Files.isDirectory(current) && Files.isDirectory(newer)) {
                checkDirectory(current, "現行XMLディレクトリ");
                checkDirectory(newer, "新版XMLディレクトリ");
                if (outputDir == null) outputDir = Path.of("comparison-output");

                XmlMessageComparator comparator = new XmlMessageComparator(config, xsdSupport);
                BatchComparisonRunner runner = new BatchComparisonRunner(comparator, xsdSupport);
                BatchComparisonSummary summary = runner.compareDirectories(current, newer, outputDir);

                System.out.println("比較モード: ディレクトリ一括比較");
                System.out.println("対象件数: " + summary.getTotalFiles());
                System.out.println("差分あり件数: " + summary.getDifferentFiles());
                System.out.println("サマリーJSON: " + outputDir.resolve("batch-summary.json").toAbsolutePath());
                System.out.println("サマリーCSV: " + outputDir.resolve("batch-summary.csv").toAbsolutePath());
                System.out.println("サマリーHTML: " + outputDir.resolve("batch-summary.html").toAbsolutePath());
                return summary.getDifferentFiles() == 0 ? 0 : 1;
            }

            checkReadable(current, "現行XML");
            checkReadable(newer, "新版XML");
            if (json == null) json = Path.of("comparison-result.json");
            if (html == null) html = Path.of("comparison-result.html");

            if (xsdSupport != null) {
                // 比較前に両方の XML を XSD で検証し、不正な入力を早期に検出します。
                xsdSupport.validate(current);
                xsdSupport.validate(newer);
            }

            XmlMessageComparator comparator = new XmlMessageComparator(config, xsdSupport);
            ComparisonReport report = comparator.compare(current, newer);
            if (xsd != null) report.setXsdFile(xsd.toAbsolutePath().toString());

            ensureParent(json);
            ReportWriter.writeJson(report, json);
            if (csv != null) { ensureParent(csv); ReportWriter.writeCsv(report, csv); }
            ensureParent(html);
            ReportWriter.writeHtml(report, html);

            System.out.println("比較結果: " + displayResult(report.getResult()));
            System.out.println("差分件数: " + report.getDifferenceCount());
            System.out.println("JSONレポート: " + json.toAbsolutePath());
            if (csv != null) System.out.println("CSVレポート: " + csv.toAbsolutePath());
            System.out.println("HTMLレポート: " + html.toAbsolutePath());
            return report.getDifferenceCount() == 0 ? 0 : 1;
        } catch (IllegalArgumentException e) {
            System.err.println("引数エラー: " + e.getMessage());
            printHelp();
            return 2;
        } catch (org.xml.sax.SAXException e) {
            System.err.println("XML/XSD検証エラー: " + e.getMessage());
            return 4;
        } catch (Exception e) {
            System.err.println("実行に失敗しました: " + e.getMessage());
            e.printStackTrace(System.err);
            return 9;
        }
    }

    /**
     * 指定パスが通常ファイルであり、読み取り可能であることを確認します。
     *
     * @param p 対象パス
     * @param label エラーメッセージ用ラベル
     */
    private static void checkReadable(Path p, String label) {
        if (!Files.isRegularFile(p) || !Files.isReadable(p)) {
            throw new IllegalArgumentException(label + " が存在しないか、読み取れません: " + p);
        }
    }

    /**
     * 指定パスが読み取り可能なディレクトリであることを確認します。
     *
     * @param p 対象ディレクトリ
     * @param label エラーメッセージ用ラベル
     */
    private static void checkDirectory(Path p, String label) {
        if (!Files.isDirectory(p) || !Files.isReadable(p)) {
            throw new IllegalArgumentException(label + " が存在しないか、読み取れません: " + p);
        }
    }

    /**
     * 出力先の親ディレクトリを必要に応じて作成します。
     *
     * @param p 出力ファイルパス
     * @throws Exception ディレクトリ作成に失敗した場合
     */
    private static void ensureParent(Path p) throws Exception {
        Path parent = p.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
    }

    /**
     * 内部結果コードを画面表示用の日本語へ変換します。
     *
     * @param result 内部結果コード
     * @return 日本語表示
     */
    private static String displayResult(String result) {
        if ("SAME".equals(result)) return "一致";
        if ("DIFFERENT".equals(result)) return "差分あり";
        return result;
    }

    /**
     * ヘルプメッセージを標準出力へ表示します。
     */
    private static void printHelp() {
        System.out.println("XMLメッセージ検証ツール\n" +
                "使い方:\n" +
                "  java -jar xml-validation-tool.jar --current old.xml --new new.xml [オプション]\n\n" +
                "必須引数:\n" +
                "  --current <ファイル>   現行XMLファイル\n" +
                "  --new <ファイル>       新版XMLファイル\n\n" +
                "任意引数:\n" +
                "  --xsd <ファイル>       XSD検証とデータ型解析\n" +
                "  --config <ファイル>    properties形式の比較設定\n" +
                "  --json <ファイル>      JSON出力。既定値は comparison-result.json\n" +
                "  --csv <ファイル>       CSV出力\n" +
                "  --html <ファイル>      HTML出力。既定値は comparison-result.html\n" +
                "  --outputDir <ディレクトリ>  ディレクトリ一括比較時の出力先\n" +
                "  --help                 ヘルプを表示\n\n" +
                "終了コード: 0=一致, 1=差分あり, 2=引数エラー, 4=XML/XSDエラー, 9=内部エラー");
    }
}

