package com.xmltool.validator.schema;

import com.xmltool.validator.util.SecureXml;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * XSD を利用した XML 検証および要素型解決を提供します。
 *
 * <p>スキーマ検証に加え、XSD 内の要素宣言から型情報を抽出し、
 * XPath から要素型を逆引きできるようにします。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public class XsdSupport {
    /** XML Schema 名前空間 URI です。 */
    private static final String XSD_NS = XMLConstants.W3C_XML_SCHEMA_NS_URI;
    /** 読み込み対象の XSD パスです。 */
    private final Path xsdPath;
    /** 要素名から型名を引くための簡易マップです。 */
    private final Map<String, String> elementTypes = new HashMap<>();

    /**
     * XSD サポートを初期化します。
     *
     * @param xsdPath XSD パス
     * @throws Exception XSD 読み込みに失敗した場合
     */
    public XsdSupport(Path xsdPath) throws Exception {
        this.xsdPath = xsdPath;
        if (xsdPath != null) loadTypes();
    }

    /**
     * XML ファイルを XSD で検証します。
     *
     * @param xmlPath 検証対象 XML
     * @throws SAXException XML/XSD 検証エラー
     * @throws IOException ファイル読み込みエラー
     */
    public void validate(Path xmlPath) throws SAXException, IOException {
        if (xsdPath == null) return;
        SchemaFactory factory = SchemaFactory.newInstance(XSD_NS);
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        Schema schema = factory.newSchema(xsdPath.toFile());
        Validator validator = schema.newValidator();
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        validator.validate(new StreamSource(xmlPath.toFile()));
    }

    /**
     * XPath から最も近い要素名を抽出し、対応する型を返します。
     *
     * @param xpath 対象 XPath
     * @return 型名。解決できない場合は null
     */
    public String resolveType(String xpath) {
        if (xpath == null) return null;
        String[] parts = xpath.split("/");
        for (int i = parts.length - 1; i >= 0; i--) {
            String p = parts[i];
            if (p.isEmpty() || p.startsWith("text()") || p.startsWith("@")) continue;
            // インデックスや名前空間接頭辞を除去し、要素名だけで型を引きます。
            String name = p.replaceFirst("\\[.*$", "");
            int colon = name.indexOf(':');
            if (colon >= 0) name = name.substring(colon + 1);
            String type = elementTypes.get(name);
            if (type != null) return type;
        }
        return null;
    }

    /**
     * XSD から要素型マップを構築します。
     *
     * @throws Exception XSD 解析に失敗した場合
     */
    private void loadTypes() throws Exception {
        Document doc = SecureXml.newDocumentBuilderFactory().newDocumentBuilder().parse(xsdPath.toFile());
        NodeList elements = doc.getElementsByTagNameNS(XSD_NS, "element");
        for (int i = 0; i < elements.getLength(); i++) {
            Element e = (Element) elements.item(i);
            String name = e.getAttribute("name");
            if (name.isEmpty()) continue;
            String type = e.getAttribute("type");
            // type 属性が無い場合はインライン定義から型を推定します。
            if (type.isEmpty()) type = findInlineType(e);
            if (!type.isEmpty()) elementTypes.putIfAbsent(name, type);
        }
    }

    /**
     * インライン定義された simpleType / complexType を判定します。
     *
     * @param e 対象要素
     * @return 型名。見つからない場合は空文字
     */
    private String findInlineType(Element e) {
        NodeList children = e.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node n = children.item(i);
            if (n.getNodeType() != Node.ELEMENT_NODE) continue;
            Element child = (Element) n;
            if (!XSD_NS.equals(child.getNamespaceURI())) continue;
            if ("simpleType".equals(child.getLocalName())) {
                NodeList restrictions = child.getElementsByTagNameNS(XSD_NS, "restriction");
                if (restrictions.getLength() > 0) {
                    String base = ((Element) restrictions.item(0)).getAttribute("base");
                    return base.isEmpty() ? "xsd:simpleType" : base;
                }
                return "xsd:simpleType";
            }
            if ("complexType".equals(child.getLocalName())) return "xsd:complexType";
        }
        return "";
    }
}

