package com.xmltool.validator.schema;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;

/**
 * データ型に応じた値比較を提供します。
 *
 * <p>数値や日付系の値を文字列の完全一致ではなく、論理的な同値性で比較します。</p>
 *
 * <p>作成者: ZSJ 程</p>
 */
public final class TypedValueComparator {
    private TypedValueComparator() {}

    /**
     * 指定型に基づいて 2 つの値が同値か判定します。
     *
     * @param type データ型
     * @param currentValue 現行値
     * @param newValue 新版値
     * @return 同値の場合は true
     */
    public static boolean areEquivalent(String type, String currentValue, String newValue) {
        if (currentValue == null || newValue == null) return false;
        String normalizedType = normalizeType(type);
        String left = currentValue.trim();
        String right = newValue.trim();
        switch (normalizedType) {
            case "integer":
            case "decimal":
                return compareDecimal(left, right);
            case "date":
                return compareDate(left, right);
            case "dateTime":
                return compareDateTime(left, right);
            case "boolean":
                return compareBoolean(left, right);
            default:
                return left.equals(right);
        }
    }

    /**
     * 2 つの値から比較用の推定型を決定します。
     *
     * @param currentValue 現行値
     * @param newValue 新版値
     * @return 推定された比較型
     */
    public static String inferComparableType(String currentValue, String newValue) {
        String leftType = TypeInference.infer(currentValue);
        String rightType = TypeInference.infer(newValue);
        if (leftType == null) return rightType;
        if (rightType == null) return leftType;
        if (leftType.equals(rightType)) return leftType;
        if (isNumeric(leftType) && isNumeric(rightType)) return "decimal";
        return "string";
    }

    /**
     * XSD 型名を比較用の基本型へ正規化します。
     *
     * @param type 元の型名
     * @return 正規化後の型名
     */
    public static String normalizeType(String type) {
        if (type == null || type.trim().isEmpty()) return "string";
        String value = type.trim();
        int colon = value.indexOf(':');
        if (colon >= 0) value = value.substring(colon + 1);
        switch (value) {
            case "byte":
            case "short":
            case "int":
            case "long":
            case "integer":
            case "nonNegativeInteger":
            case "positiveInteger":
            case "negativeInteger":
            case "nonPositiveInteger":
            case "unsignedByte":
            case "unsignedShort":
            case "unsignedInt":
            case "unsignedLong":
                return "integer";
            case "float":
            case "double":
            case "decimal":
                return "decimal";
            case "date":
                return "date";
            case "dateTime":
                return "dateTime";
            case "boolean":
                return "boolean";
            default:
                return "string";
        }
    }

    private static boolean isNumeric(String type) {
        return "integer".equals(type) || "decimal".equals(type);
    }

    private static boolean compareDecimal(String left, String right) {
        try {
            return new BigDecimal(left).compareTo(new BigDecimal(right)) == 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean compareDate(String left, String right) {
        try {
            return LocalDate.parse(left).equals(LocalDate.parse(right));
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    private static boolean compareDateTime(String left, String right) {
        try {
            return toInstant(left).equals(toInstant(right));
        } catch (DateTimeParseException e) {
            try {
                return LocalDateTime.parse(left).equals(LocalDateTime.parse(right));
            } catch (DateTimeParseException ignored) {
                return false;
            }
        }
    }

    private static Instant toInstant(String value) {
        return OffsetDateTime.parse(value).toInstant();
    }

    private static boolean compareBoolean(String left, String right) {
        return Boolean.parseBoolean(left) == Boolean.parseBoolean(right)
                && ("true".equalsIgnoreCase(left) || "false".equalsIgnoreCase(left))
                && ("true".equalsIgnoreCase(right) || "false".equalsIgnoreCase(right));
    }
}

