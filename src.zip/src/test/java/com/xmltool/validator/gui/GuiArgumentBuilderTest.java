package com.xmltool.validator.gui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * {@link GuiArgumentBuilder} の検証と引数組み立てを確認します。
 *
 * <p>作成者: ZSJ 程</p>
 */
class GuiArgumentBuilderTest {
    @Test
    void shouldBuildFileComparisonArguments(@TempDir Path tempDir) throws Exception {
        Path current = Files.writeString(tempDir.resolve("current.xml"), "<a/>");
        Path newer = Files.writeString(tempDir.resolve("new.xml"), "<a/>");
        GuiExecutionOptions options = new GuiExecutionOptions();
        options.setCurrentPath(current.toString());
        options.setNewPath(newer.toString());
        options.setJsonPath(tempDir.resolve("result.json").toString());
        options.setHtmlPath(tempDir.resolve("result.html").toString());

        String[] args = GuiArgumentBuilder.build(options);

        assertArrayEquals(new String[] {
                "--current", current.toString(),
                "--new", newer.toString(),
                "--json", tempDir.resolve("result.json").toString(),
                "--html", tempDir.resolve("result.html").toString()
        }, args);
    }

    @Test
    void shouldBuildDirectoryComparisonArguments(@TempDir Path tempDir) throws Exception {
        Path current = Files.createDirectory(tempDir.resolve("current"));
        Path newer = Files.createDirectory(tempDir.resolve("new"));
        GuiExecutionOptions options = new GuiExecutionOptions();
        options.setCurrentPath(current.toString());
        options.setNewPath(newer.toString());
        options.setOutputDir(tempDir.resolve("output").toString());

        String[] args = GuiArgumentBuilder.build(options);

        assertArrayEquals(new String[] {
                "--current", current.toString(),
                "--new", newer.toString(),
                "--outputDir", tempDir.resolve("output").toString()
        }, args);
    }

    @Test
    void shouldRejectMixedFileAndDirectory(@TempDir Path tempDir) throws Exception {
        Path current = Files.writeString(tempDir.resolve("current.xml"), "<a/>");
        Path newer = Files.createDirectory(tempDir.resolve("new"));
        GuiExecutionOptions options = new GuiExecutionOptions();
        options.setCurrentPath(current.toString());
        options.setNewPath(newer.toString());

        assertThrows(IllegalArgumentException.class, () -> GuiArgumentBuilder.build(options));
    }
}

