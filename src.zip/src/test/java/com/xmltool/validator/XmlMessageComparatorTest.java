package com.xmltool.validator;

import com.xmltool.validator.compare.XmlMessageComparator;
import com.xmltool.validator.config.CompareConfig;
import com.xmltool.validator.model.ComparisonReport;
import com.xmltool.validator.schema.XsdSupport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * {@link XmlMessageComparator} の基本動作を確認するテストです。
 *
 * <p>作成者: ZSJ 程</p>
 */
class XmlMessageComparatorTest {
    /**
     * 内容が同一の XML は SAME と判定されることを確認します。
     */
    @Test
    void sameXmlShouldReturnSame() {
        XmlMessageComparator comparator = new XmlMessageComparator(new CompareConfig(), null);
        ComparisonReport report = comparator.compare(
                Path.of("src/test/resources/same-a.xml"),
                Path.of("src/test/resources/same-b.xml"));
        assertEquals("SAME", report.getResult());
        assertEquals(0, report.getDifferenceCount());
    }

    /**
     * 値変更時に DIFFERENT となり、XPath が取得できることを確認します。
     */
    @Test
    void changedValueShouldReturnDifferenceAndXpath() {
        XmlMessageComparator comparator = new XmlMessageComparator(new CompareConfig(), null);
        ComparisonReport report = comparator.compare(
                Path.of("src/test/resources/diff-a.xml"),
                Path.of("src/test/resources/diff-b.xml"));
        assertEquals("DIFFERENT", report.getResult());
        assertTrue(report.getDifferenceCount() > 0);
        assertNotNull(report.getDifferences().get(0).getCurrentXPath());
    }

    /**
     * 小数の表記差が同値として扱われることを確認します。
     */
    @Test
    void numericTypedComparisonShouldTreatEquivalentDecimalsAsSame(@TempDir Path tempDir) throws Exception {
        Path current = write(tempDir.resolve("current.xml"),
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?><order><amount>100.00</amount></order>");
        Path newer = write(tempDir.resolve("new.xml"),
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?><order><amount>100.0</amount></order>");
        XmlMessageComparator comparator = new XmlMessageComparator(new CompareConfig(), null);

        ComparisonReport report = comparator.compare(current, newer);

        assertEquals("SAME", report.getResult());
        assertEquals(0, report.getDifferenceCount());
    }

    /**
     * 同一瞬時を表す日時文字列が同値として扱われることを確認します。
     */
    @Test
    void dateTimeTypedComparisonShouldTreatSameInstantAsSame(@TempDir Path tempDir) throws Exception {
        Path current = write(tempDir.resolve("current.xml"),
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?><order><generatedAt>2026-07-23T10:00:00+09:00</generatedAt></order>");
        Path newer = write(tempDir.resolve("new.xml"),
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?><order><generatedAt>2026-07-23T01:00:00Z</generatedAt></order>");
        XmlMessageComparator comparator = new XmlMessageComparator(new CompareConfig(), null);

        ComparisonReport report = comparator.compare(current, newer);

        assertEquals("SAME", report.getResult());
        assertEquals(0, report.getDifferenceCount());
    }

    /**
     * ディレクトリ一括比較でサマリーと個別 HTML レポートが生成されることを確認します。
     */
    @Test
    void directoryComparisonShouldGenerateBatchReports(@TempDir Path tempDir) throws Exception {
        Path currentDir = Files.createDirectories(tempDir.resolve("current"));
        Path newDir = Files.createDirectories(tempDir.resolve("new"));
        Path outputDir = tempDir.resolve("output");
        write(currentDir.resolve("a.xml"), "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><v>1</v></root>");
        write(newDir.resolve("a.xml"), "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><v>1</v></root>");
        write(currentDir.resolve("b.xml"), "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><v>1</v></root>");
        write(newDir.resolve("b.xml"), "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><v>2</v></root>");

        int code = XmlValidationApplication.run(new String[] {
                "--current", currentDir.toString(),
                "--new", newDir.toString(),
                "--outputDir", outputDir.toString()
        });

        assertEquals(1, code);
        assertTrue(Files.isRegularFile(outputDir.resolve("batch-summary.json")));
        assertTrue(Files.isRegularFile(outputDir.resolve("batch-summary.csv")));
        assertTrue(Files.isRegularFile(outputDir.resolve("batch-summary.html")));
        assertTrue(Files.isRegularFile(outputDir.resolve("files").resolve("a.html")));
        assertTrue(Files.isRegularFile(outputDir.resolve("files").resolve("b.html")));
        String batchHtml = Files.readString(outputDir.resolve("batch-summary.html"), StandardCharsets.UTF_8);
        String detailHtml = Files.readString(outputDir.resolve("files").resolve("b.html"), StandardCharsets.UTF_8);
        assertTrue(batchHtml.contains("<th class=\"sequence-column\">番号</th>"));
        assertTrue(batchHtml.contains("<td class=\"sequence-column\">1</td>"));
        assertTrue(batchHtml.contains("<td class=\"sequence-column\">2</td>"));
        assertTrue(detailHtml.contains("<th class=\"sequence-column\">番号</th>"));
        assertTrue(detailHtml.contains("<td class=\"sequence-column\">1</td>"));
    }

    private static Path write(Path path, String content) throws IOException {
        Files.writeString(path, content, StandardCharsets.UTF_8);
        return path;
    }
}

