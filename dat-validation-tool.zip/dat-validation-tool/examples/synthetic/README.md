# SYNTHETIC 合成设置

本目录仅用于公开测试。机构号、BSCode、BAH 长度和字段位置均为合成值，不代表 JASDEC 或公司协议。

- `specification/synthetic-normal.xls[x]`：横移、多行／合并表头、改名 sheet、隐藏／空白行、Excel 真公式、合法 1 字节间隔、Ccy、MAI／MAJ／OPJ。
- `specification/synthetic-repeat.xls[x]`：前 38 字节 6 字段与 L1 最大 30 次；9 个原始定义展开为 96 个字段，正文终点 788。
- `config.synthetic.json`：96 字节合成 BAH 与 8 字节合成前置头。96 和 8 都不是生产默认。
- `mapping.synthetic.json`：明确 sheet、行范围与实际列号的手工映射，可由独立 CLI 进程重现普通布局。
- `messages/current.dat`／`new.dat`：正常两记录，new 的文档 2 仅正文末字段不同，且记录顺序反转。
- `messages/new-equal-reordered.dat`：与 current 业务内容相同但顺序反转。
- `messages/mixed-types.dat`、`invalid-shift-jis.dat`：类型排除和严格解码错误用例。
- `messages/prefix.dat`、`marker.dat`：PREFIX／MARKER 删头预览用例；对应步骤必须显式配置。
- `messages/repeat-current.dat`／`repeat-new.dat`：788 字节正文，后者只修改第 30 组 ISIN。

关键独立期望：L1 第 30 组位置为 764、776、785，末端 788。所有文件标识均使用 `synt.*` 和 `99-*` 测试值。
