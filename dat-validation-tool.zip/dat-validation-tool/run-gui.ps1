$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $projectRoot
if (-not (Test-Path -LiteralPath "$projectRoot\target\dat-validation-tool.jar")) {
    & "$projectRoot\build.ps1"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
& java -cp "$projectRoot\target\dat-validation-tool.jar" com.dattool.validator.gui.DatValidationGui
exit $LASTEXITCODE
