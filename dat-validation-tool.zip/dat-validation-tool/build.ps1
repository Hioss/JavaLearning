# DAT 比較ツールを任意の作業ディレクトリからビルドします。
$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $projectRoot
mvn clean test package
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Build succeeded: $projectRoot\target\dat-validation-tool.jar"
exit 0
