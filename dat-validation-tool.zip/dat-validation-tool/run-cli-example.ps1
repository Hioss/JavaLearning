# 互換用入口。完全比較例へ転送します。
$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $projectRoot
& "$projectRoot\run-example.ps1"
exit $LASTEXITCODE
