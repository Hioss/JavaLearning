# Windows GUI 受入チェックリスト

## 前提

- `package-gui-image.ps1` を実行済みであること。
- `examples\synthetic\` が同じプロジェクト内にあること。
- Excel は不要です。結果を閲覧する場合だけ Excel または互換 viewer を使用します。

## 差分比較

1. `dist-image\dat-validation-tool\dat-validation-tool.exe` を起動します。
2. `共用設定 JSON` に `examples\synthetic\config.synthetic.json` を指定して「設定読込」を押します。
3. 出力を未使用の `.xlsx` に変更します。
4. 「仕様分析」を押し、候補とフィールド表が表示されることを確認します。
5. 「現をプレビュー」と「新をプレビュー」を押し、record 数、fileOffset、削除 byte、BAH キーが表示されることを確認します。
6. 「比較開始」を押します。結果は code 1／`DIFFERENT`／`COMPLETE` です。
7. 「Excel を開く」または「結果フォルダー」をユーザー自身で押し、成果物が開くことを確認します。

## 一致比較

`新比較ファイル`を `messages\new-equal-reordered.dat` に変更し、別の出力名で再実行します。入力順が違っても code 0／`EQUAL` になります。

## 修正可能エラー

`現比較ファイル`を存在しないパスにして実行し、具体的な事前検証エラーが出ることを確認します。その後正しいパスへ戻し、同じ window で再実行できることを確認します。

## 応答と終了

実行中は設定欄と button が無効化されます。処理中に window close を選ぶと強制取消せず警告し、処理完了後は閉じられます。表示倍率を変更し、四つの path、tab、table scroll、進捗、結果 summary が操作可能であることを確認します。

この手順で会社ファイルや network は使用しません。96 byte BAH と 8 byte 前置 header は合成例に限ります。

## 配布物の自動 smoke

リリース確認では次の診断入口を使用できます。通常利用時には不要です。最終 app-image 自身が可視 window を開き、設定読込、仕様分析、現データのプレビュー、一致比較、報告作成を同じ button action から実行して終了します。

```powershell
dist-image\dat-validation-tool\dat-validation-tool.exe `
  --acceptance-smoke <project-root> <output.xlsx> Shift_JIS [--open-result]
```

文字セットは `Shift_JIS` または `windows-31j` だけを受け付けます。成功は終了コード 0 と EQUAL／COMPLETE の報告、引数不正は 2、実行失敗は 9 です。
