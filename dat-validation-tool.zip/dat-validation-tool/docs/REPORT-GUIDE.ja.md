# 比較レポートの読み方

本ツールの `.xlsx` は Apache POI が比較結果モデルから生成します。手作業で編集した見本ではありません。

- `実行概要`: `EQUAL`／`DIFFERENT`／`UNKNOWN`、構造、完全性、BAH 解釈能力と数量を確認します。
- `項目定義`: BAH と展開済み本文項目の 1 起位置、byte 長、繰返し ID、元仕様セルを確認します。
- `電文対照*`: 一ペアにつき「現」「新」「判定」の三行です。判定は boolean の `TRUE`／`FALSE`、比較不能は `N/A` です。列が Excel 上限を超える場合は `C`、行が上限を超える場合は `P` の付いた sheet に分割されます。
- `差異明細`: 一行一差分で、現／新の値、絶対 fileOffset とフィールド内の最初の差分位置を示します。
- `単側・曖昧`: `CURRENT_ONLY`、`NEW_ONLY`、`AMBIGUOUS_KEY` の候補を示します。
- `診断`: 設定、仕様セル、レコード番号、0 起 byteOffset と修正案を示します。

同名の `*-assets-<runId>` ディレクトリには UTF-8 `manifest.json`、両側の `*.bin` と CSV index が入ります。index の `start` と `length` で、改行を含む電文も損失なく復元できます。長すぎる Excel セル値は `values/*.bin` に保存され、セルから参照されます。
