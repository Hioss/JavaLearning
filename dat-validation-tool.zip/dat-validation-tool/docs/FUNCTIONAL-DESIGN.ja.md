# DAT 固定長電文比較ツール 機能設計

## 1. 目的と境界

本ツールは、STPCOM 仕様書から固定長レイアウトを取り込み、現／新二つの DAT 電文を原始 byte 基準で比較する Windows オフラインアプリケーションです。Swing と CLI は共通の設定、入力、比較、報告コードを呼びます。Excel 原本と DAT 原本は読み取り専用です。

対象外は Web UI、会社 MQ、仕様や電文の外部送信、正式凡例なしの MAI／MAJ／OPJ 必須判定、数値／日付の論理同値化です。

## 2. 構成

| 層 | 主要クラス | 責務 |
| --- | --- | --- |
| 入口 | `DatValidationApplication`, `DatValidationGui` | CLI 終了コード、Swing 起動 |
| 設定 | `AppConfig*`, `RunConfigurationResolver`, `PreflightValidator` | JSON schema、CLI 優先順位、パス正規化、実行前保護 |
| 仕様 | `WorkbookSpecAnalyzer`, `LayoutCompiler`, `LayoutSelector` | xls/xlsx 解析、表頭 mapping、位置式、繰返し、候補選択 |
| 入力 | `RecordFramer`, `HeaderStripper`, `InputProcessor` | byte 分割、左右別ヘッダー除去、BAH、型選択、厳格復号 |
| 比較 | `ComparisonEngine` | 3 キーペアリング、重複副本、フィールド／全 byte 比較、状態集約 |
| 報告 | `ComparisonReportWriter` | xlsx、manifest、binary/index、アトミック公開 |
| サービス | `ComparisonExecutionService`, `TaskContext` | 全段階の唯一のオーケストレーション、進捗、task 単位診断 |
| GUI | `MainFrame`, `GuiRunRequestFactory` | ファイル選択、分析、プレビュー、SwingWorker、結果を開く |

## 3. 実行フロー

1. JSON と CLI／画面入力を `ResolvedRunConfiguration` に正規化し、入力と出力の同一パス、拡張子、既存出力、親ディレクトリを事前検証します。
2. Apache POI で `.xls`／`.xlsx` を読み、表頭の文字と相対配置から列を認識します。自動認識できない場合は JSON mapping の実列、行範囲、repeat binding を使います。
3. 位置式を制限付き整数式として評価し、1 起 byte の展開レイアウトを作ります。未宣言の重複、負位置、外部式、資源上限を出典セル付きで拒否します。
4. DAT を byte stream として LINE または SINGLE_MESSAGE に分割します。LINE の separator byte はレコードに含めず、原ファイルの 0 起 offset は含めて進めます。
5. FIXED_LENGTH／PREFIX／MARKER の各 step を現在の残り byte に順番適用し、各削除範囲と累積削除数を `StripTrace` に残します。
6. 明示 BAH テンプレートから message ID、完全 BSCode、document ID を抽出します。選択対象を確定してから本文長とフィールドを検証するため、他種類の短い本文を選択対象のエラーにしません。
7. フィールドは原始 byte で切り分けた後に厳格復号します。復号不能 byte は hex と offset を残し、置換文字で成功扱いしません。
8. `ComparisonEngine` が 3 キーで両側を grouping します。完全 byte 一致の副本を数量付きで相殺し、残りが一対なら比較、複数候補なら `AMBIGUOUS_KEY` とします。
9. ペアレコードは BAH、全展開フィールド、gap／予約域、最後に全削除後 byte を比較します。フィールドに属さない差分も `RAW` 範囲として報告します。
10. 結果モデルから報告を run 固有一時領域へ作成し、成功時だけ最終パスへ公開します。既存報告の置換が失敗した場合は既存物を完全な結果として偽装しません。

## 4. byte と座標

| 座標 | 基準 | 用途 |
| --- | --- | --- |
| 仕様フィールド位置 | 1 起 byte | `ExpandedField.position` |
| 原レコード内 | 0 起 byte | strip／BAH／正文の追跡 |
| 原ファイル | 0 起 byte | separator を含む `fileOffset` |
| binary index | 0 起 byte | 出力 `.bin` 内の `start` と `length` |

位置計算は文字列変換前に実行します。合成例の「8 byte 除去＋96 byte BAH＋第 30 組 ISIN」は、原レコード内 0 起 offset 867、長さ 12 です。この数値はテストベクトルであり本番既定ではありません。

## 5. 状態モデル

一つの boolean では入力の意味を表せないため、次を独立に保持します。

| 軸 | 値 | 説明 |
| --- | --- | --- |
| Equality | `EQUAL`, `DIFFERENT`, `UNKNOWN` | 原始 byte の相等性 |
| Validity | `VALID`, `INVALID`, `UNKNOWN` | 仕様と入力の構造 |
| Completeness | `COMPLETE`, `INCOMPLETE`, `UNKNOWN` | 選択範囲を漏れなく処理したか |
| Interpretation | `FULL`, `BAH_RAW`, `PARTIAL`, `UNKNOWN` | BAH をフィールドとして解釈できた程度 |

たとえば byte が同じでも構造不正なら成功ではありません。未知タイプ、復号エラー、曖昧キー、処理上限超過は、部分的な一致で上書きされません。

## 6. 報告設計

`ComparisonReportWriter` は SXSSF の定数スタイルを再利用し、行、列、セル文字数の三つの限界を数えます。対照 sheet は識別列を含めて列 block を作り、各 block に現／新／判定を繰り返します。文字列は文字列セルとして書き、`=` で始まる値を formula にしません。セル上限を超える完全値は `values/*.bin` に保存します。

選択成功レコードは安定順序で `current.bin`／`new.bin` に連結し、CSV index にキー、原ファイル offset、binary start、length を記録します。separator を境界として仮定しないため、本文に CR／LF があっても復元できます。

## 7. GUI の並行実行

画面は POI、ファイル読取、比較、報告を `SwingWorker#doInBackground` で行い、EDT は表示更新だけを行います。開始時に現在の UI から設定 snapshot を作り、全入力と実行 button を無効化します。完了／失敗の両方で再び有効化します。処理中の window close は強制取消をせず、完了後に閉じるよう案内します。

ログと進捗は `TaskContext` ごとに独立し、`System.out`／`System.err` を置換しません。CLI と GUI の比較結果は同じ `ComparisonExecutionService` から生成されます。

## 8. 配布と検証

Maven compiler は `release=11`、Shade JAR は POI の service resource を統合します。jpackage app-image は GUI main class と専用 Java runtime だけを梱包し、試験一時ファイルや会社データを含めません。

app-image の最終検証には GUI main の限定診断引数 `--acceptance-smoke <project-root> <output.xlsx> <charset> [--open-result]` を使います。これは可視 `MainFrame` を作り、画面と同じ button action で設定読込、仕様分析、プレビュー、共有サービス比較を実行します。受け付ける charset は `Shift_JIS` と `windows-31j` だけです。

テストは設定、仕様、入力、比較、報告、CLI 子プロセス、可視 Swing window を対象にします。圧力ベクトル生成器は 10,000 record／side、本文 2,500 byte、合計約 49.7 MiB を作り、`-Xmx1024m` で全チェーンを実測できます。詳細証拠は `docs/development/PROGRESS.md` に記録します。

## 9. 既知の資料境界

会社内部の仕様・電文は本 workspace に提供されていません。したがって公開合成データによる機能検証と、会社固有 layout の実測は分けて扱います。多候補、未認識表頭、実 BAH の違いは JSON mapping／BAH 設定で解決し、推測した offset を製品既定にはしません。
