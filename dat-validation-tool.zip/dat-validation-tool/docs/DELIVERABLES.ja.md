# 1.0.0-SNAPSHOT 交付物一覧

作成日: 2026-09-10

| 交付物 | byte | SHA-256 |
| --- | ---: | --- |
| `target/dat-validation-tool.jar` | 25,241,056 | `8515A7EF1C3C13FA8D623C4D58D5393E1F5E3D955A61F4F1C1B1096E58E9AE48` |
| `dist-image/dat-validation-tool/dat-validation-tool.exe` | 449,024 | `A437B177741EEDEAE6E0FCDCCEBA3902BC9DF55F1F87C7DEBA47AA7CB037FD42` |
| `README.xlsx` | 7,809 | `7881D42FCF67FDF7F5F27A87C27AEF2FCD5A26E12D6A61F3C5DDA5B1601B7F2C` |
| `機能設計書.xlsx` | 18,960 | `2694BA3CE6D6884F6E7170A636E70DB478CD01901689DA90034EB00C396A263F` |
| `examples/synthetic/results/equal.xlsx` | 11,156 | `130A861D824364C495F7F9BAB7A3EDF29AC020AA770709A1065EAFF3A49F69F6` |
| `examples/synthetic/results/comparison.xlsx` | 11,330 | `0A613D2581F1371423DCD5D609DFB0D2DA03CF1ADC2BBA68AD57D8DB184487F7` |
| `examples/synthetic/results/error.xlsx` | 10,790 | `1768D6E057743BCD43B4758F3CE4A2C5CE9A5C3E2C92A72667E7FDDCB781859F` |

app-image 全体は 356 files、160,250,012 bytes（約 152.8 MiB）で、`app/` と専用 `runtime/` を含みます。exe 単体ではなく `dist-image/dat-validation-tool/` ディレクトリ全体を配布してください。

## 検証摘要

- `package-gui-image.ps1`: exit 0。
- Maven: 51 tests、0 failures、0 errors、0 skipped。
- Java bytecode: major version 55（Java 11）。packaging JDK: 17.0.18。
- app-image: Shift_JIS と windows-31j の可視 GUI smoke が各 exit 0、EQUAL／VALID／COMPLETE、paired=2。
- CLI: exit 0／1／2／4／9 を実入口で確認。出力失敗時の既存物保持と一時物削除を確認。
- stress: 10,000 records／side、入力合計 52,119,996 bytes、`-Xmx1024m`、169,214 ms、10,000 pairs、欠落 0。

Excel／manifest の runId と timestamp は再実行ごとに変わるため、上記 hash はこの表に記載した実ファイルに対応します。app-image 内の JAR は `target/dat-validation-tool.jar` と同じ build からコピーされています。
