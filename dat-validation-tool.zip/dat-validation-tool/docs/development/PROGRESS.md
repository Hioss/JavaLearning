# 开发进度与验收证据

本文件记录实际开发、验收证据与恢复位置。

## 启动与恢复位置

- 用户实际启动入口：`开始 docs/development/00-MASTER.md`。
- 执行模式：总控连续执行 Phase 01～07。
- 当前执行阶段：Phase 01～07 已完成。
- 当前进行中的工作／恢复位置：总控任务验收和交付记录已收尾；无进行中的开发。
- 下一个待执行阶段：无。后续若使用公司实际规格，应作为独立的本地映射／格式适配任务启动。
- 首次启动交互词：`开始 phase-01-foundation.md`。
- 最近实际检查、结果与阻塞：2026-09-10 最终 `package-gui-image.ps1` 退出 0，51 tests／0 failure／0 error／0 skip；app-image 以 Shift_JIS 和 windows-31j 分别完成可视分析、预览、EQUAL 比较并退出 0，Shift_JIS 流程同时实际打开结果目录。10,000 条／侧、约 49.7 MiB 压力全链路通过。无产品阻塞；公司内部格式未实测是明确资料边界。

开发代理在开始、取得关键结果、暂停或结束时更新以上记录。恢复指令仍为用户本次选择的入口；单阶段不会自动改成总控模式。

## 阶段状态

允许状态：`NOT_STARTED`、`IN_PROGRESS`、`BLOCKED`、`DONE`。`DONE` 要有实际验收证据；材料准备完成不等于程序完成。

| 阶段 | 状态 | 验收范围 | 证据／问题 |
| --- | --- | --- | --- |
| Phase 01 | DONE | A01～A05 | 2026-09-09：12 tests PASS；JAR 帮助／配置验证退出 0；major version 55 |
| Phase 02 | DONE | A06～A16 | 2026-09-09：22 tests PASS；真实 JAR 分析 xls/xlsx/manual mapping 均退出 0 |
| Phase 03 | DONE | A17～A30 | 分帧、删头、BAH、严格解码、offset、统计与预览均有测试／样本证据 |
| Phase 04 | DONE | A31～A40 | 稳定三键配对、重复副本、歧义、字段与全 byte 差分通过 |
| Phase 05 | DONE | A41～A49 | 真实 CLI、退出码、Excel／manifest／binary-index、容量与失败安全通过 |
| Phase 06 | DONE | A50～A54 | Swing、共享服务、可视窗口分析／预览／比较／失败恢复／关闭提示通过 |
| Phase 07 | DONE | A55～A60 与全量回归 | 51 tests；49.7 MiB 压力；最终 app-image 的 Shift_JIS/windows-31j 可视流程均退出 0 |

## 每阶段完成时追加的记录

复制下列结构并填写实际信息，不保留模糊的“已测试”。

- 阶段、开始／结束日期、源码版本或变更范围：
- 实现内容及关键文件：
- 验收 ID → 自动测试方法／手工步骤／产物路径／实际结果：
- 执行命令、环境、退出码与摘要：
- 样本及报告摘要／校验值：
- 已知限制、未验证项和真正阻塞：
- 修复的前阶段问题及回归证据：
- 下阶段可以直接使用的接口、配置和样本：
- 是否满足阶段完成条件及理由：

## 当前设计记录

- 实际项目路径：`D:\CX_dat_tool\dat-validation-tool`（阶段文档中的旧示例路径不作为运行依据）。
- 用户已明确确认 Swing 界面版，并保留 CLI；不考虑 Web 版。核心功能为按所选 STPCOM 规格比较现／新两个 DAT 电文文件。
- 业务电文默认 Shift_JIS；原始字节比较，windows-31j 仅显式选用。
- 不知道真实公司头部与 BAH 偏移，采用本地模板；合成 BAH 96 字节不是生产默认。
- 不能获得公司内部项目文件，合成测试与本地预览是开发方案，不声称已验证公司全部规格。
- MAI／MAJ／OPJ 含义尚缺该版本正式凡例，不启用推测的业务必填检查。

## Phase 01（2026-09-09）

- 源码范围：`pom.xml`、`com.dattool.validator` 下 CLI／config／model／service 基础类型、6 个测试类、构建与示例脚本、日文 README、中文架构说明、合成 JSON 配置。
- 依赖版本：Jackson 2.20.0、POI 5.5.1、JUnit 5.13.4、FlatLaf 3.6.1、MigLayout 11.4.2；Compiler 3.14.0、Surefire 3.5.3、Shade 3.6.1。
- A01：`mvn clean test package` 退出 0，12 tests、0 failure/error/skip；`javap -verbose` 显示主类 major version 55；`target/dat-validation-tool.jar --help` 退出 0。
- A02：`AppConfigLoaderTest` 验证往返、未知键路径、schemaVersion、正整数及互斥删头参数。
- A03：`RunConfigurationResolverTest` 验证配置相对配置目录、CLI 相对工作目录、CLI 覆盖 JSON。
- A04：`PreflightValidatorTest` 验证规范化输入输出冲突、已有输出需显式覆盖，并用 SHA-256 断言源文件未变。
- A05：`ExitCodeMapperTest` 覆盖 0/1/2/4/9；`TaskContextTest` 验证配置快照、runId 与日志隔离；核心不依赖 GUI、不替换全局输出。
- 实际命令：`mvn clean test package`、`java -jar target/dat-validation-tool.jar --help`、`java -jar ... --validate-config`、依赖树检查、`javap`，均通过。首次 Maven 调用因沙箱不能写用户 `.m2` 失败，授权写缓存后成功，不属于产品缺陷。
- 环境：Windows 11、Temurin JDK 17.0.18、Maven 3.9.12；编译目标 Java 11。POI 5.5.1 依据 Apache 官方稳定版与 Java 11 支持说明选定。
- 已知边界：Phase 01 按要求不实现规格解析、电文解析、比较、Excel 报告或 GUI；生产入口对这些操作返回明确 `NOT_READY`/4，不生成伪结果。
- 阶段结论：A01～A05 全部满足，Phase 01 DONE；总控模式继续 Phase 02。

## Phase 02（2026-09-09）

- 实现：`WorkbookSpecAnalyzer`、`LayoutCompiler`、`PositionExpression`、`LayoutSelector` 及规格来源／原始定义／展开字段／原始间隔模型；CLI `--analyze-spec` 已走真实生产路径。
- A06～A08：`WorkbookSpecAnalyzerTest` 用 HSSF/XSSF 等价规格验证改名 sheet、横移、合并多行表头、隐藏／稀疏／空白行、说明 sheet、XML 结构行和凡例不误提取；规格 SHA-256 前后相同。
- A09～A11：1 起位置 1/5/10 与第 9 字节间隔；受限表达式支持整数、变量、括号、加减乘及整除，拒绝未知函数／变量／符号／溢出；显式父子重复组和上限诊断有测试。
- A10 独立向量：重复样本 9 个定义展开 96 字段、正文 788 字节；第 1/2/30 组断言，末组 764、776、785。
- A12～A13：真实 Excel 公式与文本位置式分型；公式由 POI 求值，外部公式在求值前拒绝并定位 R13C10；非法长度、范围、声明长度、未声明重叠与显式共用区均有诊断／测试。
- A14：`mapping.synthetic.json` 明确 sheet、行范围、1 起列号；JUnit 保存／加载回归后，又由独立 JAR 进程加载并重现 3 字段／12 字节布局，退出 0。
- A15～A16：完整 BSCode 与 variant/sheet 唯一选择、同名字段不覆盖、歧义拒绝；Ccy 不改变字段边界，MAI／MAJ／OPJ 原值保存且不触发推测的必填规则。
- 合成产物：`examples/synthetic/specification/synthetic-normal.xls[x]` 与 `synthetic-repeat.xls[x]`；SHA-256 分别为 `1FE2957...E8671`、`43E5F484...90E5F`、`81531126...32D42`、`19FE1379...F5A7`。
- 实际检查：`mvn test` 22 tests、0 failure/error/skip；`mvn clean test package` 成功；真实 JAR 分析 normal xls、normal xlsx、repeat xlsx、manual mapping 均退出 0。首次真实 JAR 检查发现 Shade 未合并 POI service，已增加 `ServicesResourceTransformer` 并回归 xls。
- 支持边界：不执行宏、嵌入对象或外部公式；公式缓存仅在显式兼容选项开启且存在可用缓存时使用并告警。真实公司规格尚未验证，遇到多候选或缺列需保存 mapping。
- 阶段结论：A06～A16 全部满足，Phase 02 DONE；总控模式继续 Phase 03。

## Phase 03（2026-09-09）

- 实现：`RecordFramer`、`HeaderStripper`、`InputProcessor`、`InputPreviewService` 及 framed／parsed record、strip trace、byte field、side statistics 模型。
- A17～A20：严格 Shift_JIS 与显式 windows-31j 使用 `CharsetDecoder` 的 REPORT 策略；非法／截断双字节保留 hex。LINE 覆盖 CRLF、LF、AUTO、混合换行、空行、全空格、末行无换行；SINGLE_MESSAGE 保留 CR／LF。
- A21～A23：FIXED_LENGTH／PREFIX／MARKER 逐记录、逐步骤、左右独立执行；第二步骤失败保留第一步累计 offset，越界／零命中／多命中不继续解析。
- A24～A26：96 byte 和非 96 byte BAH、FULL／BAH_RAW 都有测试；不扫描相似正文标识。独立断言 8 byte 删除＋96 byte BAH＋第 30 组 ISIN 的原记录 0 起 offset=867、length=12。
- A27～A30：先识别 BAH 和类型、再按选中正文布局验证；短／长的其他类型不误报；未知类型和失败计数独立，数量守恒；短正文、尾部 RAW、空白重复槽不补齐或截断。
- 合成产物：`examples/synthetic/messages/` 下 current/new、乱序一致、混合类型、损坏编码、PREFIX、MARKER、repeat 文件；均由 `SyntheticMessageGenerator` 生成并标记 SYNTHETIC。
- 自动证据：`RecordFramerTest`、`HeaderStripperTest`、`InputProcessorTest`；规格→输入使用 Phase 02 的真实 xlsx 布局。前阶段测试回归通过。
- 阶段结论：A17～A30 满足，Phase 03 DONE；总控模式继续 Phase 04。

## Phase 04（2026-09-09）

- 实现：`ComparisonEngine`、`ComparisonRunResult`、`RecordComparison`、`FieldComparison`、`ComparisonSummary`、`PairStatus`。
- A31～A32：message ID＋完整 BSCode＋完整 document ID 为唯一业务键；不使用行号、不去先导零、不截取 BSCode。输出排序与输入顺序无关。
- A33～A35：BAH-only、BODY 字段、gap／保留区、最后重复槽、尾空格、大小写、全半角和 `001` 全部按原 byte 严格比较；字段差异未覆盖的全 byte 差异生成 RAW 差异。
- A36～A38：相同 byte 副本先按数量抵消；单侧余量保留；左右各一条残余才确定配对；多个不等价候选输出 `AMBIGUOUS_KEY` 及候选数，不做最近距离匹配。
- A39～A40：Equality、Validity、Completeness、Interpretation 独立聚合；结构错误、未知／失败记录和歧义不被局部相同覆盖。
- 自动证据：`ComparisonEngineTest` 覆盖以上算法；`ComparisonPipelineTest` 用真实 xlsx＋DAT 贯通一致和确定差异。阶段完成时全量测试通过。
- 阶段结论：A31～A40 满足，Phase 04 DONE；总控模式继续 Phase 05。

## Phase 05（2026-09-09）

- 实现：`ComparisonExecutionService` 串联规格、两侧输入、比较、报告；`ComparisonReportWriter` 使用 SXSSF 生成 Excel、manifest、binary/index；CLI 已执行生产链路。
- A41～A43：真实入口支持核心四路径、共用配置、分析／验证／字符集／覆盖。`CliEndToEndTest` 子进程验证退出码 0、1、4、9，`DatValidationApplicationTest` 验证非法参数 2；日文帮助与摘要一致。
- A44～A46：Excel 含 `実行概要`、`項目定義`、`電文対照*`、`差異明細*`、`単側・曖昧`、`診断`、`実行パラメータ`。POI 回读验证三行对照、boolean、N/A、字段身份、`001`、长数字、尾空格、字面 `=1  `；行列分页、小阈值、真实 Excel 常量和超长外置均有测试。
- A47：`manifest.json` 记录状态、数量、差异、来源与配置；`current.bin`／`new.bin` 配 CSV `start/length` 可独立还原每条删除后 BAH＋正文，不假设换行边界。
- A48～A49：既有输出需显式覆盖；输入输出冲突在读取前拒绝；临时 Excel 和 assets 使用 runId，失败只清理本次临时物并保留已有报告。流式 workbook 使用有限 style 和压缩临时 XML。
- 实际差异示例：`examples/synthetic/results/comparison.xlsx` 由 shaded JAR 生成，退出 1，附 runId assets。`run-example.ps1` 和 `docs/REPORT-GUIDE.ja.md` 可复现／解读。
- 阶段结论：A41～A49 满足，Phase 05 DONE；总控模式继续 Phase 06。

## Phase 06（2026-09-09～2026-09-10）

- 实现：`DatValidationGui`、`MainFrame`、`GuiRunRequestFactory`；FlatLaf＋MigLayout 提供四路径、类型键、规格表、两侧预览、高级 JSON、进度、任务日志、结果摘要与主动打开结果。
- A50～A51：自动加载／保存共用 `AppConfig`，编辑 mapping、删头、BAH、encoding 和 output；规格分析和预览调用 Phase 02／03 API，不在 UI 重新切字符串。
- A52：POI／输入／比较／报告都在 `SwingWorker`，本次配置先 snapshot；运行时所有路径、类型、配置和 button 冻结，重复启动被拒；成功／失败均恢复。`MainFrameSmokeTest` 实际创建可视 window，验证 EDT 响应、控件冻结、错误对话框关闭后同 window 修正再运行。
- A53：同一可视 window 使用日文＋空格输入／输出路径完成报告；自动 dispatch 运行中 close 并确认 window 保持、提示关闭后任务完成。最终 app-image smoke 又通过「結果フォルダー」action 实际打开输出目录；宿主 CUA 只暴露浏览器，因此改用程序内 Swing 自动化并如实记录方式。
- A54：`GuiRunRequestFactoryTest` 对同一 config 和日文／空格路径调用唯一 `ComparisonExecutionService`，结果为 EQUAL；GUI 不改变比较状态。
- 启动：`run-gui.ps1` 或 `java -cp target/dat-validation-tool.jar com.dattool.validator.gui.DatValidationGui`。独立启动检查观察到日文 title 且进程 responding。
- 阶段结论：A50～A54 的程序内可视窗口流程、恢复和共享模型满足，Phase 06 DONE；总控模式继续 Phase 07。外部查看器的实际外观取决于用户机器关联程序，列为环境边界而非比较功能。

## Phase 07（2026-09-10）

- A55：51 项单元／集成测试覆盖普通、repeat、混合类型、BAH 变体、重复键、单侧、坏编码、坏规格和输出失败；关键流程均走生产类，0 failure／0 error／0 skip。
- A56：`SyntheticStressGenerator` 生成每侧 10,000 条、每条删除后 96＋2,500 byte；current/new 各 26,059,998 bytes，两侧合计 52,119,996 bytes（约 49.7 MiB）。Windows 11、Temurin JDK 17.0.18、`-Xmx1024m` 实测全链路 169,214 ms，paired=10,000、equal=10,000、EQUAL／VALID／COMPLETE、无漏记；report=1,992,750 bytes，assets=59,822,991 bytes。该次未取得可靠 peak working set，只确认 heap cap，故不虚构内存峰值；生成器可复现。
- A57：compiler `release=11`，`javap` major 55；CLI main 不初始化 AWT。shaded JAR 通过 help、分析与比较；打包使用 jpackage 17.0.18，与运行兼容性分开记录。
- A58：`package-gui-image.ps1` 生成 `dist-image/dat-validation-tool/`，最终 356 files、约 152.8 MiB，含专用 runtime、app jar、Swing／字体／POI／charset provider。最终 `dat-validation-tool.exe --acceptance-smoke` 自身以 Shift_JIS、windows-31j 各运行一次可视 window，真实执行设置读取→规格分析→输入预览→共享服务 EQUAL／COMPLETE 报告，均退出 0；Shift_JIS 流程的结果目录 action 也成功。
- A59：build／example／GUI／package 脚本均从 `$MyInvocation.MyCommand.Path` 定位；app 不请求网络或 Excel，不索取公司文件。脚本的递归删除只针对经绝对路径校验的 `target/jpackage-input` 和 `dist-image/dat-validation-tool`。
- A60：日文 `README.md`、`docs/FUNCTIONAL-DESIGN.ja.md`、`README.xlsx`、`機能設計書.xlsx`、中文 `review.txt`、报告说明、GUI checklist、合成样本／结果均已生成。两个 xlsx 经 artifact-tool 公式错误扫描（0）和全部 6 sheet 渲染复核后修正版式。
- 阶段结论：A55～A60 满足，Phase 07 DONE；总控 Phase 01～07 完成并停止开发。

## 最终交付证据

- 最终构建：2026-09-10 `package-gui-image.ps1` 退出 0；Maven 51 tests、0 failure/error/skip；59 个 main source、20 个 test source 编译通过；Shade 与 jpackage 成功。
- Java：Temurin JDK 17.0.18 构建／打包；compiler `release=11`；`DatValidationApplication.class` major version 55。CLI main 不初始化 GUI。
- CLI 真实退出码：EQUAL=0、DIFFERENT=1、未知参数=2、严格解码失败／NO_DATA=4、非空目录模拟发布失败=9；code 9 后既有 `keep.txt` 内容不变、无本次 temp/assets 残留。
- 最终 JAR：`target/dat-validation-tool.jar`；`docs/DELIVERABLES.ja.md` 记录 SHA-256。Windows app-image：`dist-image/dat-validation-tool/dat-validation-tool.exe`，自带 runtime。
- 最终 app-image smoke：`target/app-image-smoke/shift-jis.xlsx` 与 `windows-31j.xlsx`，对应 manifest 均为 EQUAL／VALID／COMPLETE、paired=2；两次 launcher exit 0。
- 程序生成示例：`examples/synthetic/results/equal.xlsx`（0）、`comparison.xlsx`（1）、`error.xlsx`（4）及各自 runId assets；普通与错误报告用 artifact-tool 导入并查看 `実行概要`、`電文対照`、`診断`，内容与独立期望一致。
- 脚本定位：从 `docs/` 调用 `../run-example.ps1` 退出 0，并正确回到项目根运行真实差异比较。
- 文档工作簿：`README.xlsx` 与 `機能設計書.xlsx` 公式错误扫描均为 0；README 及设计书全部 6 个 sheet 已逐页渲染复核并修正版式。工作表明确标出 SYNTHETIC、96 byte 非本番默认、状态与已知边界。
- 交付边界：没有上传、读取或推测公司内部文件；没有网络、Web、MQ 或发布操作。公司真实 STPCOM／BAH 的首次本地映射验证不计入本合成验收，但程序提供 mapping、预览和可定位诊断来完成该后续适配。
