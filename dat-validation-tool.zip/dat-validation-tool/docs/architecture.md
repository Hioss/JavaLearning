# 架构与配置基线

## 技术基线

- Java 编译目标 11，源码 UTF-8；当前构建环境可使用较新 JDK。
- Maven Compiler 3.14.0、Surefire 3.5.3、Shade 3.6.1。
- Jackson 2.20.0、JUnit Jupiter 5.13.4、FlatLaf 3.6.1、MigLayout Swing 11.4.2。
- Apache POI 5.5.1。Apache 官方将其列为稳定版本，POI 5.x 的最低 Java 版本为 8，官方 FAQ 明确建议使用 Java 11/17/21；本项目仍以 `--release 11` 编译。

## 共享模型

`AppConfig` 是 GUI 与 CLI 的唯一版本化配置。相对路径在 JSON 中以配置文件目录为基准，命令行路径以调用时工作目录为基准；显式 CLI 值覆盖 JSON。Jackson 拒绝未知键，`ConfigValidator` 再检查 schemaVersion、正整数、删头互斥条件、BAH 边界与配对键角色。

`Diagnostic` 同时容纳文件、工作表、单元格、记录与字节偏移来源。`ComparisonResult` 分开表达字节相等性、结构有效性、范围完整性和解释能力，`ExitCodeMapper` 是退出码唯一映射点。

`TaskContext` 为每次执行冻结配置 JSON，并持有独立日志及进度回调。核心逻辑不依赖 Swing，也不替换全局标准输出。

## 明确边界

合成 BAH 的 96 字节只出现在显式合成配置中，不是生产默认。真实 MQMD、自定义头、BAH 位置与长度均必须由规格或本地 JSON 配置确定。Phase 01 不包含规格解析或比较假实现。
