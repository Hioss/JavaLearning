package com.dattool.validator.input;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** FIXED_LENGTH、PREFIX、MARKER を順番に原始バイトへ適用します。 */
public final class HeaderStripper {
    public StripResult strip(FramedRecord record, AppConfig.InputConfig config) {
        byte[] remaining = record.getBytes();
        int cumulative = 0;
        List<StripTrace> traces = new ArrayList<>();
        for (int i = 0; i < config.getStripSteps().size(); i++) {
            AppConfig.StripStep step = config.getStripSteps().get(i);
            int remove;
            try {
                if (step == null || step.getType() == null) {
                    return failure(record, cumulative, traces, "STRIP_CONFIG", "删头步骤或 type 未設定です。");
                }
                if (step.getType() == AppConfig.StripType.FIXED_LENGTH) {
                    if (step.getLength() == null || step.getLength() < 0)
                        return failure(record, cumulative, traces, "STRIP_CONFIG", "FIXED_LENGTH の length は 0 以上が必要です。");
                    remove = step.getLength();
                    if (remove > remaining.length) return failure(record, cumulative, traces, "STRIP_LENGTH",
                            "削除バイト数が現在のレコード長を超えます: " + remove + " > " + remaining.length);
                } else {
                    byte[] pattern = pattern(step, config.getCharset());
                    if (step.getType() == AppConfig.StripType.PREFIX) {
                        if (!startsWith(remaining, pattern)) return failure(record, cumulative, traces, "STRIP_PREFIX",
                                "指定 PREFIX が現在のレコード先頭にありません。");
                        remove = pattern.length;
                    } else {
                        if (step.getSearchWindow() == null || step.getSearchWindow() < 1)
                            return failure(record, cumulative, traces, "STRIP_CONFIG", "MARKER の searchWindow は 1 以上が必要です。");
                        int window = Math.min(step.getSearchWindow(), remaining.length);
                        List<Integer> hits = find(remaining, pattern, window);
                        if (hits.size() != 1) return failure(record, cumulative, traces, "STRIP_MARKER_COUNT",
                                "検索窓内の MARKER 命中数は 1 が必要です: " + hits.size());
                        remove = hits.get(0) + (Boolean.TRUE.equals(step.getIncludeMarker()) ? pattern.length : 0);
                    }
                }
            } catch (IllegalArgumentException e) {
                return failure(record, cumulative, traces, "STRIP_PATTERN", e.getMessage());
            }
            traces.add(new StripTrace(i + 1, step.getType().name(), 0, remove, cumulative, cumulative + remove));
            remaining = Arrays.copyOfRange(remaining, remove, remaining.length);
            cumulative += remove;
        }
        return new StripResult(true, remaining, cumulative, traces, null);
    }

    private byte[] pattern(AppConfig.StripStep step, String charsetName) {
        if (step.getHex() != null && !step.getHex().isEmpty()) {
            String hex=step.getHex();
            if ((hex.length() & 1) != 0 || !hex.matches("[0-9A-Fa-f]+"))
                throw new IllegalArgumentException("hex は偶数桁の 16 進文字列が必要です。");
            byte[] b=new byte[hex.length()/2];
            for(int i=0;i<b.length;i++) b[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16);
            return b;
        }
        if (step.getLiteral() == null || step.getLiteral().isEmpty())
            throw new IllegalArgumentException("literal または hex のいずれかが必要です。");
        try {
            ByteBuffer encoded=Charset.forName(charsetName).newEncoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).encode(CharBuffer.wrap(step.getLiteral()));
            byte[] b=new byte[encoded.remaining()]; encoded.get(b); return b;
        } catch (CharacterCodingException e) { throw new IllegalArgumentException("文字列を " + charsetName + " で符号化できません。"); }
    }
    private boolean startsWith(byte[] value,byte[] prefix){if(prefix.length>value.length)return false;for(int i=0;i<prefix.length;i++)if(value[i]!=prefix[i])return false;return true;}
    private List<Integer> find(byte[] value,byte[] pattern,int window){
        List<Integer> hits=new ArrayList<>(); if(pattern.length==0)return hits;
        for(int i=0;i+pattern.length<=value.length&&i<window;i++){boolean same=true;for(int j=0;j<pattern.length;j++)if(value[i+j]!=pattern[j]){same=false;break;}if(same)hits.add(i);}
        return hits;
    }
    private StripResult failure(FramedRecord r,int removed,List<StripTrace> traces,String code,String message){
        Diagnostic d=new Diagnostic(Diagnostic.Severity.ERROR,code,"HEADER_STRIP",message,
                "currentInput/newInput の stripSteps と検索窓を確認してください。",
                new Diagnostic.SourceLocation(null,null,null,null,r.getRecordNumber(),r.getFileOffset()+removed));
        return new StripResult(false,null,removed,traces,d);
    }
}
