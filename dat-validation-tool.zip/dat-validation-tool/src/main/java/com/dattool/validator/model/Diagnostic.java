package com.dattool.validator.model;

import java.nio.file.Path;
import java.util.Objects;

/** ユーザーが修正できる位置情報付き診断です。 */
public final class Diagnostic {
    public enum Severity { INFO, WARNING, ERROR }

    private final Severity severity;
    private final String code;
    private final String stage;
    private final String message;
    private final String suggestedAction;
    private final SourceLocation source;

    public Diagnostic(Severity severity, String code, String stage, String message,
                      String suggestedAction, SourceLocation source) {
        this.severity = Objects.requireNonNull(severity, "severity");
        this.code = Objects.requireNonNull(code, "code");
        this.stage = Objects.requireNonNull(stage, "stage");
        this.message = Objects.requireNonNull(message, "message");
        this.suggestedAction = suggestedAction;
        this.source = source;
    }

    public static Diagnostic error(String code, String stage, String message, String action) {
        return new Diagnostic(Severity.ERROR, code, stage, message, action, null);
    }

    public Severity getSeverity() { return severity; }
    public String getCode() { return code; }
    public String getStage() { return stage; }
    public String getMessage() { return message; }
    public String getSuggestedAction() { return suggestedAction; }
    public SourceLocation getSource() { return source; }

    /** ファイル、セル、レコード、バイト位置を同時に保持できます。 */
    public static final class SourceLocation {
        private final Path file;
        private final String sheet;
        private final Integer row;
        private final Integer column;
        private final Long recordNumber;
        private final Long byteOffset;

        public SourceLocation(Path file, String sheet, Integer row, Integer column,
                              Long recordNumber, Long byteOffset) {
            this.file = file;
            this.sheet = sheet;
            this.row = row;
            this.column = column;
            this.recordNumber = recordNumber;
            this.byteOffset = byteOffset;
        }

        public Path getFile() { return file; }
        public String getSheet() { return sheet; }
        public Integer getRow() { return row; }
        public Integer getColumn() { return column; }
        public Long getRecordNumber() { return recordNumber; }
        public Long getByteOffset() { return byteOffset; }
    }
}
