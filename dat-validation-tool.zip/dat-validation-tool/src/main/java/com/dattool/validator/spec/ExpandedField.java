package com.dattool.validator.spec;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** 繰返しインデックスを適用した 1 起バイト範囲です。 */
public final class ExpandedField {
    private final String instanceId;
    private final SpecFieldDefinition definition;
    private final int position;
    private final int length;
    private final Map<String, Integer> repeatIndexes;
    public ExpandedField(String instanceId, SpecFieldDefinition definition, int position, int length, Map<String, Integer> indexes) {
        this.instanceId = instanceId; this.definition = definition; this.position = position; this.length = length;
        this.repeatIndexes = Collections.unmodifiableMap(new LinkedHashMap<>(indexes));
    }
    public String getInstanceId() { return instanceId; }
    public SpecFieldDefinition getDefinition() { return definition; }
    public int getPosition() { return position; }
    public int getLength() { return length; }
    public int getEndPosition() { return position + length - 1; }
    public int getZeroBasedOffset() { return position - 1; }
    public Map<String, Integer> getRepeatIndexes() { return repeatIndexes; }
}
