package com.dattool.validator.spec;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 抽出定義を繰返し展開し、範囲、間隔、重複を検証します。 */
public final class LayoutCompiler {
    public CompiledLayout compile(String messageId, String bsCode, String variant, String category, String snapshot,
                                  String role, String sheet, List<SpecFieldDefinition> definitions,
                                  AppConfig.MappingConfig mapping, AppConfig.ResourceLimits limits,
                                  List<Diagnostic> diagnostics) {
        Map<String, Binding> bindings = bindings(mapping, definitions, diagnostics);
        List<ExpandedField> expanded = new ArrayList<>();
        for (SpecFieldDefinition definition : definitions) {
            if (expanded.size() >= limits.getMaxExpandedFields()) {
                diagnostics.add(error("SPEC_EXPANSION_LIMIT", definition, "展開フィールド数が上限を超えます: " + limits.getMaxExpandedFields()));
                break;
            }
            expand(definition, bindings, new LinkedHashMap<>(), expanded, limits, diagnostics);
            if (expanded.size() > limits.getMaxExpandedFields()) {
                diagnostics.add(error("SPEC_EXPANSION_LIMIT", definition, "展開フィールド数が上限を超えます: " + limits.getMaxExpandedFields()));
                break;
            }
        }
        expanded.sort(Comparator.comparingInt(ExpandedField::getPosition).thenComparing(ExpandedField::getInstanceId));
        Integer declaredExpected = mapping == null ? null : mapping.getExpectedBodyLength();
        int expected = declaredExpected == null ? 0 : declaredExpected;
        for (ExpandedField f : expanded) {
            if (declaredExpected != null && f.getEndPosition() > declaredExpected)
                diagnostics.add(error("SPEC_DECLARED_LENGTH", f.getDefinition(), "フィールド終端が明示本文長を超えます: " + f.getEndPosition() + " > " + declaredExpected));
            expected = Math.max(expected, f.getEndPosition());
        }
        List<RawRange> gaps = validateCoverage(expanded, expected, mapping, diagnostics);
        return new CompiledLayout(messageId, bsCode, variant, category, snapshot, role, sheet,
                new ArrayList<>(definitions), expanded, gaps, expected);
    }

    private Map<String, Binding> bindings(AppConfig.MappingConfig mapping, List<SpecFieldDefinition> definitions, List<Diagnostic> d) {
        Map<String, Binding> result = new LinkedHashMap<>();
        if (mapping != null && mapping.getRepeatBindings() != null) for (AppConfig.RepeatBinding b : mapping.getRepeatBindings()) {
            if (b.getId() != null) result.put(b.getId(), new Binding(b.getId(), b.getVariable(), b.getMaxCount(), b.getParentId()));
        }
        for (SpecFieldDefinition f : definitions) if (f.getRepeatId() != null && !f.getRepeatId().isBlank()) {
            Binding existing = result.get(f.getRepeatId());
            if (existing == null && f.getRepeatVariable() != null && f.getMaxCount() != null)
                result.put(f.getRepeatId(), new Binding(f.getRepeatId(), f.getRepeatVariable(), f.getMaxCount(), f.getParentRepeatId()));
            else if (existing != null && f.getMaxCount() != null && existing.max != null && !existing.max.equals(f.getMaxCount()))
                d.add(error("SPEC_REPEAT_CONFLICT", f, "同じ繰返し ID の最大回数が一致しません。"));
        }
        return result;
    }

    private void expand(SpecFieldDefinition f, Map<String, Binding> bindings, Map<String, Integer> indexes,
                        List<ExpandedField> out, AppConfig.ResourceLimits limits, List<Diagnostic> d) {
        List<Binding> chain = new ArrayList<>();
        if (f.getRepeatId() != null && !f.getRepeatId().isBlank()) {
            Set<String> seen = new LinkedHashSet<>();
            String id = f.getRepeatId();
            while (id != null) {
                if (!seen.add(id)) { d.add(error("SPEC_REPEAT_CYCLE", f, "繰返しの親子関係が循環しています: " + id)); return; }
                Binding b = bindings.get(id);
                if (b == null || b.variable == null || b.max == null || b.max < 1) {
                    d.add(error("SPEC_REPEAT_UNKNOWN", f, "繰返し ID の変数／最大回数が確定できません: " + id)); return;
                }
                chain.add(0, b); id = b.parent;
            }
        }
        expandChain(f, chain, 0, indexes, out, limits, d);
    }

    private void expandChain(SpecFieldDefinition f, List<Binding> chain, int depth, Map<String, Integer> indexes,
                             List<ExpandedField> out, AppConfig.ResourceLimits limits, List<Diagnostic> d) {
        if (out.size() >= limits.getMaxExpandedFields()) return;
        if (depth < chain.size()) {
            Binding b = chain.get(depth);
            for (int i = 1; i <= b.max; i++) {
                indexes.put(b.variable, i);
                expandChain(f, chain, depth + 1, indexes, out, limits, d);
            }
            indexes.remove(b.variable);
            return;
        }
        try {
            Set<String> variables = PositionExpression.variables(f.getPositionExpression());
            if (!indexes.keySet().containsAll(variables)) {
                Set<String> missing = new LinkedHashSet<>(variables); missing.removeAll(indexes.keySet());
                d.add(error("SPEC_VARIABLE_UNKNOWN", f, "位置式の変数に繰返し定義がありません: " + missing)); return;
            }
            Map<String, Long> vars = new HashMap<>(); indexes.forEach((k, v) -> vars.put(k, v.longValue()));
            long position = PositionExpression.evaluate(f.getPositionExpression(), vars);
            long end = Math.addExact(position, (long) f.getLength() - 1);
            if (position < 1 || end > Integer.MAX_VALUE) {
                d.add(error("SPEC_RANGE", f, "位置または終端が許容範囲外です: " + position + ".." + end)); return;
            }
            if (f.getLength() < 1) { d.add(error("SPEC_LENGTH", f, "サイズは正の整数である必要があります。")); return; }
            if (f.isCurrency() && f.getLength() < 3) d.add(error("SPEC_CCY_LENGTH", f, "Ccy 項目は 3 バイト以上必要です。"));
            StringBuilder id = new StringBuilder(f.getStableId());
            indexes.forEach((k, v) -> id.append('[').append(k).append('=').append(v).append(']'));
            out.add(new ExpandedField(id.toString(), f, (int) position, f.getLength(), indexes));
        } catch (PositionExpression.ExpressionException | ArithmeticException e) {
            d.add(error("SPEC_EXPRESSION", f, e.getMessage()));
        }
    }

    private List<RawRange> validateCoverage(List<ExpandedField> fields, int expected, AppConfig.MappingConfig mapping, List<Diagnostic> d) {
        List<RawRange> gaps = new ArrayList<>();
        int cursor = 1;
        ExpandedField previous = null;
        for (ExpandedField f : fields) {
            if (f.getPosition() > cursor) gaps.add(new RawRange(cursor, f.getPosition() - cursor));
            if (previous != null && f.getPosition() <= previous.getEndPosition() && !allowedOverlap(previous, f, mapping))
                d.add(Diagnostic.error("SPEC_OVERLAP", "SPEC", "未宣言の範囲重複: " + previous.getInstanceId() + " と " + f.getInstanceId(), "sharedRanges で明示するか仕様を修正してください。"));
            cursor = Math.max(cursor, f.getEndPosition() + 1);
            if (previous == null || f.getEndPosition() > previous.getEndPosition()) previous = f;
        }
        if (cursor <= expected) gaps.add(new RawRange(cursor, expected - cursor + 1));
        return gaps;
    }

    private boolean allowedOverlap(ExpandedField a, ExpandedField b, AppConfig.MappingConfig mapping) {
        if (mapping == null || mapping.getSharedRanges() == null) return false;
        String pair1 = a.getDefinition().getStableId() + "|" + b.getDefinition().getStableId();
        String pair2 = b.getDefinition().getStableId() + "|" + a.getDefinition().getStableId();
        return mapping.getSharedRanges().contains(pair1) || mapping.getSharedRanges().contains(pair2);
    }

    private Diagnostic error(String code, SpecFieldDefinition f, String message) {
        SpecSource s = f.getSource();
        return new Diagnostic(Diagnostic.Severity.ERROR, code, "SPEC", message,
                "仕様セルまたは mapping 設定を修正してください。",
                new Diagnostic.SourceLocation(s.getFile(), s.getSheet(), s.getRow(), s.getColumn(), null, null));
    }

    private static final class Binding {
        final String id; final String variable; final Integer max; final String parent;
        Binding(String id, String variable, Integer max, String parent) { this.id=id; this.variable=variable; this.max=max; this.parent=parent; }
    }
}
