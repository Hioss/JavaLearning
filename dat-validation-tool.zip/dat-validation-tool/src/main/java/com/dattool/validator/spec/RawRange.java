package com.dattool.validator.spec;

/** 仕様フィールドで説明されないが比較対象に残すバイト範囲です。 */
public final class RawRange {
    private final int position;
    private final int length;
    public RawRange(int position, int length) { this.position = position; this.length = length; }
    public int getPosition() { return position; }
    public int getLength() { return length; }
    public int getEndPosition() { return position + length - 1; }
}
