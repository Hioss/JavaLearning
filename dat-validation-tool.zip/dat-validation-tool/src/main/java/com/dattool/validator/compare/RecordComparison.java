package com.dattool.validator.compare;

import com.dattool.validator.input.MessageKey;
import com.dattool.validator.input.ParsedRecord;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 配対または単側レコード。候補が曖昧な場合は candidates に全件を残します。 */
public final class RecordComparison {
    private final MessageKey key; private final PairStatus status; private final ParsedRecord current; private final ParsedRecord newer;
    private final List<ParsedRecord> currentCandidates; private final List<ParsedRecord> newCandidates; private final List<FieldComparison> fields;
    private final int firstDifference;
    public RecordComparison(MessageKey key,PairStatus status,ParsedRecord current,ParsedRecord newer,List<ParsedRecord> currentCandidates,List<ParsedRecord> newCandidates,List<FieldComparison> fields,int firstDifference){
        this.key=key;this.status=status;this.current=current;this.newer=newer;this.currentCandidates=immutable(currentCandidates);this.newCandidates=immutable(newCandidates);this.fields=Collections.unmodifiableList(new ArrayList<>(fields));this.firstDifference=firstDifference;
    }
    private static List<ParsedRecord> immutable(List<ParsedRecord> value){return Collections.unmodifiableList(new ArrayList<>(value));}
    public MessageKey getKey(){return key;} public PairStatus getStatus(){return status;} public ParsedRecord getCurrent(){return current;} public ParsedRecord getNewer(){return newer;}
    public List<ParsedRecord> getCurrentCandidates(){return currentCandidates;} public List<ParsedRecord> getNewCandidates(){return newCandidates;} public List<FieldComparison> getFields(){return fields;}
    public int getFirstDifference(){return firstDifference;}
}
