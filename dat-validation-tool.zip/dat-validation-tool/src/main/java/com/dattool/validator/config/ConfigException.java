package com.dattool.validator.config;

/** 設定ファイルの形式または値が不正な場合の例外です。 */
public class ConfigException extends Exception {
    public ConfigException(String message) { super(message); }
    public ConfigException(String message, Throwable cause) { super(message, cause); }
}
