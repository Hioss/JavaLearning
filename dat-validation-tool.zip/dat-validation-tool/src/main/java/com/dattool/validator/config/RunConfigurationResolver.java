package com.dattool.validator.config;

import com.dattool.validator.cli.CliArguments;

import java.nio.file.Path;

/** 設定ファイルと CLI の優先順位、相対パスの基準を適用します。 */
public final class RunConfigurationResolver {
    private RunConfigurationResolver() {}

    public static ResolvedRunConfiguration resolve(CliArguments cli, Path workingDirectory) throws ConfigException {
        Path configFile = resolve(cli.value("config"), workingDirectory);
        AppConfig config = configFile == null ? new AppConfig() : AppConfigLoader.load(configFile);
        Path configBase = configFile == null ? workingDirectory : configFile.getParent();
        AppConfig.PathsConfig p = config.getPaths() == null ? new AppConfig.PathsConfig() : config.getPaths();
        Path spec = choose(cli.value("spec"), p.getSpecification(), workingDirectory, configBase);
        Path current = choose(cli.value("current"), p.getCurrent(), workingDirectory, configBase);
        Path newer = choose(cli.value("new"), p.getNewer(), workingDirectory, configBase);
        Path output = choose(cli.value("output"), p.getOutput(), workingDirectory, configBase);
        Path bahSpec = choose(cli.value("bah-spec"), p.getBahSpecification(), workingDirectory, configBase);
        if (cli.value("message-id") != null) config.getSpecification().setMessageId(cli.value("message-id"));
        if (cli.value("bs-code") != null) config.getSpecification().setBsCode(cli.value("bs-code"));
        if (cli.value("sheet") != null) config.getSpecification().setSheet(cli.value("sheet"));
        if (cli.value("charset") != null) {
            config.getCurrentInput().setCharset(cli.value("charset"));
            config.getNewInput().setCharset(cli.value("charset"));
        }
        if (cli.hasFlag("overwrite")) config.getOutput().setOverwrite(true);
        return new ResolvedRunConfiguration(config, configFile, spec, current, newer, output, bahSpec);
    }

    private static Path choose(String cli, String configured, Path cliBase, Path configBase) {
        return cli != null ? resolve(cli, cliBase) : resolve(configured, configBase);
    }

    private static Path resolve(String value, Path base) {
        if (value == null || value.trim().isEmpty()) return null;
        Path p = Path.of(value);
        return (p.isAbsolute() ? p : base.resolve(p)).toAbsolutePath().normalize();
    }
}
