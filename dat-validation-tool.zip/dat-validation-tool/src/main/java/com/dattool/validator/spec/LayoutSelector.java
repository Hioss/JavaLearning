package com.dattool.validator.spec;

import java.util.List;
import java.util.stream.Collectors;

/** 複数候補から型識別キーで一意のレイアウトを選びます。 */
public final class LayoutSelector {
    private LayoutSelector() {}

    /** メッセージ ID、完全 BSCode、変体、任意 sheet で一意に選択します。 */
    public static CompiledLayout select(List<CompiledLayout> candidates, String messageId, String bsCode,
                                        String variant, String sheet) {
        List<CompiledLayout> matches = candidates.stream()
                .filter(x -> equals(messageId, x.getMessageId()))
                .filter(x -> equals(bsCode, x.getBsCode()))
                .filter(x -> variant == null || equals(variant, x.getVariant()))
                .filter(x -> sheet == null || equals(sheet, x.getSheet()))
                .collect(Collectors.toList());
        if (matches.isEmpty()) throw new IllegalArgumentException("指定したメッセージ ID と完全 BSCode のレイアウトがありません。");
        if (matches.size() != 1) throw new IllegalArgumentException("レイアウト候補が複数あります。variant または sheet を明示してください: " + matches.size());
        return matches.get(0);
    }

    private static boolean equals(String a, String b) { return a == null ? b == null : a.equals(b); }
}
