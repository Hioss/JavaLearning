package com.dattool.validator.model;

/** 比較の同一性、構造、完全性、説明能力を独立して表す結果です。 */
public final class ComparisonResult {
    public enum Equality { EQUAL, DIFFERENT, UNKNOWN }
    public enum Validity { VALID, INVALID, UNKNOWN }
    public enum Completeness { COMPLETE, INCOMPLETE, UNKNOWN }
    public enum Interpretation { FULL, BAH_RAW, PARTIAL, UNKNOWN }

    private final boolean dataPresent;
    private final Equality equality;
    private final Validity validity;
    private final Completeness completeness;
    private final Interpretation interpretation;
    private final boolean ambiguous;
    private final boolean configurationError;
    private final boolean internalError;

    private ComparisonResult(Builder b) {
        this.dataPresent = b.dataPresent;
        this.equality = b.equality;
        this.validity = b.validity;
        this.completeness = b.completeness;
        this.interpretation = b.interpretation;
        this.ambiguous = b.ambiguous;
        this.configurationError = b.configurationError;
        this.internalError = b.internalError;
    }

    public static Builder builder() { return new Builder(); }
    public boolean isDataPresent() { return dataPresent; }
    public Equality getEquality() { return equality; }
    public Validity getValidity() { return validity; }
    public Completeness getCompleteness() { return completeness; }
    public Interpretation getInterpretation() { return interpretation; }
    public boolean isAmbiguous() { return ambiguous; }
    public boolean isConfigurationError() { return configurationError; }
    public boolean isInternalError() { return internalError; }

    public static final class Builder {
        private boolean dataPresent;
        private Equality equality = Equality.UNKNOWN;
        private Validity validity = Validity.UNKNOWN;
        private Completeness completeness = Completeness.UNKNOWN;
        private Interpretation interpretation = Interpretation.UNKNOWN;
        private boolean ambiguous;
        private boolean configurationError;
        private boolean internalError;

        public Builder dataPresent(boolean value) { dataPresent = value; return this; }
        public Builder equality(Equality value) { equality = value; return this; }
        public Builder validity(Validity value) { validity = value; return this; }
        public Builder completeness(Completeness value) { completeness = value; return this; }
        public Builder interpretation(Interpretation value) { interpretation = value; return this; }
        public Builder ambiguous(boolean value) { ambiguous = value; return this; }
        public Builder configurationError(boolean value) { configurationError = value; return this; }
        public Builder internalError(boolean value) { internalError = value; return this; }
        public ComparisonResult build() { return new ComparisonResult(this); }
    }
}
