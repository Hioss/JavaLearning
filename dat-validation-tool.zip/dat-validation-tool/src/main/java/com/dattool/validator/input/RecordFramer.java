package com.dattool.validator.input;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** 原始バイトの LINE／SINGLE_MESSAGE 分帧です。 */
public final class RecordFramer {
    public FrameResult frame(Path file, AppConfig.InputConfig config, AppConfig.ResourceLimits limits) throws IOException {
        if (config.getFraming() == AppConfig.Framing.SINGLE_MESSAGE) return single(file, limits);
        return lines(file, config, limits);
    }

    private FrameResult single(Path file, AppConfig.ResourceLimits limits) throws IOException {
        long size = Files.size(file);
        List<Diagnostic> d = new ArrayList<>();
        if (size > limits.getMaxRecordBytes()) {
            d.add(diag("FRAME_RECORD_LIMIT", file, 1, 0, "単一レコードが上限を超えます: " + size));
            return new FrameResult(new ArrayList<>(), d, 0, size == 0 ? 0 : 1, "NONE");
        }
        byte[] bytes = Files.readAllBytes(file);
        List<FramedRecord> records = new ArrayList<>();
        if (bytes.length > 0) records.add(new FramedRecord(1, 0, bytes));
        return new FrameResult(records, d, 0, records.size(), "NONE");
    }

    private FrameResult lines(Path file, AppConfig.InputConfig config, AppConfig.ResourceLimits limits) throws IOException {
        List<FramedRecord> records = new ArrayList<>();
        List<Diagnostic> d = new ArrayList<>();
        ByteArrayOutputStream current = new ByteArrayOutputStream();
        long recordStart = 0, fileOffset = 0, recordNumber = 1, ignored = 0, physical = 0;
        String detected = null;
        boolean previousCr = false;
        boolean stoppedByLimit = false;
        try (InputStream in = Files.newInputStream(file)) {
            int read;
            while ((read = in.read()) >= 0) {
                byte b = (byte) read;
                current.write(b);
                boolean delimiter = false;
                int delimiterLength = 0;
                String kind = null;
                if (config.getLineSeparator() == AppConfig.LineSeparator.CRLF) {
                    if (previousCr && b == 0x0A) { delimiter=true; delimiterLength=2; kind="CRLF"; }
                } else if (config.getLineSeparator() == AppConfig.LineSeparator.LF) {
                    if (b == 0x0A) { delimiter=true; delimiterLength=1; kind="LF"; }
                } else if (config.getLineSeparator() == AppConfig.LineSeparator.AUTO || config.getLineSeparator() == AppConfig.LineSeparator.MIXED) {
                    if (b == 0x0A) { delimiter=true; delimiterLength=previousCr ? 2 : 1; kind=previousCr ? "CRLF" : "LF"; }
                }
                fileOffset++;
                if (delimiter) {
                    byte[] all = current.toByteArray();
                    byte[] payload = java.util.Arrays.copyOf(all, all.length - delimiterLength);
                    physical++;
                    if (detected == null) detected = kind;
                    else if (!detected.equals(kind) && config.getLineSeparator() == AppConfig.LineSeparator.AUTO)
                        d.add(diag("FRAME_MIXED_SEPARATOR", file, recordNumber, recordStart,
                                "AUTO で混在改行を検出しました: " + detected + " と " + kind));
                    if (payload.length == 0 && config.isIgnoreEmptyLines()) ignored++;
                    else records.add(new FramedRecord(recordNumber, recordStart, payload));
                    if (payload.length == 0 && !config.isIgnoreEmptyLines())
                        d.add(diag("FRAME_EMPTY_RECORD", file, recordNumber, recordStart, "ゼロ長行は既定ではエラーです。"));
                    if (records.size() > limits.getMaxRecordsInMemory()) {
                        d.add(diag("FRAME_RECORD_COUNT_LIMIT", file, recordNumber, recordStart,
                                "レコード数がメモリ上限を超えました: " + limits.getMaxRecordsInMemory()));
                        stoppedByLimit = true;
                        break;
                    }
                    current.reset(); recordNumber++; recordStart=fileOffset;
                } else if (current.size() > limits.getMaxRecordBytes()) {
                    d.add(diag("FRAME_RECORD_LIMIT", file, recordNumber, recordStart,
                            "レコード長が上限を超えました: " + limits.getMaxRecordBytes()));
                    stoppedByLimit = true;
                    break;
                }
                previousCr = b == 0x0D;
            }
        }
        if (!stoppedByLimit && current.size() > 0) {
            physical++;
            records.add(new FramedRecord(recordNumber, recordStart, current.toByteArray()));
        }
        return new FrameResult(records, d, ignored, physical, detected == null ? "NONE" : detected);
    }

    private Diagnostic diag(String code, Path file, long record, long offset, String message) {
        return new Diagnostic(Diagnostic.Severity.ERROR, code, "FRAMING", message,
                "record framing と改行設定を確認してください。", new Diagnostic.SourceLocation(file, null, null, null, record, offset));
    }
}
