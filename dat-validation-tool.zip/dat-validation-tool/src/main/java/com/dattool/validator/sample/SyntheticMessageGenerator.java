package com.dattool.validator.sample;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

/** 公開テスト用 Shift_JIS DAT を決定的に生成します。実運用 BAH の既定値ではありません。 */
public final class SyntheticMessageGenerator {
    private static final Charset SJIS=Charset.forName("Shift_JIS");
    private static final byte[] PREFIX="MQHEAD08".getBytes(SJIS);
    private SyntheticMessageGenerator() {}
    public static void main(String[] args) throws Exception {
        Path out=args.length==0?Paths.get("examples","synthetic","messages"):Paths.get(args[0]);
        Files.createDirectories(out);
        byte[] one=normalBody("日本","ｱｲｳｴ","001");
        byte[] two=normalBody("東京","ｶｷｸｹ","002");
        byte[] changed=normalBody("東京","ｶｷｸｹ","009");
        byte[] r1=message96("synt.001.001.01","99-99000001-00001",doc(1),one,PREFIX);
        byte[] r2=message96("synt.001.001.01","99-99000001-00001",doc(2),two,PREFIX);
        byte[] r2Changed=message96("synt.001.001.01","99-99000001-00001",doc(2),changed,PREFIX);
        byte[] other=message96("synt.999.001.01","99-99000999-00001",doc(3),new byte[]{'X'},PREFIX);
        writeLines(out.resolve("current.dat"),r1,r2);
        writeLines(out.resolve("new.dat"),r2Changed,r1);
        writeLines(out.resolve("new-equal-reordered.dat"),r2,r1);
        writeLines(out.resolve("mixed-types.dat"),r1,other);
        byte[] invalid=r1.clone();invalid[invalid.length-1]=(byte)0x82;writeLines(out.resolve("invalid-shift-jis.dat"),invalid);
        writeLines(out.resolve("prefix.dat"),message96("synt.001.001.01","99-99000001-00001",doc(4),one,"PREFIX".getBytes(SJIS)));
        writeLines(out.resolve("marker.dat"),message96("synt.001.001.01","99-99000001-00001",doc(5),one,"xxMARK".getBytes(SJIS)));
        byte[] repeat=repeatBody(false),repeatChanged=repeatBody(true);
        writeLines(out.resolve("repeat-current.dat"),message96("synt.002.001.01","99-99000002-00001",doc(6),repeat,PREFIX));
        writeLines(out.resolve("repeat-new.dat"),message96("synt.002.001.01","99-99000002-00001",doc(6),repeatChanged,PREFIX));
        System.out.println("SYNTHETIC DAT generated: "+out.toAbsolutePath());
    }
    private static byte[] normalBody(String a,String b,String c){byte[] body=spaces(12);put(body,0,4,a);put(body,4,4,b);put(body,9,3,c);return body;}
    private static byte[] repeatBody(boolean changeLast){
        byte[] body=spaces(788);put(body,0,4,"0001");put(body,4,4,"JPY ");put(body,8,11,"12345678901");
        put(body,19,8,"00000100");put(body,27,4,"TEST");put(body,31,7,"HEADER1");
        for(int a=1;a<=30;a++){int start=38+25*(a-1);put(body,start,12,String.format("ISIN%08d",a));put(body,start+12,9,String.format("%09d",a));put(body,start+21,4,"OK  ");}
        if(changeLast)put(body,38+25*29,12,"ISIN99999999");return body;
    }
    private static byte[] message96(String msg,String bs,String document,byte[] body,byte[] prefix){
        byte[] bah=spaces(96);put(bah,0,11,"SENDER");put(bah,11,11,"RECEIVER");put(bah,22,35,document);put(bah,57,15,msg);put(bah,72,17,bs);
        ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(prefix,0,prefix.length);out.write(bah,0,bah.length);out.write(body,0,body.length);return out.toByteArray();
    }
    private static String doc(int value){return String.format("%035d",value);}
    private static byte[] spaces(int length){byte[] b=new byte[length];Arrays.fill(b,(byte)' ');return b;}
    private static void put(byte[] target,int offset,int length,String value){byte[] b=value.getBytes(SJIS);if(b.length>length)throw new IllegalArgumentException(value);System.arraycopy(b,0,target,offset,b.length);}
    private static void writeLines(Path path,byte[]...records)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();for(int i=0;i<records.length;i++){out.write(records[i]);if(i+1<records.length)out.write(new byte[]{'\r','\n'});}Files.write(path,out.toByteArray());}
}
