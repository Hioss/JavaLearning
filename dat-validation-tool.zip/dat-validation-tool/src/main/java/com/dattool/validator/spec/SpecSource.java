package com.dattool.validator.spec;

import java.nio.file.Path;

/** 仕様定義の元ファイルと実セル座標です。 */
public final class SpecSource {
    private final Path file;
    private final String sheet;
    private final int row;
    private final int column;
    public SpecSource(Path file, String sheet, int row, int column) {
        this.file = file; this.sheet = sheet; this.row = row; this.column = column;
    }
    public Path getFile() { return file; }
    public String getSheet() { return sheet; }
    public int getRow() { return row; }
    public int getColumn() { return column; }
    public String display() { return file + "!" + sheet + "!R" + row + "C" + column; }
}
