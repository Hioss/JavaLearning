package com.dattool.validator.gui;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.ResolvedRunConfiguration;
import java.nio.file.Path;

/** 画面文字列を CLI と同じ正規化済み実行要求へ変換します。 */
public final class GuiRunRequestFactory {
    private GuiRunRequestFactory() {}
    public static ResolvedRunConfiguration create(AppConfig config,Path configFile,String specification,String current,String newer,String output){Path base=Path.of("").toAbsolutePath().normalize();return new ResolvedRunConfiguration(config,configFile,resolve(specification,base),resolve(current,base),resolve(newer,base),resolve(output,base),resolve(config.getPaths().getBahSpecification(),configFile==null?base:configFile.toAbsolutePath().getParent()));}
    private static Path resolve(String value,Path base){if(value==null||value.trim().isEmpty())return null;Path p=Path.of(value.trim());return (p.isAbsolute()?p:base.resolve(p)).toAbsolutePath().normalize();}
}
