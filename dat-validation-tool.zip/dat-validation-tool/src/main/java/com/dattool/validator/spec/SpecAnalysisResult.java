package com.dattool.validator.spec;

import com.dattool.validator.model.Diagnostic;

import java.util.Collections;
import java.util.List;

/** 仕様候補と、候補を選ぶための診断を返します。 */
public final class SpecAnalysisResult {
    private final List<CompiledLayout> candidates;
    private final List<Diagnostic> diagnostics;
    public SpecAnalysisResult(List<CompiledLayout> candidates, List<Diagnostic> diagnostics) {
        this.candidates = Collections.unmodifiableList(candidates);
        this.diagnostics = Collections.unmodifiableList(diagnostics);
    }
    public List<CompiledLayout> getCandidates() { return candidates; }
    public List<Diagnostic> getDiagnostics() { return diagnostics; }
    public boolean hasErrors() { return diagnostics.stream().anyMatch(d -> d.getSeverity() == Diagnostic.Severity.ERROR); }
}
