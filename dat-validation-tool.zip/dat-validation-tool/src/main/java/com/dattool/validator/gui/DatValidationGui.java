package com.dattool.validator.gui;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Windows app-image と JAR classpath から起動できる Swing 入口です。 */
public final class DatValidationGui {
    private DatValidationGui() {}
    public static void main(String[] args){if(args.length>0&&"--acceptance-smoke".equals(args[0])){GuiAcceptanceSmoke.run(args);return;}SwingUtilities.invokeLater(()->{try{setupLookAndFeel();new MainFrame().setVisible(true);}catch(Exception e){javax.swing.JOptionPane.showMessageDialog(null,"起動に失敗しました: "+e.getMessage(),"DAT 比較",javax.swing.JOptionPane.ERROR_MESSAGE);}});}
    static void setupLookAndFeel(){FlatLightLaf.setup();UIManager.put("defaultFont",new java.awt.Font("Yu Gothic UI",java.awt.Font.PLAIN,13));}
}
