package com.dattool.validator.spec;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;
import org.apache.poi.poifs.filesystem.FileMagic;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/** STPCOM の表頭候補を検出し、HSSF/XSSF を同じモデルへ変換します。 */
public final class WorkbookSpecAnalyzer {
    private static final Map<String, Set<String>> HEADER_ALIASES = aliases();
    private final LayoutCompiler compiler = new LayoutCompiler();

    public SpecAnalysisResult analyze(Path path, AppConfig config) {
        List<Diagnostic> diagnostics = new ArrayList<>();
        List<CompiledLayout> candidates = new ArrayList<>();
        if (path == null || !Files.isRegularFile(path) || !Files.isReadable(path)) {
            diagnostics.add(Diagnostic.error("SPEC_FILE", "SPEC", "仕様書を読み取れません: " + path, "読み取り可能な .xls または .xlsx を指定してください。"));
            return new SpecAnalysisResult(candidates, diagnostics);
        }
        try {
            validateMagic(path);
            try (InputStream in = Files.newInputStream(path); Workbook workbook = WorkbookFactory.create(in)) {
                FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
                AppConfig.SpecificationConfig sc = config.getSpecification();
                for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                    Sheet sheet = workbook.getSheetAt(i);
                    if (sc.getSheet() != null && !sc.getSheet().equals(sheet.getSheetName())) continue;
                    HeaderMapping header = sc.getMapping() != null && sc.getMapping().getColumns() != null
                            && !sc.getMapping().getColumns().isEmpty()
                            ? manualHeader(sc.getMapping()) : detectHeader(sheet, evaluator, diagnostics, path);
                    if (header == null) continue;
                    Metadata metadata = readMetadata(sheet, evaluator, diagnostics, path);
                    if (sc.getMessageId() != null) metadata.messageId = sc.getMessageId();
                    if (sc.getBsCode() != null) metadata.bsCode = sc.getBsCode();
                    if (sc.getVariant() != null) metadata.variant = sc.getVariant();
                    if (sc.getCategory() != null) metadata.category = sc.getCategory();
                    if (sc.getSnapshot() != null) metadata.snapshot = sc.getSnapshot();
                    List<SpecFieldDefinition> definitions = extract(path, sheet, header, evaluator, sc.getMapping(), diagnostics);
                    if (definitions.isEmpty()) {
                        diagnostics.add(error("SPEC_NO_FIELDS", path, sheet.getSheetName(), header.dataStart + 1, 1,
                                "位置とサイズを持つ固定長項目がありません。"));
                        continue;
                    }
                    CompiledLayout layout = compiler.compile(metadata.messageId, metadata.bsCode, metadata.variant,
                            metadata.category, metadata.snapshot, metadata.role, sheet.getSheetName(), definitions,
                            sc.getMapping(), config.getLimits(), diagnostics);
                    candidates.add(layout);
                }
                if (sc.getSheet() != null && workbook.getSheet(sc.getSheet()) == null)
                    diagnostics.add(Diagnostic.error("SPEC_SHEET", "SPEC", "指定シートがありません: " + sc.getSheet(), "実在するシート名を指定してください。"));
            }
            detectConflicts(candidates, diagnostics);
            if (candidates.isEmpty() && diagnostics.stream().noneMatch(d -> d.getSeverity() == Diagnostic.Severity.ERROR))
                diagnostics.add(Diagnostic.error("SPEC_HEADER_NOT_FOUND", "SPEC", "STPCOM／固定長データ情報の表頭候補を特定できません。",
                        "mapping.columns と行範囲を JSON に保存して指定してください。"));
        } catch (Exception e) {
            diagnostics.add(Diagnostic.error("SPEC_READ", "SPEC", "仕様書の読取に失敗しました: " + path + " (" + e.getMessage() + ")",
                    "ファイル形式、拡張子、破損、暗号化を確認してください。"));
        }
        return new SpecAnalysisResult(candidates, diagnostics);
    }

    private void validateMagic(Path path) throws IOException {
        FileMagic magic;
        try (InputStream raw = Files.newInputStream(path); InputStream in = FileMagic.prepareToCheckMagic(new BufferedInputStream(raw))) {
            magic = FileMagic.valueOf(in);
        }
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.endsWith(".xls") && magic != FileMagic.OLE2)
            throw new IOException(".xls 拡張子ですが内部形式が OLE2/HSSF ではありません: " + magic);
        if (name.endsWith(".xlsx") && magic != FileMagic.OOXML)
            throw new IOException(".xlsx 拡張子ですが内部形式が OOXML/XSSF ではありません: " + magic);
        if (!name.endsWith(".xls") && !name.endsWith(".xlsx")) throw new IOException("拡張子は .xls または .xlsx にしてください。");
    }

    private HeaderMapping manualHeader(AppConfig.MappingConfig mapping) {
        int headerEnd = value(mapping.getHeaderEndRow(), value(mapping.getHeaderStartRow(), 1)) - 1;
        int dataStart = value(mapping.getDataStartRow(), headerEnd + 2) - 1;
        int dataEnd = value(mapping.getDataEndRow(), Integer.MAX_VALUE) - 1;
        Map<String, Integer> columns = new LinkedHashMap<>();
        mapping.getColumns().forEach((k, v) -> columns.put(k, v - 1));
        return new HeaderMapping(headerEnd, dataStart, dataEnd, columns);
    }

    private HeaderMapping detectHeader(Sheet sheet, FormulaEvaluator evaluator, List<Diagnostic> diagnostics, Path path) {
        HeaderMapping best = null;
        int bestScore = -1;
        boolean marker = containsMarker(sheet, evaluator);
        if (!marker) return null;
        for (int r = sheet.getFirstRowNum(); r <= sheet.getLastRowNum(); r++) {
            int maxCol = maxColumn(sheet, Math.max(sheet.getFirstRowNum(), r - 2), r);
            Map<String, Integer> columns = new LinkedHashMap<>();
            for (int c = 0; c < maxCol; c++) {
                String combined = "";
                for (int hr = Math.max(sheet.getFirstRowNum(), r - 2); hr <= r; hr++) combined += normalized(cellText(sheet, hr, c, evaluator, null, null));
                for (Map.Entry<String, Set<String>> e : HEADER_ALIASES.entrySet()) {
                    if (!columns.containsKey(e.getKey()) && e.getValue().contains(combined)) columns.put(e.getKey(), c);
                    else if (!columns.containsKey(e.getKey())) {
                        String current = normalized(cellText(sheet, r, c, evaluator, null, null));
                        if (e.getValue().contains(current)) columns.put(e.getKey(), c);
                    }
                }
            }
            if (!columns.containsKey("position") || !columns.containsKey("size")) continue;
            if (!columns.containsKey("itemNumber") && !columns.containsKey("itemName") && !columns.containsKey("path")) continue;
            int score = columns.size();
            if (score > bestScore) {
                best = new HeaderMapping(r, r + 1, Integer.MAX_VALUE, columns);
                bestScore = score;
            } else if (score == bestScore && best != null && !best.columns.equals(columns)) {
                diagnostics.add(error("SPEC_HEADER_AMBIGUOUS", path, sheet.getSheetName(), r + 1, 1,
                        "同点の表頭候補があります。手動 mapping を指定してください。"));
            }
        }
        return best;
    }

    private boolean containsMarker(Sheet sheet, FormulaEvaluator evaluator) {
        int limit = Math.min(sheet.getLastRowNum(), sheet.getFirstRowNum() + 80);
        for (int r = sheet.getFirstRowNum(); r <= limit; r++) {
            Row row = sheet.getRow(r); if (row == null) continue;
            for (int c = row.getFirstCellNum() < 0 ? 0 : row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
                String value = normalized(cellText(sheet, r, c, evaluator, null, null));
                if (value.contains("stpcom") || value.contains("固定長データ情報")) return true;
            }
        }
        return false;
    }

    private Metadata readMetadata(Sheet sheet, FormulaEvaluator evaluator, List<Diagnostic> d, Path path) {
        Metadata m = new Metadata();
        int limit = Math.min(sheet.getLastRowNum(), sheet.getFirstRowNum() + 40);
        for (int r = sheet.getFirstRowNum(); r <= limit; r++) {
            Row row = sheet.getRow(r); if (row == null) continue;
            for (int c = 0; c < Math.max(0, row.getLastCellNum()); c++) {
                String label = normalized(cellText(sheet, r, c, evaluator, d, path));
                String next = nextValue(sheet, r, c + 1, Math.max(c + 1, row.getLastCellNum()), evaluator, d, path);
                if (label.equals("メッセージid") || label.equals("messageid")) m.messageId = next;
                else if (label.equals("bscode")) m.bsCode = next;
                else if (label.equals("役割") || label.equals("role")) m.role = next;
                else if (label.equals("レイアウト変体") || label.equals("レイアウトバリアント") || label.equals("variant")) m.variant = next;
                else if (label.equals("業務分類") || label.equals("category")) m.category = next;
                else if (label.equals("仕様スナップショット") || label.equals("snapshot")) m.snapshot = next;
            }
        }
        return m;
    }

    private List<SpecFieldDefinition> extract(Path path, Sheet sheet, HeaderMapping h, FormulaEvaluator evaluator,
                                               AppConfig.MappingConfig mapping, List<Diagnostic> d) {
        List<SpecFieldDefinition> fields = new ArrayList<>();
        boolean allowCached = mapping != null && mapping.isAllowCachedFormulaResults();
        int end = Math.min(sheet.getLastRowNum(), h.dataEnd);
        for (int r = h.dataStart; r <= end; r++) {
            String position = value(sheet, r, h, "position", evaluator, d, path, allowCached);
            String sizeText = value(sheet, r, h, "size", evaluator, d, path, allowCached);
            if (blank(position) && blank(sizeText)) continue;
            int sourceColumn = h.columns.getOrDefault("position", 0) + 1;
            if (blank(position) || blank(sizeText)) {
                d.add(error("SPEC_FIELD_INCOMPLETE", path, sheet.getSheetName(), r + 1, sourceColumn,
                        "位置とサイズの両方が必要です。"));
                continue;
            }
            Integer length = integer(sizeText);
            if (length == null || length < 1) {
                d.add(error("SPEC_LENGTH", path, sheet.getSheetName(), r + 1, h.columns.get("size") + 1,
                        "サイズは正の整数である必要があります: " + sizeText));
                continue;
            }
            String item = value(sheet, r, h, "itemNumber", evaluator, d, path, allowCached);
            String name = value(sheet, r, h, "itemName", evaluator, d, path, allowCached);
            String fieldPath = value(sheet, r, h, "path", evaluator, d, path, allowCached);
            if (blank(name)) name = !blank(fieldPath) ? fieldPath : (!blank(item) ? "項番 " + item : "無名項目 R" + (r + 1));
            String repeatId = nullIfBlank(value(sheet, r, h, "repeatId", evaluator, d, path, allowCached));
            Integer maxCount = integer(value(sheet, r, h, "maxCount", evaluator, d, path, allowCached));
            String repeatVariable = nullIfBlank(value(sheet, r, h, "repeatVariable", evaluator, d, path, allowCached));
            String parentRepeatId = nullIfBlank(value(sheet, r, h, "parentRepeatId", evaluator, d, path, allowCached));
            String ccy = value(sheet, r, h, "ccy", evaluator, d, path, allowCached);
            Cell posCell = getCell(sheet, r, h.columns.get("position"));
            String kind = posCell != null && posCell.getCellType() == CellType.FORMULA ? "FORMULA" :
                    posCell != null && posCell.getCellType() == CellType.NUMERIC ? "NUMBER" : "TEXT";
            String stable = "BODY:" + sheet.getSheetName() + ":R" + (r + 1) + ":" + (!blank(item) ? item : name);
            fields.add(new SpecFieldDefinition(stable, item, name, fieldPath,
                    value(sheet, r, h, "setting", evaluator, d, path, allowCached), position.trim(), length, repeatId, maxCount,
                    repeatVariable, parentRepeatId, isCircle(ccy), value(sheet, r, h, "attribute", evaluator, d, path, allowCached),
                    value(sheet, r, h, "notes", evaluator, d, path, allowCached), value(sheet, r, h, "required", evaluator, d, path, allowCached),
                    kind, new SpecSource(path, sheet.getSheetName(), r + 1, sourceColumn)));
        }
        return fields;
    }

    private String value(Sheet sheet, int row, HeaderMapping h, String key, FormulaEvaluator evaluator,
                         List<Diagnostic> diagnostics, Path path, boolean allowCached) {
        Integer col = h.columns.get(key);
        return col == null ? null : cellText(sheet, row, col, evaluator, diagnostics, path, allowCached);
    }

    private String cellText(Sheet sheet, int rowIndex, int columnIndex, FormulaEvaluator evaluator,
                            List<Diagnostic> diagnostics, Path path) {
        return cellText(sheet, rowIndex, columnIndex, evaluator, diagnostics, path, false);
    }

    private String cellText(Sheet sheet, int rowIndex, int columnIndex, FormulaEvaluator evaluator,
                            List<Diagnostic> diagnostics, Path path, boolean allowCached) {
        Cell cell = getCell(sheet, rowIndex, columnIndex);
        if (cell == null) return null;
        DataFormatter formatter = new DataFormatter(Locale.JAPAN, false);
        if (cell.getCellType() != CellType.FORMULA) return formatter.formatCellValue(cell);
        String formula = cell.getCellFormula();
        if (formula.matches("(?is).*(\\[|\\]|WEBSERVICE\\s*\\(|HYPERLINK\\s*\\().*")) {
            if (diagnostics != null) diagnostics.add(error("SPEC_EXTERNAL_FORMULA", path, sheet.getSheetName(), rowIndex + 1, columnIndex + 1,
                    "外部参照または外部機能を含む数式は評価しません: " + formula));
            return null;
        }
        try {
            CellValue cv = evaluator.evaluate(cell);
            if (cv == null) throw new IllegalStateException("評価値がありません");
            switch (cv.getCellType()) {
                case STRING: return cv.getStringValue();
                case NUMERIC: return numeric(cv.getNumberValue());
                case BOOLEAN: return Boolean.toString(cv.getBooleanValue());
                case BLANK: return "";
                case ERROR: throw new IllegalStateException("数式エラー " + cv.getErrorValue());
                default: throw new IllegalStateException("未対応の評価型");
            }
        } catch (RuntimeException ex) {
            if (allowCached) {
                String cached = cachedFormulaValue(cell);
                if (cached != null) {
                    if (diagnostics != null) diagnostics.add(new Diagnostic(Diagnostic.Severity.WARNING, "SPEC_FORMULA_CACHE", "SPEC",
                            "数式評価に失敗したため明示設定によりキャッシュ値を使用しました: " + formula,
                            "キャッシュが現行仕様と一致するか確認してください。",
                            new Diagnostic.SourceLocation(path, sheet.getSheetName(), rowIndex + 1, columnIndex + 1, null, null)));
                    return cached;
                }
            }
            if (diagnostics != null) diagnostics.add(error("SPEC_FORMULA_EVAL", path, sheet.getSheetName(), rowIndex + 1, columnIndex + 1,
                    "数式を評価できません: " + formula + " (" + ex.getMessage() + ")"));
            return null;
        }
    }

    private String cachedFormulaValue(Cell cell) {
        try {
            switch (cell.getCachedFormulaResultType()) {
                case STRING: return cell.getStringCellValue();
                case NUMERIC: return numeric(cell.getNumericCellValue());
                case BOOLEAN: return Boolean.toString(cell.getBooleanCellValue());
                case BLANK: return "";
                default: return null;
            }
        } catch (RuntimeException e) {
            return null;
        }
    }

    private Cell getCell(Sheet sheet, int row, int col) {
        if (row < 0 || col < 0) return null;
        for (CellRangeAddress range : sheet.getMergedRegions()) if (range.isInRange(row, col)) {
            Row top = sheet.getRow(range.getFirstRow());
            return top == null ? null : top.getCell(range.getFirstColumn(), Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
        }
        Row r = sheet.getRow(row);
        return r == null ? null : r.getCell(col, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
    }

    private String nextValue(Sheet sheet, int row, int from, int to, FormulaEvaluator e, List<Diagnostic> d, Path path) {
        for (int c = from; c < to; c++) { String v = cellText(sheet, row, c, e, d, path); if (!blank(v)) return v; }
        return null;
    }

    private int maxColumn(Sheet sheet, int from, int to) {
        int max = 0;
        for (int r = from; r <= to; r++) { Row row = sheet.getRow(r); if (row != null) max = Math.max(max, row.getLastCellNum()); }
        return max;
    }

    private void detectConflicts(List<CompiledLayout> layouts, List<Diagnostic> d) {
        Map<String, String> signatures = new HashMap<>();
        for (CompiledLayout l : layouts) {
            String signature = l.getFields().stream().map(f -> f.getPosition() + ":" + f.getLength()).collect(Collectors.joining(","));
            String old = signatures.putIfAbsent(l.typeKey(), signature);
            if (old != null && !old.equals(signature)) d.add(Diagnostic.error("SPEC_VARIANT_CONFLICT", "SPEC",
                    "同じメッセージ ID／完全 BSCode／変体に異なる配置があります: " + l.typeKey(), "sheet または variant を明示してください。"));
        }
    }

    private static Map<String, Set<String>> aliases() {
        Map<String, Set<String>> a = new LinkedHashMap<>();
        put(a, "itemNumber", "固定長項番", "stpcom項番", "項番");
        put(a, "position", "位置", "バイト位置", "開始位置");
        put(a, "size", "サイズ", "バイト数", "長さ");
        put(a, "ccy", "ccy", "通貨");
        put(a, "repeatId", "繰返し情報id", "繰返しid", "繰り返しid");
        put(a, "maxCount", "最大回数", "最大繰返し回数");
        put(a, "repeatVariable", "繰返し変数", "変数");
        put(a, "parentRepeatId", "親繰返しid", "親id");
        put(a, "attribute", "属性");
        put(a, "notes", "備考");
        put(a, "required", "必須区分", "必須");
        put(a, "itemName", "項目名", "jasdec項目名", "利用項目名");
        put(a, "path", "パス", "階層", "xmlpath");
        put(a, "setting", "設定内容", "設定値");
        return Collections.unmodifiableMap(a);
    }
    private static void put(Map<String, Set<String>> map, String key, String... values) {
        map.put(key, Arrays.stream(values).map(WorkbookSpecAnalyzer::normalized).collect(Collectors.toSet()));
    }
    private static String normalized(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value, Normalizer.Form.NFKC).replaceAll("[\\s　]+", "").toLowerCase(Locale.ROOT);
    }
    private static boolean blank(String v) { return v == null || v.trim().isEmpty(); }
    private static String nullIfBlank(String v) { return blank(v) ? null : v.trim(); }
    private static Integer integer(String text) {
        if (blank(text)) return null;
        try { return Integer.valueOf(text.trim()); } catch (NumberFormatException e) { return null; }
    }
    private static String numeric(double n) { long l = (long) n; return n == l ? Long.toString(l) : Double.toString(n); }
    private static boolean isCircle(String s) { String n = normalized(s); return "○".equals(n) || "◯".equals(n) || "o".equals(n); }
    private static int value(Integer actual, int fallback) { return actual == null ? fallback : actual; }
    private Diagnostic error(String code, Path path, String sheet, int row, int col, String message) {
        return new Diagnostic(Diagnostic.Severity.ERROR, code, "SPEC", message, "仕様セルまたは mapping 設定を確認してください。",
                new Diagnostic.SourceLocation(path, sheet, row, col, null, null));
    }

    private static final class HeaderMapping {
        final int headerEnd; final int dataStart; final int dataEnd; final Map<String, Integer> columns;
        HeaderMapping(int headerEnd, int dataStart, int dataEnd, Map<String, Integer> columns) {
            this.headerEnd=headerEnd; this.dataStart=dataStart; this.dataEnd=dataEnd; this.columns=columns;
        }
    }
    private static final class Metadata {
        String messageId; String bsCode; String variant; String category; String snapshot; String role = "BODY";
    }
}
