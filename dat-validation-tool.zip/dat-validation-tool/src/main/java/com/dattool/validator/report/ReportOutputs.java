package com.dattool.validator.report;

import java.nio.file.Path;

public final class ReportOutputs {
    private final Path report; private final Path manifest; private final Path assetsDirectory;
    public ReportOutputs(Path report,Path manifest,Path assetsDirectory){this.report=report;this.manifest=manifest;this.assetsDirectory=assetsDirectory;}
    public Path getReport(){return report;} public Path getManifest(){return manifest;} public Path getAssetsDirectory(){return assetsDirectory;}
}
