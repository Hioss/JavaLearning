package com.dattool.validator.service;

import com.dattool.validator.model.Diagnostic;

/** タスク単位のログ受け口です。 */
@FunctionalInterface
public interface TaskLog {
    void accept(Diagnostic diagnostic);
}
