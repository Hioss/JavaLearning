package com.dattool.validator.compare;

import com.dattool.validator.input.InputSideResult;
import com.dattool.validator.model.ComparisonResult;
import com.dattool.validator.model.Diagnostic;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** レポートが再解析なしで直列化できる完全比較モデルです。 */
public final class ComparisonRunResult {
    private final ComparisonResult result; private final ComparisonSummary summary; private final InputSideResult currentInput; private final InputSideResult newInput;
    private final List<RecordComparison> records; private final List<Diagnostic> diagnostics;
    public ComparisonRunResult(ComparisonResult result,ComparisonSummary summary,InputSideResult currentInput,InputSideResult newInput,List<RecordComparison> records,List<Diagnostic> diagnostics){this.result=result;this.summary=summary;this.currentInput=currentInput;this.newInput=newInput;this.records=Collections.unmodifiableList(new ArrayList<>(records));this.diagnostics=Collections.unmodifiableList(new ArrayList<>(diagnostics));}
    public ComparisonResult getResult(){return result;} public ComparisonSummary getSummary(){return summary;} public InputSideResult getCurrentInput(){return currentInput;} public InputSideResult getNewInput(){return newInput;}
    public List<RecordComparison> getRecords(){return records;} public List<Diagnostic> getDiagnostics(){return diagnostics;}
}
