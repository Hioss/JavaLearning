package com.dattool.validator.input;

import com.dattool.validator.model.Diagnostic;
import java.util.Collections;
import java.util.List;

/** 一方の入力処理結果です。 */
public final class InputSideResult {
    private final InputStatistics statistics; private final List<ParsedRecord> records; private final List<Diagnostic> diagnostics;
    private final String detectedSeparator;
    public InputSideResult(InputStatistics statistics,List<ParsedRecord> records,List<Diagnostic> diagnostics,String separator){
        this.statistics=statistics;this.records=Collections.unmodifiableList(records);this.diagnostics=Collections.unmodifiableList(diagnostics);this.detectedSeparator=separator;
    }
    public InputStatistics getStatistics(){return statistics;} public List<ParsedRecord> getRecords(){return records;}
    public List<Diagnostic> getDiagnostics(){return diagnostics;} public String getDetectedSeparator(){return detectedSeparator;}
    public boolean isComplete(){return diagnostics.stream().noneMatch(d->d.getSeverity()==Diagnostic.Severity.ERROR)&&statistics.isConserved();}
}
