package com.dattool.validator.input;

import java.util.Arrays;

/** BAH または本文フィールドの原始値と三種類のオフセットです。 */
public final class ByteFieldValue {
    private final String instanceId; private final String role; private final String name;
    private final int position; private final int length; private final long recordOffset; private final long fileOffset;
    private final byte[] bytes; private final DecodedBytes decoded;
    public ByteFieldValue(String instanceId,String role,String name,int position,int length,long recordOffset,long fileOffset,byte[] bytes,DecodedBytes decoded){
        this.instanceId=instanceId;this.role=role;this.name=name;this.position=position;this.length=length;
        this.recordOffset=recordOffset;this.fileOffset=fileOffset;this.bytes=Arrays.copyOf(bytes,bytes.length);this.decoded=decoded;
    }
    public String getInstanceId(){return instanceId;} public String getRole(){return role;} public String getName(){return name;}
    public int getPosition(){return position;} public int getLength(){return length;} public long getRecordOffset(){return recordOffset;}
    public long getFileOffset(){return fileOffset;} public byte[] getBytes(){return Arrays.copyOf(bytes,bytes.length);} public DecodedBytes getDecoded(){return decoded;}
}
