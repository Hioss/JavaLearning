package com.dattool.validator.input;

/** R10 の数量保存式を表す片側統計です。 */
public final class InputStatistics {
    long totalRecords; long selectedRecords; long otherTypeRecords; long recognitionFailures;
    long parsedSelectedRecords; long failedSelectedRecords; long ignoredEmptyRecords; long physicalRecords;
    public long getTotalRecords(){return totalRecords;} public long getSelectedRecords(){return selectedRecords;}
    public long getOtherTypeRecords(){return otherTypeRecords;} public long getRecognitionFailures(){return recognitionFailures;}
    public long getParsedSelectedRecords(){return parsedSelectedRecords;} public long getFailedSelectedRecords(){return failedSelectedRecords;}
    public long getIgnoredEmptyRecords(){return ignoredEmptyRecords;} public long getPhysicalRecords(){return physicalRecords;}
    public boolean isConserved(){return totalRecords==selectedRecords+otherTypeRecords+recognitionFailures&&selectedRecords==parsedSelectedRecords+failedSelectedRecords;}
}
