package com.dattool.validator.compare;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.input.ByteFieldValue;
import com.dattool.validator.input.InputSideResult;
import com.dattool.validator.input.MessageKey;
import com.dattool.validator.input.ParsedRecord;
import com.dattool.validator.model.ComparisonResult;
import com.dattool.validator.model.Diagnostic;
import com.dattool.validator.util.ByteText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** R11 の重複キー規則と R12 の全バイト比較を決定的に実装します。 */
public final class ComparisonEngine {
    public ComparisonRunResult compare(InputSideResult current,InputSideResult newer,AppConfig.BahMode bahMode){
        Map<MessageKey,List<ParsedRecord>> left=group(current.getRecords()),right=group(newer.getRecords());
        TreeMap<MessageKey,Boolean> keys=new TreeMap<>();left.keySet().forEach(k->keys.put(k,Boolean.TRUE));right.keySet().forEach(k->keys.put(k,Boolean.TRUE));
        List<RecordComparison> rows=new ArrayList<>();List<Diagnostic> diagnostics=new ArrayList<>();diagnostics.addAll(current.getDiagnostics());diagnostics.addAll(newer.getDiagnostics());
        ComparisonSummary summary=new ComparisonSummary();
        for(MessageKey key:keys.keySet()) pairGroup(key,new ArrayList<>(left.getOrDefault(key,List.of())),new ArrayList<>(right.getOrDefault(key,List.of())),rows,summary,diagnostics);
        boolean inputInvalid=!current.isComplete()||!newer.isComplete();boolean ambiguous=summary.ambiguousGroups>0;boolean data=!current.getRecords().isEmpty()||!newer.getRecords().isEmpty();
        ComparisonResult.Equality equality=!data?ComparisonResult.Equality.UNKNOWN:(ambiguous||inputInvalid?ComparisonResult.Equality.UNKNOWN:(summary.differentPairs+summary.currentOnly+summary.newOnly==0?ComparisonResult.Equality.EQUAL:ComparisonResult.Equality.DIFFERENT));
        ComparisonResult result=ComparisonResult.builder().dataPresent(data).equality(equality)
                .validity(inputInvalid?ComparisonResult.Validity.INVALID:ComparisonResult.Validity.VALID)
                .completeness(inputInvalid||ambiguous?ComparisonResult.Completeness.INCOMPLETE:ComparisonResult.Completeness.COMPLETE)
                .interpretation(bahMode==AppConfig.BahMode.FULL?ComparisonResult.Interpretation.FULL:ComparisonResult.Interpretation.BAH_RAW)
                .ambiguous(ambiguous).build();
        if(!data)diagnostics.add(Diagnostic.error("NO_DATA","COMPARISON","選択型の比較可能データが両側にありません。","messageId、BSCode、BAH と入力設定を確認してください。"));
        return new ComparisonRunResult(result,summary,current,newer,rows,diagnostics);
    }
    private Map<MessageKey,List<ParsedRecord>> group(List<ParsedRecord> records){Map<MessageKey,List<ParsedRecord>> map=new TreeMap<>();for(ParsedRecord r:records)map.computeIfAbsent(r.getKey(),k->new ArrayList<>()).add(r);return map;}
    private void pairGroup(MessageKey key,List<ParsedRecord> left,List<ParsedRecord> right,List<RecordComparison> rows,ComparisonSummary s,List<Diagnostic>d){
        for(int i=0;i<left.size();){ParsedRecord l=left.get(i);int hit=findExact(right,l.getProcessedBytes());if(hit>=0){ParsedRecord r=right.remove(hit);left.remove(i);addPair(key,l,r,rows,s);}else i++;}
        if(left.isEmpty()){for(ParsedRecord r:right)addSingle(key,null,r,rows,s);return;}
        if(right.isEmpty()){for(ParsedRecord l:left)addSingle(key,l,null,rows,s);return;}
        if(left.size()==1&&right.size()==1){addPair(key,left.get(0),right.get(0),rows,s);return;}
        rows.add(new RecordComparison(key,PairStatus.AMBIGUOUS_KEY,null,null,left,right,List.of(),-1));s.ambiguousGroups++;
        d.add(Diagnostic.error("AMBIGUOUS_KEY","MATCHING","重複キーに複数の不等価候補があります: "+key+" current="+left.size()+" new="+right.size(),"候補の BAH キー定義を確認し、必要なら明示的な識別キーを追加してください。"));
    }
    private int findExact(List<ParsedRecord> records,byte[] bytes){for(int i=0;i<records.size();i++)if(Arrays.equals(bytes,records.get(i).getProcessedBytes()))return i;return -1;}
    private void addSingle(MessageKey key,ParsedRecord left,ParsedRecord right,List<RecordComparison> rows,ComparisonSummary s){PairStatus status=left==null?PairStatus.NEW_ONLY:PairStatus.CURRENT_ONLY;rows.add(new RecordComparison(key,status,left,right,List.of(),List.of(),List.of(),-1));if(left==null)s.newOnly++;else s.currentOnly++;}
    private void addPair(MessageKey key,ParsedRecord left,ParsedRecord right,List<RecordComparison> rows,ComparisonSummary s){
        byte[] lb=left.getProcessedBytes(),rb=right.getProcessedBytes();boolean equal=Arrays.equals(lb,rb);List<FieldComparison> fields=compareFields(left,right);
        int first=firstDifference(lb,rb);if(!equal&&fields.stream().allMatch(FieldComparison::isEqual))fields.add(unmapped(left,right,first));
        long diff=fields.stream().filter(f->!f.isEqual()).count();s.fieldDifferences+=diff;s.paired++;if(equal)s.equalPairs++;else s.differentPairs++;
        rows.add(new RecordComparison(key,equal?PairStatus.PAIRED_EQUAL:PairStatus.PAIRED_DIFFERENT,left,right,List.of(),List.of(),fields,first));
    }
    private List<FieldComparison> compareFields(ParsedRecord left,ParsedRecord right){
        Map<String,ByteFieldValue> lm=index(left.getFields()),rm=index(right.getFields());TreeMap<String,Boolean> ids=new TreeMap<>();lm.keySet().forEach(k->ids.put(k,Boolean.TRUE));rm.keySet().forEach(k->ids.put(k,Boolean.TRUE));List<FieldComparison> result=new ArrayList<>();
        for(String identity:ids.keySet()){ByteFieldValue l=lm.get(identity),r=rm.get(identity),source=l==null?r:l;boolean eq=l!=null&&r!=null&&Arrays.equals(l.getBytes(),r.getBytes());result.add(new FieldComparison(source.getInstanceId(),source.getRole(),l,r,eq,eq?-1:firstDifference(l==null?new byte[0]:l.getBytes(),r==null?new byte[0]:r.getBytes())));}return result;
    }
    private Map<String,ByteFieldValue> index(List<ByteFieldValue> fields){Map<String,ByteFieldValue> map=new LinkedHashMap<>();for(ByteFieldValue f:fields)map.put(f.getRole()+"|"+f.getInstanceId(),f);return map;}
    private FieldComparison unmapped(ParsedRecord left,ParsedRecord right,int offset){
        byte[] lb=left.getProcessedBytes(),rb=right.getProcessedBytes();int length=Math.max(lb.length,rb.length)-offset;byte[] l=offset<lb.length?Arrays.copyOfRange(lb,offset,lb.length):new byte[0],r=offset<rb.length?Arrays.copyOfRange(rb,offset,rb.length):new byte[0];
        ByteFieldValue lv=new ByteFieldValue("RAW:UNMAPPED@"+offset,"RAW","未割当差分",offset+1,l.length,left.getRemovedBytes()+offset,left.getOriginalFileOffset()+left.getRemovedBytes()+offset,l,ByteText.decode(l,"Shift_JIS"));
        ByteFieldValue rv=new ByteFieldValue("RAW:UNMAPPED@"+offset,"RAW","未割当差分",offset+1,r.length,right.getRemovedBytes()+offset,right.getOriginalFileOffset()+right.getRemovedBytes()+offset,r,ByteText.decode(r,"Shift_JIS"));
        return new FieldComparison("RAW:UNMAPPED@"+offset,"RAW",lv,rv,false,0);
    }
    private int firstDifference(byte[] a,byte[] b){int min=Math.min(a.length,b.length);for(int i=0;i<min;i++)if(a[i]!=b[i])return i;return a.length==b.length?-1:min;}
}
