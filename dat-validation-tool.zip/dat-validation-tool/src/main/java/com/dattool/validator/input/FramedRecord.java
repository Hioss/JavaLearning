package com.dattool.validator.input;

import java.util.Arrays;

/** ファイル内 0 起オフセット付きの原始レコードです。 */
public final class FramedRecord {
    private final long recordNumber;
    private final long fileOffset;
    private final byte[] bytes;
    public FramedRecord(long recordNumber, long fileOffset, byte[] bytes) {
        this.recordNumber=recordNumber; this.fileOffset=fileOffset; this.bytes=Arrays.copyOf(bytes, bytes.length);
    }
    public long getRecordNumber() { return recordNumber; }
    public long getFileOffset() { return fileOffset; }
    public int getLength() { return bytes.length; }
    public byte[] getBytes() { return Arrays.copyOf(bytes, bytes.length); }
}
