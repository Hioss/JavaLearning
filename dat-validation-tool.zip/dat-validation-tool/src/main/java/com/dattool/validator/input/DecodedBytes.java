package com.dattool.validator.input;

/** 厳格デコード結果。失敗時も hex を保持します。 */
public final class DecodedBytes {
    private final boolean valid; private final String text; private final String visible; private final String hex; private final String error;
    public DecodedBytes(boolean valid,String text,String visible,String hex,String error){this.valid=valid;this.text=text;this.visible=visible;this.hex=hex;this.error=error;}
    public boolean isValid(){return valid;} public String getText(){return text;} public String getVisible(){return visible;}
    public String getHex(){return hex;} public String getError(){return error;}
}
