package com.dattool.validator.input;

/** 一つの删头步骤の現在座標と原始レコード座標です。 */
public final class StripTrace {
    private final int stepIndex;
    private final String type;
    private final int relativeStart;
    private final int relativeEndExclusive;
    private final int originalStart;
    private final int originalEndExclusive;
    public StripTrace(int stepIndex,String type,int relativeStart,int relativeEndExclusive,int originalStart,int originalEndExclusive){
        this.stepIndex=stepIndex;this.type=type;this.relativeStart=relativeStart;this.relativeEndExclusive=relativeEndExclusive;
        this.originalStart=originalStart;this.originalEndExclusive=originalEndExclusive;
    }
    public int getStepIndex(){return stepIndex;}
    /** GUI 表示用の互換名。 */
    public int getStep(){return stepIndex;}
    public String getType(){return type;}
    public int getRelativeStart(){return relativeStart;}
    public int getRelativeEndExclusive(){return relativeEndExclusive;}
    public int getOriginalStart(){return originalStart;}
    public int getOriginalEndExclusive(){return originalEndExclusive;}
}
