package com.dattool.validator.compare;

import com.dattool.validator.input.ByteFieldValue;

/** 一つの BAH／BODY／RAW 範囲の厳格な原始バイト比較です。 */
public final class FieldComparison {
    private final String instanceId; private final String role; private final ByteFieldValue current; private final ByteFieldValue newer;
    private final boolean equal; private final int firstDifference;
    public FieldComparison(String instanceId,String role,ByteFieldValue current,ByteFieldValue newer,boolean equal,int firstDifference){this.instanceId=instanceId;this.role=role;this.current=current;this.newer=newer;this.equal=equal;this.firstDifference=firstDifference;}
    public String getInstanceId(){return instanceId;} public String getRole(){return role;} public ByteFieldValue getCurrent(){return current;} public ByteFieldValue getNewer(){return newer;}
    public boolean isEqual(){return equal;} public int getFirstDifference(){return firstDifference;}
}
