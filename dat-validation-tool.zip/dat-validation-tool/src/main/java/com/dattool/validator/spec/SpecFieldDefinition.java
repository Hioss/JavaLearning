package com.dattool.validator.spec;

/** Excel から保真抽出した展開前フィールド定義です。 */
public final class SpecFieldDefinition {
    private final String stableId;
    private final String itemNumber;
    private final String name;
    private final String path;
    private final String setting;
    private final String positionExpression;
    private final int length;
    private final String repeatId;
    private final Integer maxCount;
    private final String repeatVariable;
    private final String parentRepeatId;
    private final boolean currency;
    private final String attribute;
    private final String notes;
    private final String requiredCode;
    private final String positionValueKind;
    private final SpecSource source;

    public SpecFieldDefinition(String stableId, String itemNumber, String name, String path, String setting,
                               String positionExpression, int length, String repeatId, Integer maxCount,
                               String repeatVariable, String parentRepeatId, boolean currency, String attribute,
                               String notes, String requiredCode, String positionValueKind, SpecSource source) {
        this.stableId = stableId; this.itemNumber = itemNumber; this.name = name; this.path = path; this.setting = setting;
        this.positionExpression = positionExpression; this.length = length; this.repeatId = repeatId; this.maxCount = maxCount;
        this.repeatVariable = repeatVariable; this.parentRepeatId = parentRepeatId; this.currency = currency;
        this.attribute = attribute; this.notes = notes; this.requiredCode = requiredCode;
        this.positionValueKind = positionValueKind; this.source = source;
    }
    public String getStableId() { return stableId; }
    public String getItemNumber() { return itemNumber; }
    public String getName() { return name; }
    public String getPath() { return path; }
    public String getSetting() { return setting; }
    public String getPositionExpression() { return positionExpression; }
    public int getLength() { return length; }
    public String getRepeatId() { return repeatId; }
    public Integer getMaxCount() { return maxCount; }
    public String getRepeatVariable() { return repeatVariable; }
    public String getParentRepeatId() { return parentRepeatId; }
    public boolean isCurrency() { return currency; }
    public String getAttribute() { return attribute; }
    public String getNotes() { return notes; }
    public String getRequiredCode() { return requiredCode; }
    public String getPositionValueKind() { return positionValueKind; }
    public SpecSource getSource() { return source; }
}
