package com.dattool.validator;

import com.dattool.validator.cli.CliArguments;
import com.dattool.validator.config.ConfigException;
import com.dattool.validator.config.ConfigValidator;
import com.dattool.validator.config.PreflightValidator;
import com.dattool.validator.config.ResolvedRunConfiguration;
import com.dattool.validator.config.RunConfigurationResolver;
import com.dattool.validator.model.Diagnostic;
import com.dattool.validator.model.ExitCodeMapper;
import com.dattool.validator.service.ComparisonExecutionService;
import com.dattool.validator.service.ExecutionException;
import com.dattool.validator.service.ExecutionResult;
import com.dattool.validator.service.TaskContext;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.spec.SpecAnalysisResult;
import com.dattool.validator.spec.WorkbookSpecAnalyzer;

import java.io.PrintStream;
import java.nio.file.Path;
import java.util.List;

/** DAT 電文比較ツールの CLI エントリーポイントです。 */
public final class DatValidationApplication {
    private DatValidationApplication() {}

    public static void main(String[] args) {
        int code = run(args, System.out, System.err, Path.of(".").toAbsolutePath().normalize());
        if (code != 0) System.exit(code);
    }

    /** テストと GUI からも利用でき、グローバル出力を変更しません。 */
    public static int run(String[] args, PrintStream out, PrintStream err, Path workingDirectory) {
        try {
            CliArguments cli = CliArguments.parse(args);
            if (cli.hasFlag("help")) { printHelp(out); return 0; }
            ResolvedRunConfiguration run = RunConfigurationResolver.resolve(cli, workingDirectory);
            List<Diagnostic> configDiagnostics = ConfigValidator.validate(run.getConfig());
            if (!configDiagnostics.isEmpty()) { printDiagnostics(configDiagnostics, err); return 2; }
            if (cli.hasFlag("validate-config")) {
                if (run.getConfigFile() == null) throw new IllegalArgumentException("--validate-config には --config が必要です。");
                out.println("設定検証: 正常");
                out.println("schemaVersion: " + run.getConfig().getSchemaVersion());
                return 0;
            }
            boolean analyze = cli.hasFlag("analyze-spec");
            List<Diagnostic> preflight = PreflightValidator.validate(run, analyze);
            if (!preflight.isEmpty()) { printDiagnostics(preflight, err); return 2; }
            if (analyze) {
                SpecAnalysisResult analysis = new WorkbookSpecAnalyzer().analyze(run.getSpecification(), run.getConfig());
                printDiagnostics(analysis.getDiagnostics(), analysis.hasErrors() ? err : out);
                out.println("仕様分析候補数: " + analysis.getCandidates().size());
                for (int i = 0; i < analysis.getCandidates().size(); i++) {
                    CompiledLayout layout = analysis.getCandidates().get(i);
                    out.println("候補 " + (i + 1) + ": messageId=" + layout.getMessageId()
                            + ", bsCode=" + layout.getBsCode() + ", variant=" + layout.getVariant()
                            + ", sheet=" + layout.getSheet() + ", 定義=" + layout.getDefinitions().size()
                            + ", 展開=" + layout.getFields().size() + ", 本文バイト=" + layout.getExpectedLength()
                            + ", 未割当範囲=" + layout.getGaps().size());
                }
                return analysis.hasErrors() || analysis.getCandidates().isEmpty() ? 4 : 0;
            }
            TaskContext context=TaskContext.create(run.getConfig(),d->printDiagnostics(java.util.Collections.singletonList(d),err),
                    (percent,stage,message)->out.println("["+percent+"%/"+stage+"] "+message));
            ExecutionResult execution=new ComparisonExecutionService().execute(run,context,true);
            com.dattool.validator.compare.ComparisonRunResult result=execution.getComparison();
            out.println("比較結論: "+result.getResult().getEquality()+", 構造="+result.getResult().getValidity()+", 完全性="+result.getResult().getCompleteness());
            out.println("配対="+result.getSummary().getPaired()+", 差分配対="+result.getSummary().getDifferentPairs()+", 現のみ="+result.getSummary().getCurrentOnly()+", 新のみ="+result.getSummary().getNewOnly()+", 曖昧="+result.getSummary().getAmbiguousGroups());
            out.println("Excel: "+execution.getReport());out.println("manifest: "+execution.getManifest());
            return ExitCodeMapper.toExitCode(result.getResult());
        } catch (ExecutionException e) {
            printDiagnostics(e.getDiagnostics(),err);err.println("比較不能: "+e.getMessage());return 4;
        } catch (IllegalArgumentException | ConfigException e) {
            err.println("引数／設定エラー: " + e.getMessage());
            return 2;
        } catch (Exception e) {
            err.println("内部エラー: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            return 9;
        }
    }

    public static void printDiagnostics(List<Diagnostic> diagnostics, PrintStream err) {
        for (Diagnostic d : diagnostics) {
            String source = d.getSource() == null ? "" : " [" + d.getSource().getFile() + "!" + d.getSource().getSheet()
                    + "!R" + d.getSource().getRow() + "C" + d.getSource().getColumn() + "]";
            err.println("[" + d.getSeverity() + "/" + d.getCode() + "] " + d.getMessage() + source
                    + (d.getSuggestedAction() == null ? "" : " 修正: " + d.getSuggestedAction()));
        }
    }

    private static void printHelp(PrintStream out) {
        out.println("DAT 固定長電文比較ツール");
        out.println("使い方:");
        out.println("  java -jar dat-validation-tool.jar --spec <仕様.xls|xlsx> --current <現.dat> --new <新.dat> --output <結果.xlsx> [オプション]");
        out.println();
        out.println("主なオプション:");
        out.println("  --config <設定.json>       バージョン付き共通設定");
        out.println("  --message-id <ID>          対象メッセージ ID");
        out.println("  --bs-code <完全BSCode>     対象の完全 BSCode");
        out.println("  --sheet <シート名>         仕様シートを明示");
        out.println("  --bah-spec <仕様.xls|xlsx> BAH 仕様書");
        out.println("  --charset <文字セット>     Shift_JIS または windows-31j");
        out.println("  --overwrite                既存結果の上書きを明示");
        out.println("  --analyze-spec             電文なしで仕様を分析");
        out.println("  --validate-config          JSON 設定だけを検証");
        out.println("  --help, -h                 このヘルプ");
        out.println();
        out.println("終了コード: 0=一致／分析成功, 1=差分, 2=引数・事前検証, 4=比較不能／NO_DATA, 9=内部・出力エラー");
    }
}
