package com.dattool.validator.config;

import java.nio.file.Path;

/** 基準ディレクトリを適用済みの実行設定です。 */
public final class ResolvedRunConfiguration {
    private final AppConfig config;
    private final Path configFile;
    private final Path specification;
    private final Path current;
    private final Path newer;
    private final Path output;
    private final Path bahSpecification;

    public ResolvedRunConfiguration(AppConfig config, Path configFile, Path specification, Path current,
                                    Path newer, Path output, Path bahSpecification) {
        this.config = config;
        this.configFile = configFile;
        this.specification = specification;
        this.current = current;
        this.newer = newer;
        this.output = output;
        this.bahSpecification = bahSpecification;
    }
    public AppConfig getConfig() { return config; }
    public Path getConfigFile() { return configFile; }
    public Path getSpecification() { return specification; }
    public Path getCurrent() { return current; }
    public Path getNewer() { return newer; }
    public Path getOutput() { return output; }
    public Path getBahSpecification() { return bahSpecification; }
}
