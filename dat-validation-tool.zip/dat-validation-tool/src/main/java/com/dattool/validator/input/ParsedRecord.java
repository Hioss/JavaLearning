package com.dattool.validator.input;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** 選択型として完全に解析できた BAH＋本文レコードです。 */
public final class ParsedRecord {
    private final Path sourceFile; private final long recordNumber; private final long originalFileOffset;
    private final int originalLength; private final int removedBytes; private final MessageKey key;
    private final byte[] originalBytes; private final byte[] processedBytes; private final byte[] bahBytes; private final byte[] bodyBytes;
    private final List<ByteFieldValue> fields;
    private final List<StripTrace> stripTraces;
    public ParsedRecord(Path sourceFile,long recordNumber,long originalFileOffset,int originalLength,int removedBytes,MessageKey key,
                        byte[] original,byte[] processed,byte[] bah,byte[] body,List<ByteFieldValue> fields,List<StripTrace> stripTraces){
        this.sourceFile=sourceFile;this.recordNumber=recordNumber;this.originalFileOffset=originalFileOffset;this.originalLength=originalLength;
        this.removedBytes=removedBytes;this.key=key;this.originalBytes=Arrays.copyOf(original,original.length);this.processedBytes=Arrays.copyOf(processed,processed.length);
        this.bahBytes=Arrays.copyOf(bah,bah.length);this.bodyBytes=Arrays.copyOf(body,body.length);this.fields=Collections.unmodifiableList(new java.util.ArrayList<>(fields));
        this.stripTraces=Collections.unmodifiableList(new java.util.ArrayList<>(stripTraces));
    }
    public Path getSourceFile(){return sourceFile;} public long getRecordNumber(){return recordNumber;} public long getOriginalFileOffset(){return originalFileOffset;}
    public int getOriginalLength(){return originalLength;} public int getRemovedBytes(){return removedBytes;} public MessageKey getKey(){return key;}
    public byte[] getOriginalBytes(){return Arrays.copyOf(originalBytes,originalBytes.length);}
    public byte[] getProcessedBytes(){return Arrays.copyOf(processedBytes,processedBytes.length);} public byte[] getBahBytes(){return Arrays.copyOf(bahBytes,bahBytes.length);}
    public byte[] getBodyBytes(){return Arrays.copyOf(bodyBytes,bodyBytes.length);} public List<ByteFieldValue> getFields(){return fields;}
    public List<StripTrace> getStripTraces(){return stripTraces;}
}
