package com.dattool.validator.service;

/** タスク進捗を GUI または CLI へ通知します。 */
@FunctionalInterface
public interface ProgressListener {
    void onProgress(int percent, String stage, String message);
}
