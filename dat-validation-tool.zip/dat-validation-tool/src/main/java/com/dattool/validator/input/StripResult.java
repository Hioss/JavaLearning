package com.dattool.validator.input;

import com.dattool.validator.model.Diagnostic;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** 删头结果。失败时 remainingBytes は比較に使用しません。 */
public final class StripResult {
    private final boolean success; private final byte[] remainingBytes; private final int removedBytes;
    private final List<StripTrace> traces; private final Diagnostic diagnostic;
    public StripResult(boolean success,byte[] remaining,int removed,List<StripTrace> traces,Diagnostic diagnostic){
        this.success=success;this.remainingBytes=remaining==null?null:Arrays.copyOf(remaining,remaining.length);this.removedBytes=removed;
        this.traces=Collections.unmodifiableList(traces);this.diagnostic=diagnostic;
    }
    public boolean isSuccess(){return success;}
    public byte[] getRemainingBytes(){return remainingBytes==null?null:Arrays.copyOf(remainingBytes,remainingBytes.length);}
    public int getRemovedBytes(){return removedBytes;}
    public List<StripTrace> getTraces(){return traces;}
    public Diagnostic getDiagnostic(){return diagnostic;}
}
