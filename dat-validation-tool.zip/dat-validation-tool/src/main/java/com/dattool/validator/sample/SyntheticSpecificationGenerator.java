package com.dattool.validator.sample;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** 公開試験専用の SYNTHETIC 仕様書を生成します。 */
public final class SyntheticSpecificationGenerator {
    private SyntheticSpecificationGenerator() {}

    public static void main(String[] args) throws Exception {
        Path directory = args.length == 0 ? Path.of("examples", "synthetic", "specification") : Path.of(args[0]);
        Files.createDirectories(directory);
        writeNormal(directory.resolve("synthetic-normal.xlsx"), new XSSFWorkbook());
        writeNormal(directory.resolve("synthetic-normal.xls"), new HSSFWorkbook());
        writeRepeat(directory.resolve("synthetic-repeat.xlsx"), new XSSFWorkbook());
        writeRepeat(directory.resolve("synthetic-repeat.xls"), new HSSFWorkbook());
        System.out.println("SYNTHETIC specifications: " + directory.toAbsolutePath());
    }

    public static void writeNormal(Path path, Workbook workbook) throws IOException {
        try (Workbook wb = workbook) {
            wb.createSheet("説明").createRow(0).createCell(0).setCellValue("SYNTHETIC - 試験専用");
            Sheet s = wb.createSheet("改名された固定長仕様");
            metadata(s, "synt.001.001.01", "99-99000001-00001", "NORMAL-GAP", "BODY");
            createHeaders(s, 8, 4);
            row(s, 10, 4, "MAI", "1", "種別", "種別を設定", "1", "1", "4", "", "", "", "", "", "C", "", "/Body/Type");
            Row second = row(s, 12, 4, "MAJ", "2", "文書番号", "前導ゼロを保持", "2", null, "4", "", "", "", "", "", "C", "", "/Body/DocumentNo");
            second.createCell(9).setCellFormula("1+4");
            row(s, 13, 4, "OPJ", "3", "通貨", "3 バイト全体", "3", "10", "3", "○", "", "", "", "", "C", "合成 Ccy", "/Body/Currency");
            s.createRow(11).setZeroHeight(true);
            s.createRow(16).createCell(4).setCellValue("XML 構造行（フィールドではない）");
            s.createRow(18).createCell(4).setCellValue("（凡例）位置は 1 バイトを 1 とする");
            write(path, wb);
        }
    }

    public static void writeRepeat(Path path, Workbook workbook) throws IOException {
        try (Workbook wb = workbook) {
            Sheet s = wb.createSheet("繰返し仕様");
            metadata(s, "synt.002.001.01", "99-99000002-00001", "REPEAT-30", "BODY");
            createHeaders(s, 8, 2);
            int r = 10;
            row(s, r++, 2, "MAI", "1", "先頭種別", "", "1", "1", "4", "", "", "", "", "", "C", "", "/Body/F1");
            row(s, r++, 2, "MAI", "2", "処理区分", "", "2", "5", "4", "", "", "", "", "", "C", "", "/Body/F2");
            row(s, r++, 2, "MAJ", "3", "文書番号", "", "3", "9", "11", "", "", "", "", "", "C", "", "/Body/F3");
            row(s, r++, 2, "MAJ", "4", "基準日", "", "4", "20", "8", "", "", "", "", "", "C", "", "/Body/F4");
            row(s, r++, 2, "OPJ", "5", "件数", "", "5", "28", "4", "", "", "", "", "", "C", "", "/Body/F5");
            row(s, r++, 2, "OPJ", "6", "予約", "", "6", "32", "7", "", "", "", "", "", "C", "全半角スペース", "/Body/F6");
            row(s, r++, 2, "MAJ", "7", "ISIN 銘柄コード", "", "7", "39+25*(a-1)", "12", "", "L1", "30", "a", "", "C", "", "/Body/L1/ISIN");
            row(s, r++, 2, "OPJ", "8", "現行銘柄コード", "", "8", "51+25*(a-1)", "9", "", "L1", "30", "a", "", "C", "", "/Body/L1/CurrentCode");
            row(s, r, 2, "OPJ", "9", "外部コードリスト", "", "9", "60+25*(a-1)", "4", "", "L1", "30", "a", "", "C", "", "/Body/L1/ExternalCode");
            write(path, wb);
        }
    }

    public static void writeStress(Path path,int bodyLength) throws IOException {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet s = wb.createSheet("負荷仕様");
            metadata(s, "synt.900.001.01", "99-99000900-00001", "STRESS-"+bodyLength, "BODY");
            createHeaders(s, 8, 2);
            row(s, 10, 2, "MAI", "1", "負荷本文", "合成負荷専用", "1", "1", Integer.toString(bodyLength), "", "", "", "", "", "C", "", "/Body/Payload");
            write(path, wb);
        }
    }

    private static void metadata(Sheet s, String messageId, String bsCode, String variant, String role) {
        s.createRow(0).createCell(0).setCellValue("STPCOM2");
        s.createRow(1).createCell(0).setCellValue("固定長データ情報");
        pair(s, 2, "メッセージID", messageId);
        pair(s, 3, "BSCode", bsCode);
        pair(s, 4, "役割", role);
        pair(s, 5, "レイアウト変体", variant);
        pair(s, 6, "業務分類", "SYNTHETIC");
        pair(s, 7, "仕様スナップショット", "2026-09-09");
    }
    private static void pair(Sheet s, int row, String label, String value) {
        Row r = s.createRow(row); r.createCell(0).setCellValue(label); r.createCell(1).setCellValue(value);
    }
    private static void createHeaders(Sheet s, int groupRow, int col) {
        Row group = s.createRow(groupRow);
        group.createCell(col).setCellValue("JASDEC 利用項目");
        s.addMergedRegion(new CellRangeAddress(groupRow, groupRow, col, col + 3));
        group.createCell(col + 4).setCellValue("固定長データ情報");
        s.addMergedRegion(new CellRangeAddress(groupRow, groupRow, col + 4, col + 14));
        Row h = s.createRow(groupRow + 1);
        String[] labels = {"必須区分", "JASDEC項番", "項目名", "設定内容", "固定長項番", "位置", "サイズ", "Ccy",
                "繰返し情報 ID", "最大回数", "繰返し変数", "親繰返し ID", "属性", "備考", "パス"};
        for (int i = 0; i < labels.length; i++) h.createCell(col + i).setCellValue(labels[i]);
    }
    private static Row row(Sheet s, int row, int col, String... values) {
        Row r = s.createRow(row);
        for (int i = 0; i < values.length; i++) if (values[i] != null) r.createCell(col + i).setCellValue(values[i]);
        return r;
    }
    private static void write(Path path, Workbook wb) throws IOException {
        Files.createDirectories(path.toAbsolutePath().getParent());
        try (OutputStream out = Files.newOutputStream(path)) { wb.write(out); }
    }
}
