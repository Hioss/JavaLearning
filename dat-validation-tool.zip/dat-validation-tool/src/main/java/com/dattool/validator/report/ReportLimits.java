package com.dattool.validator.report;

import org.apache.poi.ss.SpreadsheetVersion;

/** 実上限以下の小さい値をテスト注入できるページング境界です。 */
public final class ReportLimits {
    private final int rows; private final int columns;
    public ReportLimits(){this(SpreadsheetVersion.EXCEL2007.getMaxRows(),SpreadsheetVersion.EXCEL2007.getMaxColumns());}
    public ReportLimits(int rows,int columns){if(rows<4||rows>SpreadsheetVersion.EXCEL2007.getMaxRows())throw new IllegalArgumentException("rows");if(columns<7||columns>SpreadsheetVersion.EXCEL2007.getMaxColumns())throw new IllegalArgumentException("columns");this.rows=rows;this.columns=columns;}
    public int getRows(){return rows;} public int getColumns(){return columns;}
}
