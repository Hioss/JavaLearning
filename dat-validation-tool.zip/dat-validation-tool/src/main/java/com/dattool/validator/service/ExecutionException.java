package com.dattool.validator.service;

import com.dattool.validator.model.Diagnostic;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ExecutionException extends Exception {
    private final List<Diagnostic> diagnostics;
    public ExecutionException(String message,List<Diagnostic> diagnostics){super(message);this.diagnostics=Collections.unmodifiableList(new ArrayList<>(diagnostics));}
    public List<Diagnostic> getDiagnostics(){return diagnostics;}
}
