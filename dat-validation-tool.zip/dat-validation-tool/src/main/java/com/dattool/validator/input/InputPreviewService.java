package com.dattool.validator.input;

import java.util.ArrayList;
import java.util.List;

/** GUI 用に結果を再読込せず先頭 N 件だけ返します。 */
public final class InputPreviewService {
    public List<ParsedRecord> first(InputSideResult result,int limit){
        if(limit<0)throw new IllegalArgumentException("preview limit は 0 以上です。");
        return new ArrayList<>(result.getRecords().subList(0,Math.min(limit,result.getRecords().size())));
    }
}
