package com.dattool.validator.service;

import com.dattool.validator.compare.ComparisonEngine;
import com.dattool.validator.compare.ComparisonRunResult;
import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.ResolvedRunConfiguration;
import com.dattool.validator.input.InputProcessor;
import com.dattool.validator.input.InputSideResult;
import com.dattool.validator.report.ComparisonReportWriter;
import com.dattool.validator.report.ReportOutputs;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.spec.LayoutSelector;
import com.dattool.validator.spec.SpecAnalysisResult;
import com.dattool.validator.spec.WorkbookSpecAnalyzer;

/** 仕様→入力→比較→報告を一つの共有パイプラインで実行します。 */
public final class ComparisonExecutionService {
    public ExecutionResult execute(ResolvedRunConfiguration run,TaskContext context,boolean writeReport) throws Exception {
        AppConfig config=context.getConfigSnapshot();
        progress(context,5,"SPEC","仕様書を分析しています。");
        SpecAnalysisResult analysis=new WorkbookSpecAnalyzer().analyze(run.getSpecification(),config);analysis.getDiagnostics().forEach(context.getLog()::accept);
        if(analysis.hasErrors())throw new ExecutionException("仕様書を一意に解析できません。",analysis.getDiagnostics());
        CompiledLayout layout=LayoutSelector.select(analysis.getCandidates(),config.getSpecification().getMessageId(),config.getSpecification().getBsCode(),config.getSpecification().getVariant(),config.getSpecification().getSheet());
        InputProcessor processor=new InputProcessor();progress(context,25,"CURRENT_INPUT","現行ファイルを解析しています。");
        InputSideResult current=processor.process(run.getCurrent(),config.getCurrentInput(),config.getBah(),layout,config.getLimits());current.getDiagnostics().forEach(context.getLog()::accept);
        progress(context,45,"NEW_INPUT","新ファイルを解析しています。");
        InputSideResult newer=processor.process(run.getNewer(),config.getNewInput(),config.getBah(),layout,config.getLimits());newer.getDiagnostics().forEach(context.getLog()::accept);
        progress(context,65,"COMPARE","配対と原始バイト比較を実行しています。");ComparisonRunResult compared=new ComparisonEngine().compare(current,newer,config.getBah().getMode());
        ReportOutputs outputs=null;if(writeReport){progress(context,80,"REPORT","Excel／manifest／中間ファイルを作成しています。");outputs=new ComparisonReportWriter().write(run.getOutput(),compared,layout,config,context);}
        progress(context,100,"DONE","処理が完了しました。");return new ExecutionResult(compared,layout,outputs==null?null:outputs.getReport(),outputs==null?null:outputs.getManifest());
    }
    private void progress(TaskContext c,int value,String stage,String message){c.getProgress().onProgress(value,stage,message);}
}
