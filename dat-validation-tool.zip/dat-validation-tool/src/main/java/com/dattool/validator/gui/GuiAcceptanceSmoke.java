package com.dattool.validator.gui;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;

/** Final app-image diagnostic: drives a visible window through the same actions as a user. */
final class GuiAcceptanceSmoke {
    private GuiAcceptanceSmoke() {}

    static void run(String[] args) {
        if (args.length < 4 || args.length > 5 || (args.length == 5 && !"--open-result".equals(args[4]))) System.exit(2);
        Path root = Path.of(args[1]).toAbsolutePath().normalize();
        Path output = Path.of(args[2]).toAbsolutePath().normalize();
        String charset = args[3];
        if (!("Shift_JIS".equals(charset) || "windows-31j".equalsIgnoreCase(charset))) System.exit(2);
        try {
            Files.createDirectories(output.getParent());
            DatValidationGui.setupLookAndFeel();
            AtomicReference<MainFrame> ref = new AtomicReference<>();
            SwingUtilities.invokeAndWait(() -> {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
                ref.set(frame);
            });
            boolean openResult = args.length == 5 && "--open-result".equals(args[4]);
            Thread automation = new Thread(() -> execute(root, output, charset, openResult, ref.get()), "gui-acceptance-smoke");
            automation.setDaemon(false);
            automation.start();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(9);
        }
    }

    private static void execute(Path root, Path output, String charset, boolean openResult, MainFrame frame) {
        int code = 9;
        try {
            Path config = root.resolve("examples/synthetic/config.synthetic.json");
            onEdt(() -> {
                named(frame, JTextField.class, "configPath").setText(config.toString());
                named(frame, JButton.class, "button.設定読込").doClick();
                named(frame, JTextField.class, "currentPath").setText(root.resolve("examples/synthetic/messages/current.dat").toString());
                named(frame, JTextField.class, "newPath").setText(root.resolve("examples/synthetic/messages/new-equal-reordered.dat").toString());
                named(frame, JTextField.class, "outputPath").setText(output.toString());
                JTextArea json = named(frame, JTextArea.class, "advancedConfig");
                json.setText(json.getText().replace("\"charset\" : \"Shift_JIS\"", "\"charset\" : \"" + charset + "\""));
            });

            JButton analyze = named(frame, JButton.class, "button.仕様分析");
            click(analyze);
            waitFor(() -> enabled(analyze), Duration.ofSeconds(20));
            JButton preview = named(frame, JButton.class, "button.現をプレビュー");
            click(preview);
            waitFor(() -> enabled(preview), Duration.ofSeconds(20));
            require(text(frame, JTextArea.class, "messagePreview").contains("parsed="), "preview did not complete");
            JButton start = named(frame, JButton.class, "button.比較開始");
            click(start);
            waitFor(() -> enabled(start), Duration.ofSeconds(60));
            String summary = text(frame, JLabel.class, "resultSummary");
            require(Files.isRegularFile(output), "report was not generated");
            require(summary.contains("EQUAL") && summary.contains("COMPLETE"), "unexpected result: " + summary);
            if (openResult) {
                SwingUtilities.invokeLater(() -> named(frame, JButton.class, "button.結果フォルダー").doClick());
                Thread.sleep(1000);
                AtomicReference<Window> errorDialog = new AtomicReference<>();
                SwingUtilities.invokeAndWait(() -> {
                    for (Window window : Window.getWindows()) {
                        if (window != frame && window.isShowing() && window.getClass().getName().contains("Dialog")) {
                            errorDialog.set(window);
                            window.dispose();
                        }
                    }
                });
                require(errorDialog.get() == null, "result folder could not be opened");
            }
            code = 0;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            int exit = code;
            try {
                SwingUtilities.invokeAndWait(frame::dispose);
            } catch (Exception ignored) {
                exit = 9;
            }
            System.exit(exit);
        }
    }

    private static void click(JButton button) throws Exception {
        SwingUtilities.invokeAndWait(button::doClick);
    }

    private static boolean enabled(JButton button) {
        AtomicReference<Boolean> value = new AtomicReference<>();
        try {
            SwingUtilities.invokeAndWait(() -> value.set(button.isEnabled()));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
        return value.get();
    }

    private static void waitFor(BooleanSupplier condition, Duration timeout) throws Exception {
        Instant deadline = Instant.now().plus(timeout);
        while (!condition.getAsBoolean() && Instant.now().isBefore(deadline)) Thread.sleep(50);
        require(condition.getAsBoolean(), "timed out waiting for Swing operation");
    }

    private static void onEdt(Runnable action) throws Exception {
        SwingUtilities.invokeAndWait(action);
    }

    private static <T extends Component> String text(Container root, Class<T> type, String name) throws Exception {
        AtomicReference<String> value = new AtomicReference<>();
        SwingUtilities.invokeAndWait(() -> {
            Component component = named(root, type, name);
            if (component instanceof JTextArea) value.set(((JTextArea) component).getText());
            else value.set(((JLabel) component).getText());
        });
        return value.get();
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }

    private static <T extends Component> T named(Container root, Class<T> type, String name) {
        for (Component component : root.getComponents()) {
            if (type.isInstance(component) && name.equals(component.getName())) return type.cast(component);
            if (component instanceof Container) {
                try {
                    return named((Container) component, type, name);
                } catch (IllegalArgumentException ignored) {
                    // Continue with the next branch.
                }
            }
        }
        throw new IllegalArgumentException("Component not found: " + type.getSimpleName() + " / " + name);
    }
}
