package com.dattool.validator.sample;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.AppConfigLoader;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

/** 10,000 条／約 50 MiB の再生成可能な公開負荷ベクトルです。 */
public final class SyntheticStressGenerator {
    private static final Charset SJIS=Charset.forName("Shift_JIS");
    private SyntheticStressGenerator(){}
    public static void main(String[] args)throws Exception{Path dir=args.length>0?Path.of(args[0]):Path.of("target","stress-synthetic");int count=args.length>1?Integer.parseInt(args[1]):10_000;int bodyLength=args.length>2?Integer.parseInt(args[2]):2_500;Files.createDirectories(dir);SyntheticSpecificationGenerator.writeStress(dir.resolve("synthetic-stress.xlsx"),bodyLength);writeMessages(dir.resolve("current.dat"),count,bodyLength);writeMessages(dir.resolve("new.dat"),count,bodyLength);AppConfigLoader.save(config(bodyLength,count),dir.resolve("config.json"));System.out.println("records-per-side="+count+" bodyBytes="+bodyLength+" totalInputBytes="+(Files.size(dir.resolve("current.dat"))+Files.size(dir.resolve("new.dat"))));}
    private static void writeMessages(Path file,int count,int bodyLength)throws Exception{try(OutputStream out=new BufferedOutputStream(Files.newOutputStream(file),1024*1024)){for(int i=1;i<=count;i++){byte[] record=record(i,bodyLength);out.write(record);if(i<count){out.write('\r');out.write('\n');}}}}
    private static byte[] record(int number,int bodyLength){byte[] record=new byte[8+96+bodyLength];Arrays.fill(record,(byte)' ');put(record,0,8,"MQHEAD08");put(record,8,11,"SENDER");put(record,19,11,"RECEIVER");put(record,30,35,String.format("%035d",number));put(record,65,15,"synt.900.001.01");put(record,80,17,"99-99000900-00001");put(record,104,Math.min(bodyLength,16),String.format("ROW%08d",number));return record;}
    private static AppConfig config(int bodyLength,int count){AppConfig c=new AppConfig();c.getPaths().setSpecification("synthetic-stress.xlsx");c.getPaths().setCurrent("current.dat");c.getPaths().setNewer("new.dat");c.getPaths().setOutput("stress-report.xlsx");c.getSpecification().setSheet("負荷仕様");c.getSpecification().setMessageId("synt.900.001.01");c.getSpecification().setBsCode("99-99000900-00001");c.getSpecification().setVariant("STRESS-"+bodyLength);AppConfig.StripStep strip=new AppConfig.StripStep();strip.setType(AppConfig.StripType.FIXED_LENGTH);strip.setLength(8);c.getCurrentInput().setStripSteps(List.of(strip));AppConfig.StripStep strip2=new AppConfig.StripStep();strip2.setType(AppConfig.StripType.FIXED_LENGTH);strip2.setLength(8);c.getNewInput().setStripSteps(List.of(strip2));AppConfig.BahConfig b=c.getBah();b.setMode(AppConfig.BahMode.BAH_RAW);b.setTotalLength(96);b.setBodyStart(97);b.setVariant("SYNTHETIC-STRESS-96");b.setFields(List.of(field("sender",AppConfig.BahRole.SENDER,1,11,true),field("receiver",AppConfig.BahRole.RECEIVER,12,11,true),field("doc",AppConfig.BahRole.DOCUMENT_ID,23,35,true),field("message",AppConfig.BahRole.MESSAGE_ID,58,15,true),field("bs",AppConfig.BahRole.BS_CODE,73,17,false),field("reserved",AppConfig.BahRole.RESERVED,90,7,false)));c.getLimits().setMaxRecordBytes(bodyLength+200);c.getLimits().setMaxRecordsInMemory(Math.max(count,10_000));c.getOutput().setOverwrite(true);return c;}
    private static AppConfig.BahField field(String id,AppConfig.BahRole role,int position,int length,boolean trim){AppConfig.BahField f=new AppConfig.BahField();f.setId(id);f.setName(id);f.setRole(role);f.setPosition(position);f.setLength(length);f.setTrimHalfWidthSpacePadding(trim);return f;}
    private static void put(byte[] target,int offset,int length,String text){byte[] bytes=text.getBytes(SJIS);if(bytes.length>length)throw new IllegalArgumentException(text);System.arraycopy(bytes,0,target,offset,bytes.length);}
}
