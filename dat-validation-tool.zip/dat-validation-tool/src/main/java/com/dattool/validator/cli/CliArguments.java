package com.dattool.validator.cli;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 既知の CLI 引数だけを受け付ける解析結果です。 */
public final class CliArguments {
    private static final Set<String> VALUE_OPTIONS = Set.of(
            "config", "spec", "current", "new", "output", "message-id", "bs-code", "sheet", "bah-spec", "charset");
    private static final Set<String> FLAG_OPTIONS = Set.of("help", "overwrite", "analyze-spec", "validate-config");
    private final Map<String, String> values;
    private final Set<String> flags;

    private CliArguments(Map<String, String> values, Set<String> flags) {
        this.values = Collections.unmodifiableMap(values);
        this.flags = Collections.unmodifiableSet(flags);
    }

    public static CliArguments parse(String[] args) {
        Map<String, String> values = new LinkedHashMap<>();
        Set<String> flags = new java.util.LinkedHashSet<>();
        for (int i = 0; i < args.length; i++) {
            String token = args[i];
            if ("-h".equals(token)) token = "--help";
            if (!token.startsWith("--") || token.length() == 2) throw new IllegalArgumentException("不明な引数です: " + token);
            String name = token.substring(2);
            if (FLAG_OPTIONS.contains(name)) {
                if (!flags.add(name)) throw new IllegalArgumentException("引数が重複しています: --" + name);
            } else if (VALUE_OPTIONS.contains(name)) {
                if (values.containsKey(name)) throw new IllegalArgumentException("引数が重複しています: --" + name);
                if (i + 1 >= args.length || args[i + 1].startsWith("--")) throw new IllegalArgumentException("引数の値が不足しています: --" + name);
                values.put(name, args[++i]);
            } else throw new IllegalArgumentException("不明な引数です: --" + name);
        }
        if (flags.contains("analyze-spec") && flags.contains("validate-config"))
            throw new IllegalArgumentException("--analyze-spec と --validate-config は同時に指定できません。");
        return new CliArguments(values, flags);
    }

    public String value(String name) { return values.get(name); }
    public boolean hasFlag(String name) { return flags.contains(name); }
}
