package com.dattool.validator.model;

/** 詳細結果を CLI 終了コードへ一か所で変換します。 */
public final class ExitCodeMapper {
    private ExitCodeMapper() {}

    public static int toExitCode(ComparisonResult result) {
        if (result.isConfigurationError()) return 2;
        if (result.isInternalError()) return 9;
        if (!result.isDataPresent()
                || result.getValidity() != ComparisonResult.Validity.VALID
                || result.getCompleteness() != ComparisonResult.Completeness.COMPLETE
                || result.isAmbiguous()
                || result.getEquality() == ComparisonResult.Equality.UNKNOWN) return 4;
        return result.getEquality() == ComparisonResult.Equality.EQUAL ? 0 : 1;
    }
}
