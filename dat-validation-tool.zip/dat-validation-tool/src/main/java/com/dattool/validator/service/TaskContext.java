package com.dattool.validator.service;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.AppConfigLoader;
import com.dattool.validator.config.ConfigException;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** 一回の実行に閉じた設定スナップショット、ログ、進捗です。 */
public final class TaskContext {
    private final UUID runId;
    private final Instant startedAt;
    private final String configJson;
    private final TaskLog log;
    private final ProgressListener progress;

    private TaskContext(AppConfig config, TaskLog log, ProgressListener progress) throws ConfigException {
        this.runId = UUID.randomUUID();
        this.startedAt = Instant.now();
        this.configJson = AppConfigLoader.toJson(Objects.requireNonNull(config, "config"));
        this.log = Objects.requireNonNull(log, "log");
        this.progress = Objects.requireNonNull(progress, "progress");
    }

    public static TaskContext create(AppConfig config, TaskLog log, ProgressListener progress) throws ConfigException {
        return new TaskContext(config, log, progress);
    }
    public UUID getRunId() { return runId; }
    public Instant getStartedAt() { return startedAt; }
    public AppConfig getConfigSnapshot() throws ConfigException { return AppConfigLoader.fromJson(configJson); }
    public TaskLog getLog() { return log; }
    public ProgressListener getProgress() { return progress; }
}
