package com.dattool.validator.service;

import com.dattool.validator.compare.ComparisonRunResult;
import com.dattool.validator.spec.CompiledLayout;
import java.nio.file.Path;

/** CLI と GUI が共有する一回の実行結果です。 */
public final class ExecutionResult {
    private final ComparisonRunResult comparison; private final CompiledLayout layout; private final Path report; private final Path manifest;
    public ExecutionResult(ComparisonRunResult comparison,CompiledLayout layout,Path report,Path manifest){this.comparison=comparison;this.layout=layout;this.report=report;this.manifest=manifest;}
    public ComparisonRunResult getComparison(){return comparison;} public CompiledLayout getLayout(){return layout;} public Path getReport(){return report;} public Path getManifest(){return manifest;}
}
