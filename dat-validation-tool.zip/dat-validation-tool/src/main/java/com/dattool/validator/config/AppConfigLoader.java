package com.dattool.validator.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** UTF-8 JSON 設定を厳格に読み書きします。 */
public final class AppConfigLoader {
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .enable(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)
            .enable(SerializationFeature.INDENT_OUTPUT);

    private AppConfigLoader() {}

    public static AppConfig load(Path path) throws ConfigException {
        try {
            byte[] bytes = Files.readAllBytes(path);
            return fromJson(new String(bytes, StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new ConfigException("設定ファイルを読み取れません: " + path + " (" + e.getMessage() + ")", e);
        }
    }

    public static AppConfig fromJson(String json) throws ConfigException {
        try {
            return MAPPER.readValue(json, AppConfig.class);
        } catch (JsonMappingException e) {
            String path = e.getPathReference();
            throw new ConfigException("設定 JSON が不正です" + (path == null ? "" : " " + path) + ": " + e.getOriginalMessage(), e);
        } catch (JsonProcessingException e) {
            throw new ConfigException("設定 JSON の構文が不正です: " + e.getOriginalMessage(), e);
        }
    }

    public static String toJson(AppConfig config) throws ConfigException {
        try {
            return MAPPER.writeValueAsString(config) + System.lineSeparator();
        } catch (JsonProcessingException e) {
            throw new ConfigException("設定 JSON を生成できません: " + e.getOriginalMessage(), e);
        }
    }

    public static void save(AppConfig config, Path path) throws ConfigException {
        try {
            Path parent = path.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.write(path, toJson(config).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new ConfigException("設定ファイルを書き込めません: " + path + " (" + e.getMessage() + ")", e);
        }
    }
}
