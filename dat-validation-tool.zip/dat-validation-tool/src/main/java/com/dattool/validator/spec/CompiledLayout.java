package com.dattool.validator.spec;

import java.util.Collections;
import java.util.List;

/** 一意に選択可能な固定長本文レイアウトです。 */
public final class CompiledLayout {
    private final String messageId;
    private final String bsCode;
    private final String variant;
    private final String category;
    private final String snapshot;
    private final String role;
    private final String sheet;
    private final List<SpecFieldDefinition> definitions;
    private final List<ExpandedField> fields;
    private final List<RawRange> gaps;
    private final int expectedLength;

    public CompiledLayout(String messageId, String bsCode, String variant, String category, String snapshot,
                          String role, String sheet, List<SpecFieldDefinition> definitions,
                          List<ExpandedField> fields, List<RawRange> gaps, int expectedLength) {
        this.messageId = messageId; this.bsCode = bsCode; this.variant = variant; this.category = category;
        this.snapshot = snapshot; this.role = role; this.sheet = sheet;
        this.definitions = Collections.unmodifiableList(definitions); this.fields = Collections.unmodifiableList(fields);
        this.gaps = Collections.unmodifiableList(gaps); this.expectedLength = expectedLength;
    }
    public String getMessageId() { return messageId; }
    public String getBsCode() { return bsCode; }
    public String getVariant() { return variant; }
    public String getCategory() { return category; }
    public String getSnapshot() { return snapshot; }
    public String getRole() { return role; }
    public String getSheet() { return sheet; }
    public List<SpecFieldDefinition> getDefinitions() { return definitions; }
    public List<ExpandedField> getFields() { return fields; }
    public List<RawRange> getGaps() { return gaps; }
    public int getExpectedLength() { return expectedLength; }
    public String typeKey() { return safe(messageId) + "|" + safe(bsCode) + "|" + safe(variant); }
    private static String safe(String s) { return s == null ? "" : s; }
}
