package com.dattool.validator.config;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** GUI と CLI が共有するバージョン付き設定です。 */
public class AppConfig {
    public static final int CURRENT_SCHEMA_VERSION = 1;

    private int schemaVersion = CURRENT_SCHEMA_VERSION;
    private PathsConfig paths = new PathsConfig();
    private SpecificationConfig specification = new SpecificationConfig();
    private InputConfig currentInput = new InputConfig();
    private InputConfig newInput = new InputConfig();
    private BahConfig bah = new BahConfig();
    private ResourceLimits limits = new ResourceLimits();
    private OutputConfig output = new OutputConfig();

    public int getSchemaVersion() { return schemaVersion; }
    public void setSchemaVersion(int schemaVersion) { this.schemaVersion = schemaVersion; }
    public PathsConfig getPaths() { return paths; }
    public void setPaths(PathsConfig paths) { this.paths = paths; }
    public SpecificationConfig getSpecification() { return specification; }
    public void setSpecification(SpecificationConfig specification) { this.specification = specification; }
    public InputConfig getCurrentInput() { return currentInput; }
    public void setCurrentInput(InputConfig currentInput) { this.currentInput = currentInput; }
    public InputConfig getNewInput() { return newInput; }
    public void setNewInput(InputConfig newInput) { this.newInput = newInput; }
    public BahConfig getBah() { return bah; }
    public void setBah(BahConfig bah) { this.bah = bah; }
    public ResourceLimits getLimits() { return limits; }
    public void setLimits(ResourceLimits limits) { this.limits = limits; }
    public OutputConfig getOutput() { return output; }
    public void setOutput(OutputConfig output) { this.output = output; }

    public static class PathsConfig {
        private String specification;
        private String current;
        private String newer;
        private String output;
        private String bahSpecification;
        public String getSpecification() { return specification; }
        public void setSpecification(String specification) { this.specification = specification; }
        public String getCurrent() { return current; }
        public void setCurrent(String current) { this.current = current; }
        public String getNewer() { return newer; }
        public void setNewer(String newer) { this.newer = newer; }
        public String getOutput() { return output; }
        public void setOutput(String output) { this.output = output; }
        public String getBahSpecification() { return bahSpecification; }
        public void setBahSpecification(String bahSpecification) { this.bahSpecification = bahSpecification; }
    }

    public static class SpecificationConfig {
        private String sheet;
        private String messageId;
        private String bsCode;
        private String variant;
        private String category;
        private String snapshot;
        private MappingConfig mapping = new MappingConfig();
        public String getSheet() { return sheet; }
        public void setSheet(String sheet) { this.sheet = sheet; }
        public String getMessageId() { return messageId; }
        public void setMessageId(String messageId) { this.messageId = messageId; }
        public String getBsCode() { return bsCode; }
        public void setBsCode(String bsCode) { this.bsCode = bsCode; }
        public String getVariant() { return variant; }
        public void setVariant(String variant) { this.variant = variant; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public String getSnapshot() { return snapshot; }
        public void setSnapshot(String snapshot) { this.snapshot = snapshot; }
        public MappingConfig getMapping() { return mapping; }
        public void setMapping(MappingConfig mapping) { this.mapping = mapping; }
    }

    public static class MappingConfig {
        private Integer headerStartRow;
        private Integer headerEndRow;
        private Integer dataStartRow;
        private Integer dataEndRow;
        private boolean allowCachedFormulaResults;
        private Map<String, Integer> columns = new LinkedHashMap<>();
        private List<RepeatBinding> repeatBindings = new ArrayList<>();
        private List<String> sharedRanges = new ArrayList<>();
        private Integer expectedBodyLength;
        public Integer getHeaderStartRow() { return headerStartRow; }
        public void setHeaderStartRow(Integer value) { headerStartRow = value; }
        public Integer getHeaderEndRow() { return headerEndRow; }
        public void setHeaderEndRow(Integer value) { headerEndRow = value; }
        public Integer getDataStartRow() { return dataStartRow; }
        public void setDataStartRow(Integer value) { dataStartRow = value; }
        public Integer getDataEndRow() { return dataEndRow; }
        public void setDataEndRow(Integer value) { dataEndRow = value; }
        public boolean isAllowCachedFormulaResults() { return allowCachedFormulaResults; }
        public void setAllowCachedFormulaResults(boolean value) { allowCachedFormulaResults = value; }
        public Map<String, Integer> getColumns() { return columns; }
        public void setColumns(Map<String, Integer> columns) { this.columns = columns; }
        public List<RepeatBinding> getRepeatBindings() { return repeatBindings; }
        public void setRepeatBindings(List<RepeatBinding> value) { repeatBindings = value; }
        public List<String> getSharedRanges() { return sharedRanges; }
        public void setSharedRanges(List<String> value) { sharedRanges = value; }
        public Integer getExpectedBodyLength() { return expectedBodyLength; }
        public void setExpectedBodyLength(Integer value) { expectedBodyLength = value; }
    }

    public static class RepeatBinding {
        private String id;
        private String variable;
        private Integer maxCount;
        private String parentId;
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getVariable() { return variable; }
        public void setVariable(String variable) { this.variable = variable; }
        public Integer getMaxCount() { return maxCount; }
        public void setMaxCount(Integer maxCount) { this.maxCount = maxCount; }
        public String getParentId() { return parentId; }
        public void setParentId(String parentId) { this.parentId = parentId; }
    }

    public enum Framing { LINE, SINGLE_MESSAGE }
    public enum LineSeparator { AUTO, CRLF, LF, MIXED }
    public enum StripType { FIXED_LENGTH, PREFIX, MARKER }

    public static class InputConfig {
        private String charset = "Shift_JIS";
        private Framing framing = Framing.LINE;
        private LineSeparator lineSeparator = LineSeparator.AUTO;
        private boolean ignoreEmptyLines;
        private List<StripStep> stripSteps = new ArrayList<>();
        public String getCharset() { return charset; }
        public void setCharset(String charset) { this.charset = charset; }
        public Framing getFraming() { return framing; }
        public void setFraming(Framing framing) { this.framing = framing; }
        public LineSeparator getLineSeparator() { return lineSeparator; }
        public void setLineSeparator(LineSeparator value) { lineSeparator = value; }
        public boolean isIgnoreEmptyLines() { return ignoreEmptyLines; }
        public void setIgnoreEmptyLines(boolean value) { ignoreEmptyLines = value; }
        public List<StripStep> getStripSteps() { return stripSteps; }
        public void setStripSteps(List<StripStep> stripSteps) { this.stripSteps = stripSteps; }
    }

    public static class StripStep {
        private StripType type;
        private Integer length;
        private String literal;
        private String hex;
        private Integer searchWindow;
        private Boolean includeMarker;
        public StripType getType() { return type; }
        public void setType(StripType type) { this.type = type; }
        public Integer getLength() { return length; }
        public void setLength(Integer length) { this.length = length; }
        public String getLiteral() { return literal; }
        public void setLiteral(String literal) { this.literal = literal; }
        public String getHex() { return hex; }
        public void setHex(String hex) { this.hex = hex; }
        public Integer getSearchWindow() { return searchWindow; }
        public void setSearchWindow(Integer searchWindow) { this.searchWindow = searchWindow; }
        public Boolean getIncludeMarker() { return includeMarker; }
        public void setIncludeMarker(Boolean value) { includeMarker = value; }
    }

    public enum BahMode { FULL, BAH_RAW }
    public enum BahRole { SENDER, RECEIVER, DOCUMENT_ID, MESSAGE_ID, BS_CODE, RESERVED, OTHER }

    public static class BahConfig {
        private BahMode mode = BahMode.BAH_RAW;
        private Integer totalLength;
        private Integer bodyStart;
        private String variant;
        private List<BahField> fields = new ArrayList<>();
        public BahMode getMode() { return mode; }
        public void setMode(BahMode mode) { this.mode = mode; }
        public Integer getTotalLength() { return totalLength; }
        public void setTotalLength(Integer totalLength) { this.totalLength = totalLength; }
        public Integer getBodyStart() { return bodyStart; }
        public void setBodyStart(Integer bodyStart) { this.bodyStart = bodyStart; }
        public String getVariant() { return variant; }
        public void setVariant(String variant) { this.variant = variant; }
        public List<BahField> getFields() { return fields; }
        public void setFields(List<BahField> fields) { this.fields = fields; }
    }

    public static class BahField {
        private String id;
        private String name;
        private BahRole role;
        private Integer position;
        private Integer length;
        private boolean trimHalfWidthSpacePadding;
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public BahRole getRole() { return role; }
        public void setRole(BahRole role) { this.role = role; }
        public Integer getPosition() { return position; }
        public void setPosition(Integer position) { this.position = position; }
        public Integer getLength() { return length; }
        public void setLength(Integer length) { this.length = length; }
        public boolean isTrimHalfWidthSpacePadding() { return trimHalfWidthSpacePadding; }
        public void setTrimHalfWidthSpacePadding(boolean value) { trimHalfWidthSpacePadding = value; }
    }

    public static class ResourceLimits {
        private int maxRecordBytes = 16 * 1024 * 1024;
        private int maxExpandedFields = 100_000;
        private int previewRecordLimit = 20;
        private int maxRecordsInMemory = 100_000;
        public int getMaxRecordBytes() { return maxRecordBytes; }
        public void setMaxRecordBytes(int value) { maxRecordBytes = value; }
        public int getMaxExpandedFields() { return maxExpandedFields; }
        public void setMaxExpandedFields(int value) { maxExpandedFields = value; }
        public int getPreviewRecordLimit() { return previewRecordLimit; }
        public void setPreviewRecordLimit(int value) { previewRecordLimit = value; }
        public int getMaxRecordsInMemory() { return maxRecordsInMemory; }
        public void setMaxRecordsInMemory(int value) { maxRecordsInMemory = value; }
    }

    public static class OutputConfig {
        private boolean overwrite;
        private String temporaryDirectory;
        private int inlineCellTextLimit = 32767;
        public boolean isOverwrite() { return overwrite; }
        public void setOverwrite(boolean overwrite) { this.overwrite = overwrite; }
        public String getTemporaryDirectory() { return temporaryDirectory; }
        public void setTemporaryDirectory(String value) { temporaryDirectory = value; }
        public int getInlineCellTextLimit() { return inlineCellTextLimit; }
        public void setInlineCellTextLimit(int value) { inlineCellTextLimit = value; }
    }
}
