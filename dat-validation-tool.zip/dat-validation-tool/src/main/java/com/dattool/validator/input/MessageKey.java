package com.dattool.validator.input;

import java.util.Objects;

/** BAH のメッセージ ID＋完全 BSCode＋文書 ID です。 */
public final class MessageKey implements Comparable<MessageKey> {
    private final String messageId; private final String bsCode; private final String documentId;
    public MessageKey(String messageId,String bsCode,String documentId){this.messageId=messageId;this.bsCode=bsCode;this.documentId=documentId;}
    public String getMessageId(){return messageId;} public String getBsCode(){return bsCode;} public String getDocumentId(){return documentId;}
    @Override public int compareTo(MessageKey o){int c=messageId.compareTo(o.messageId);if(c!=0)return c;c=bsCode.compareTo(o.bsCode);return c!=0?c:documentId.compareTo(o.documentId);}
    @Override public boolean equals(Object o){if(!(o instanceof MessageKey))return false;MessageKey k=(MessageKey)o;return messageId.equals(k.messageId)&&bsCode.equals(k.bsCode)&&documentId.equals(k.documentId);}
    @Override public int hashCode(){return Objects.hash(messageId,bsCode,documentId);}
    @Override public String toString(){return messageId+"|"+bsCode+"|"+documentId;}
}
