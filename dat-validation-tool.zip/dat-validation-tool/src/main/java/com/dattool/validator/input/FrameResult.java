package com.dattool.validator.input;

import com.dattool.validator.model.Diagnostic;
import java.util.Collections;
import java.util.List;

/** 分帧记录、物理计数、实际改行形式和诊断です。 */
public final class FrameResult {
    private final List<FramedRecord> records;
    private final List<Diagnostic> diagnostics;
    private final long ignoredEmptyRecords;
    private final long physicalRecordCount;
    private final String detectedSeparator;
    public FrameResult(List<FramedRecord> records, List<Diagnostic> diagnostics, long ignored, long physical, String separator) {
        this.records=Collections.unmodifiableList(records); this.diagnostics=Collections.unmodifiableList(diagnostics);
        this.ignoredEmptyRecords=ignored; this.physicalRecordCount=physical; this.detectedSeparator=separator;
    }
    public List<FramedRecord> getRecords(){return records;}
    public List<Diagnostic> getDiagnostics(){return diagnostics;}
    public long getIgnoredEmptyRecords(){return ignoredEmptyRecords;}
    public long getPhysicalRecordCount(){return physicalRecordCount;}
    public String getDetectedSeparator(){return detectedSeparator;}
}
