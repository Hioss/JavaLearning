package com.dattool.validator.input;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.spec.ExpandedField;
import com.dattool.validator.spec.RawRange;
import com.dattool.validator.util.ByteText;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** 分帧→删头→BAH 識別→型筛选→本文解析の固定順を実行します。 */
public final class InputProcessor {
    private final RecordFramer framer=new RecordFramer(); private final HeaderStripper stripper=new HeaderStripper();

    public InputSideResult process(Path file, AppConfig.InputConfig input, AppConfig.BahConfig bah,
                                   CompiledLayout selected, AppConfig.ResourceLimits limits) throws IOException {
        FrameResult framed=framer.frame(file,input,limits);
        List<Diagnostic> diagnostics=new ArrayList<>(framed.getDiagnostics());
        List<ParsedRecord> records=new ArrayList<>(); InputStatistics stats=new InputStatistics();
        stats.ignoredEmptyRecords=framed.getIgnoredEmptyRecords(); stats.physicalRecords=framed.getPhysicalRecordCount();
        boolean bahConfigured=validBahEnvelope(bah);
        if (!bahConfigured) {
            diagnostics.add(Diagnostic.error("BAH_CONFIG_REQUIRED","BAH","BAH 境界と配対キー位置が未設定です。","bah.totalLength、bodyStart、fields を設定してください。"));
        }
        for(FramedRecord raw:framed.getRecords()){
            stats.totalRecords++;
            StripResult stripped=stripper.strip(raw,input);
            if(!stripped.isSuccess()){stats.recognitionFailures++;diagnostics.add(withFile(stripped.getDiagnostic(),file,raw));continue;}
            if(!bahConfigured){stats.recognitionFailures++;continue;}
            byte[] bytes=stripped.getRemainingBytes();
            if(bytes.length<bah.getTotalLength()){stats.recognitionFailures++;diagnostics.add(diag("BAH_SHORT","BAH",file,raw,stripped.getRemovedBytes(),"删头后のレコードが BAH 長より短いです。"));continue;}
            Map<AppConfig.BahRole,KeyPart> keyParts=keyParts(bytes,bah,input.getCharset(),diagnostics,file,raw,stripped.getRemovedBytes());
            KeyPart message=keyParts.get(AppConfig.BahRole.MESSAGE_ID),bs=keyParts.get(AppConfig.BahRole.BS_CODE),doc=keyParts.get(AppConfig.BahRole.DOCUMENT_ID);
            if(!validKey(message,"[A-Za-z0-9._-]+")||!validKey(bs,"[A-Za-z0-9-]+")||!validKey(doc,".+")){
                stats.recognitionFailures++;diagnostics.add(diag("BAH_KEY","BAH",file,raw,stripped.getRemovedBytes(),"BAH のメッセージ ID、完全 BSCode、文書 ID を検証できません。"));continue;
            }
            if(!selected.getMessageId().equals(message.value)||!selected.getBsCode().equals(bs.value)){stats.otherTypeRecords++;continue;}
            stats.selectedRecords++;
            int bodyOffset=bah.getBodyStart()-1;
            int actualBody=bytes.length-bodyOffset;
            if(actualBody!=selected.getExpectedLength()){
                stats.failedSelectedRecords++;diagnostics.add(diag("BODY_LENGTH","BODY",file,raw,stripped.getRemovedBytes()+bodyOffset,
                        "選択型の本文長が仕様と一致しません: " + actualBody + " != " + selected.getExpectedLength()));continue;
            }
            byte[] bahBytes=Arrays.copyOfRange(bytes,0,bah.getTotalLength()); byte[] body=Arrays.copyOfRange(bytes,bodyOffset,bytes.length);
            List<ByteFieldValue> values=new ArrayList<>(); boolean decodeValid=true;
            for(AppConfig.BahField f:bah.getFields()){
                if (!validBahField(f, bah.getTotalLength())) {
                    decodeValid=false;
                    diagnostics.add(diag("BAH_FIELD_RANGE","BAH",file,raw,stripped.getRemovedBytes(),"BAH フィールド範囲が不正です。"));
                    continue;
                }
                byte[] v=Arrays.copyOfRange(bytes,f.getPosition()-1,f.getPosition()-1+f.getLength());
                DecodedBytes decoded=ByteText.decode(v,input.getCharset());
                if(!decoded.isValid()){
                    decodeValid=false;
                    diagnostics.add(diag("BAH_FIELD_DECODE","BAH",file,raw,stripped.getRemovedBytes()+f.getPosition()-1,
                            "BAH フィールドを "+input.getCharset()+" で厳格に復号できません: "+f.getId()+" hex="+decoded.getHex()));
                }
                values.add(new ByteFieldValue("BAH:"+f.getId(),"BAH",f.getName(),f.getPosition(),f.getLength(),
                        stripped.getRemovedBytes()+f.getPosition()-1,raw.getFileOffset()+stripped.getRemovedBytes()+f.getPosition()-1,v,decoded));
            }
            for(ExpandedField f:selected.getFields()){
                byte[] v=Arrays.copyOfRange(body,f.getZeroBasedOffset(),f.getZeroBasedOffset()+f.getLength());
                DecodedBytes decoded=ByteText.decode(v,input.getCharset());
                if(!decoded.isValid()){decodeValid=false;diagnostics.add(diag("FIELD_DECODE","BODY",file,raw,
                        stripped.getRemovedBytes()+bodyOffset+f.getZeroBasedOffset(),"フィールドを "+input.getCharset()+" で厳格に復号できません: "+f.getInstanceId()+" hex="+decoded.getHex()));}
                values.add(new ByteFieldValue(f.getInstanceId(),"BODY",f.getDefinition().getName(),f.getPosition(),f.getLength(),
                        stripped.getRemovedBytes()+bodyOffset+f.getZeroBasedOffset(),raw.getFileOffset()+stripped.getRemovedBytes()+bodyOffset+f.getZeroBasedOffset(),v,decoded));
            }
            for(RawRange gap:selected.getGaps()){
                byte[] v=Arrays.copyOfRange(body,gap.getPosition()-1,gap.getEndPosition());
                DecodedBytes decoded=ByteText.decode(v,input.getCharset());
                if(!decoded.isValid()){
                    decodeValid=false;
                    diagnostics.add(diag("RAW_DECODE","BODY",file,raw,stripped.getRemovedBytes()+bodyOffset+gap.getPosition()-1,
                            "未割当領域を "+input.getCharset()+" で厳格に復号できません: hex="+decoded.getHex()));
                }
                values.add(new ByteFieldValue("BODY:RAW:"+gap.getPosition(),"BODY_RAW","未割当領域",gap.getPosition(),gap.getLength(),
                        stripped.getRemovedBytes()+bodyOffset+gap.getPosition()-1,raw.getFileOffset()+stripped.getRemovedBytes()+bodyOffset+gap.getPosition()-1,v,decoded));
            }
            if(!decodeValid){stats.failedSelectedRecords++;continue;}
            stats.parsedSelectedRecords++;
            records.add(new ParsedRecord(file,raw.getRecordNumber(),raw.getFileOffset(),raw.getLength(),stripped.getRemovedBytes(),
                    new MessageKey(message.value,bs.value,doc.value),raw.getBytes(),bytes,bahBytes,body,values,stripped.getTraces()));
        }
        return new InputSideResult(stats,records,diagnostics,framed.getDetectedSeparator());
    }

    private Map<AppConfig.BahRole,KeyPart> keyParts(byte[] bytes,AppConfig.BahConfig bah,String charset,List<Diagnostic>d,Path file,FramedRecord raw,int removed){
        Map<AppConfig.BahRole,KeyPart> values=new EnumMap<>(AppConfig.BahRole.class);
        for(AppConfig.BahField f:bah.getFields())if(f!=null&&(f.getRole()==AppConfig.BahRole.MESSAGE_ID||f.getRole()==AppConfig.BahRole.BS_CODE||f.getRole()==AppConfig.BahRole.DOCUMENT_ID)){
            if(!validBahField(f,bah.getTotalLength())){continue;}
            byte[] v=Arrays.copyOfRange(bytes,f.getPosition()-1,f.getPosition()-1+f.getLength());DecodedBytes decoded=ByteText.decode(v,charset);
            if(!decoded.isValid()){d.add(diag("BAH_DECODE","BAH",file,raw,removed+f.getPosition()-1,"BAH キーを "+charset+" で復号できません: hex="+decoded.getHex()));values.put(f.getRole(),new KeyPart(null,false));}
            else{String text=decoded.getText();if(f.isTrimHalfWidthSpacePadding())text=trimHalfWidth(text);values.put(f.getRole(),new KeyPart(text,true));}
        }
        return values;
    }
    private boolean validKey(KeyPart p,String regex){return p!=null&&p.valid&&p.value!=null&&!p.value.isEmpty()&&p.value.matches(regex);}
    private boolean validBahEnvelope(AppConfig.BahConfig bah){return bah!=null&&bah.getTotalLength()!=null&&bah.getTotalLength()>0&&bah.getBodyStart()!=null&&bah.getBodyStart()==bah.getTotalLength()+1&&bah.getFields()!=null;}
    private boolean validBahField(AppConfig.BahField f,int total){return f!=null&&f.getPosition()!=null&&f.getLength()!=null&&f.getPosition()>0&&f.getLength()>0&&(long)f.getPosition()+f.getLength()-1<=total;}
    private String trimHalfWidth(String s){int start=0,end=s.length();while(start<end&&s.charAt(start)==' ')start++;while(end>start&&s.charAt(end-1)==' ')end--;return s.substring(start,end);}
    private Diagnostic withFile(Diagnostic source,Path file,FramedRecord raw){return new Diagnostic(source.getSeverity(),source.getCode(),source.getStage(),source.getMessage(),source.getSuggestedAction(),new Diagnostic.SourceLocation(file,null,null,null,raw.getRecordNumber(),source.getSource()==null?raw.getFileOffset():source.getSource().getByteOffset()));}
    private Diagnostic diag(String code,String stage,Path file,FramedRecord raw,long recordOffset,String message){return new Diagnostic(Diagnostic.Severity.ERROR,code,stage,message,"設定とレコード境界を確認してください。",new Diagnostic.SourceLocation(file,null,null,null,raw.getRecordNumber(),raw.getFileOffset()+recordOffset));}
    private static final class KeyPart{final String value;final boolean valid;KeyPart(String value,boolean valid){this.value=value;this.valid=valid;}}
}
