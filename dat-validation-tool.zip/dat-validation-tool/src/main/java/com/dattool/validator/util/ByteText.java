package com.dattool.validator.util;

import com.dattool.validator.input.DecodedBytes;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;

/** バイト証拠を変えずに厳格テキストと可視表示を作ります。 */
public final class ByteText {
    private ByteText() {}
    public static DecodedBytes decode(byte[] bytes,String charsetName){
        String hex=hex(bytes);
        try{
            String text=Charset.forName(charsetName).newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            return new DecodedBytes(true,text,visible(text),hex,null);
        }catch(CharacterCodingException|IllegalArgumentException e){return new DecodedBytes(false,null,"<DECODE_ERROR>",hex,e.getMessage());}
    }
    public static String hex(byte[] bytes){StringBuilder s=new StringBuilder(bytes.length*2);for(byte b:bytes)s.append(String.format("%02X",b&0xff));return s.toString();}
    private static String visible(String text){StringBuilder s=new StringBuilder();for(int i=0;i<text.length();i++){char c=text.charAt(i);if(c==' ')s.append('␠');else if(c=='\t')s.append("\\t");else if(c=='\r')s.append("\\r");else if(c=='\n')s.append("\\n");else if(c==0)s.append("\\0");else if(Character.isISOControl(c))s.append(String.format("\\u%04X",(int)c));else s.append(c);}return s.toString();}
}
