package com.dattool.validator.config;

import com.dattool.validator.model.Diagnostic;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** JSON 構文とは別に設定値の相互関係を検証します。 */
public final class ConfigValidator {
    private ConfigValidator() {}

    public static List<Diagnostic> validate(AppConfig c) {
        List<Diagnostic> d = new ArrayList<>();
        if (c == null) {
            d.add(error("CFG_NULL", "$", "設定がありません。"));
            return d;
        }
        if (c.getSchemaVersion() != AppConfig.CURRENT_SCHEMA_VERSION) {
            d.add(error("CFG_SCHEMA_VERSION", "$.schemaVersion",
                    "未対応の schemaVersion です: " + c.getSchemaVersion()));
        }
        if (c.getPaths() == null) d.add(error("CFG_REQUIRED", "$.paths", "paths は必須です。"));
        if (c.getSpecification() == null) d.add(error("CFG_REQUIRED", "$.specification", "specification は必須です。"));
        if (c.getCurrentInput() == null) d.add(error("CFG_REQUIRED", "$.currentInput", "currentInput は必須です。"));
        else validateInput(c.getCurrentInput(), "$.currentInput", d);
        if (c.getNewInput() == null) d.add(error("CFG_REQUIRED", "$.newInput", "newInput は必須です。"));
        else validateInput(c.getNewInput(), "$.newInput", d);
        if (c.getLimits() == null) d.add(error("CFG_REQUIRED", "$.limits", "limits は必須です。"));
        else {
            positive(c.getLimits().getMaxRecordBytes(), "$.limits.maxRecordBytes", d);
            positive(c.getLimits().getMaxExpandedFields(), "$.limits.maxExpandedFields", d);
            positive(c.getLimits().getPreviewRecordLimit(), "$.limits.previewRecordLimit", d);
            positive(c.getLimits().getMaxRecordsInMemory(), "$.limits.maxRecordsInMemory", d);
        }
        if (c.getOutput() == null) d.add(error("CFG_REQUIRED", "$.output", "output は必須です。"));
        else if (c.getOutput().getInlineCellTextLimit() < 1 || c.getOutput().getInlineCellTextLimit() > 32767) {
            d.add(error("CFG_RANGE", "$.output.inlineCellTextLimit", "1～32767 を指定してください。"));
        }
        validateMapping(c.getSpecification(), d);
        validateBah(c.getBah(), d);
        return d;
    }

    private static void validateInput(AppConfig.InputConfig input, String path, List<Diagnostic> d) {
        String cs = input.getCharset();
        if (!("Shift_JIS".equalsIgnoreCase(cs) || "windows-31j".equalsIgnoreCase(cs) || "MS932".equalsIgnoreCase(cs))) {
            d.add(error("CFG_CHARSET", path + ".charset", "Shift_JIS または windows-31j を明示してください。"));
        } else if (!Charset.isSupported(cs)) {
            d.add(error("CFG_CHARSET_UNSUPPORTED", path + ".charset", "この Java では文字セットを利用できません: " + cs));
        }
        if (input.getFraming() == null) d.add(error("CFG_REQUIRED", path + ".framing", "記録形式は必須です。"));
        if (input.getLineSeparator() == null) d.add(error("CFG_REQUIRED", path + ".lineSeparator", "改行形式は必須です。"));
        if (input.getStripSteps() == null) {
            d.add(error("CFG_REQUIRED", path + ".stripSteps", "stripSteps は配列で指定してください。"));
            return;
        }
        for (int i = 0; i < input.getStripSteps().size(); i++) {
            validateStrip(input.getStripSteps().get(i), path + ".stripSteps[" + i + "]", d);
        }
    }

    private static void validateStrip(AppConfig.StripStep s, String path, List<Diagnostic> d) {
        if (s == null || s.getType() == null) {
            d.add(error("CFG_REQUIRED", path + ".type", "削除方式は必須です。"));
            return;
        }
        boolean literal = s.getLiteral() != null && !s.getLiteral().isEmpty();
        boolean hex = s.getHex() != null && !s.getHex().isEmpty();
        if (s.getType() == AppConfig.StripType.FIXED_LENGTH) {
            if (s.getLength() == null || s.getLength() < 0) d.add(error("CFG_RANGE", path + ".length", "0 以上のバイト数が必要です。"));
            if (literal || hex || s.getSearchWindow() != null || s.getIncludeMarker() != null) d.add(error("CFG_EXCLUSIVE", path, "FIXED_LENGTH では文字列、hex、検索窓、includeMarker を指定できません。"));
        } else {
            if (literal == hex) d.add(error("CFG_EXCLUSIVE", path, "literal と hex のどちらか一方だけを指定してください。"));
            if (s.getLength() != null) d.add(error("CFG_EXCLUSIVE", path + ".length", "文字列方式では length を指定できません。"));
            if (hex && !s.getHex().matches("(?i)([0-9a-f]{2})+")) d.add(error("CFG_HEX", path + ".hex", "偶数桁の 16 進文字列を指定してください。"));
            if (s.getType() == AppConfig.StripType.MARKER) {
                if (s.getSearchWindow() == null || s.getSearchWindow() < 1) d.add(error("CFG_RANGE", path + ".searchWindow", "MARKER には正の検索窓が必要です。"));
                if (s.getIncludeMarker() == null) d.add(error("CFG_REQUIRED", path + ".includeMarker", "マーカーを削除に含めるか明示してください。"));
            } else if (s.getSearchWindow() != null || s.getIncludeMarker() != null) {
                d.add(error("CFG_EXCLUSIVE", path, "PREFIX では検索窓と includeMarker を指定できません。"));
            }
        }
    }

    private static void validateMapping(AppConfig.SpecificationConfig spec, List<Diagnostic> d) {
        if (spec == null || spec.getMapping() == null) return;
        AppConfig.MappingConfig m = spec.getMapping();
        positiveNullable(m.getHeaderStartRow(), "$.specification.mapping.headerStartRow", d);
        positiveNullable(m.getHeaderEndRow(), "$.specification.mapping.headerEndRow", d);
        positiveNullable(m.getDataStartRow(), "$.specification.mapping.dataStartRow", d);
        positiveNullable(m.getDataEndRow(), "$.specification.mapping.dataEndRow", d);
        positiveNullable(m.getExpectedBodyLength(), "$.specification.mapping.expectedBodyLength", d);
        if (m.getHeaderStartRow() != null && m.getHeaderEndRow() != null && m.getHeaderStartRow() > m.getHeaderEndRow())
            d.add(error("CFG_ORDER", "$.specification.mapping", "headerStartRow は headerEndRow 以下にしてください。"));
        if (m.getDataStartRow() != null && m.getDataEndRow() != null && m.getDataStartRow() > m.getDataEndRow())
            d.add(error("CFG_ORDER", "$.specification.mapping", "dataStartRow は dataEndRow 以下にしてください。"));
        if (m.getColumns() != null) for (Map.Entry<String, Integer> e : m.getColumns().entrySet())
            positiveNullable(e.getValue(), "$.specification.mapping.columns." + e.getKey(), d);
        Set<String> ids = new HashSet<>();
        if (m.getRepeatBindings() != null) for (int i = 0; i < m.getRepeatBindings().size(); i++) {
            AppConfig.RepeatBinding b = m.getRepeatBindings().get(i);
            String p = "$.specification.mapping.repeatBindings[" + i + "]";
            if (blank(b.getId())) d.add(error("CFG_REQUIRED", p + ".id", "繰返し ID は必須です。"));
            else if (!ids.add(b.getId())) d.add(error("CFG_DUPLICATE", p + ".id", "繰返し ID が重複しています。"));
            if (blank(b.getVariable())) d.add(error("CFG_REQUIRED", p + ".variable", "位置式の変数名は必須です。"));
            positiveNullable(b.getMaxCount(), p + ".maxCount", d);
        }
    }

    private static void validateBah(AppConfig.BahConfig b, List<Diagnostic> d) {
        if (b == null) { d.add(error("CFG_REQUIRED", "$.bah", "bah は必須です。")); return; }
        if (b.getMode() == null) d.add(error("CFG_REQUIRED", "$.bah.mode", "BAH モードは必須です。"));
        if (b.getTotalLength() == null && (b.getBodyStart() != null || (b.getFields() != null && !b.getFields().isEmpty())))
            d.add(error("CFG_REQUIRED", "$.bah.totalLength", "BAH の境界を設定してください。"));
        if (b.getTotalLength() != null) {
            positiveNullable(b.getTotalLength(), "$.bah.totalLength", d);
            positiveNullable(b.getBodyStart(), "$.bah.bodyStart", d);
            if (b.getBodyStart() != null && b.getBodyStart() != b.getTotalLength() + 1)
                d.add(error("CFG_BAH_BOUNDARY", "$.bah.bodyStart", "本文開始位置は BAH 長 + 1 と一致させてください。"));
            Set<AppConfig.BahRole> required = EnumSet.of(AppConfig.BahRole.DOCUMENT_ID, AppConfig.BahRole.MESSAGE_ID, AppConfig.BahRole.BS_CODE);
            Set<AppConfig.BahRole> found = EnumSet.noneOf(AppConfig.BahRole.class);
            Set<String> ids = new HashSet<>();
            if (b.getFields() != null) for (int i = 0; i < b.getFields().size(); i++) {
                AppConfig.BahField f = b.getFields().get(i);
                String p = "$.bah.fields[" + i + "]";
                if (blank(f.getId())) d.add(error("CFG_REQUIRED", p + ".id", "BAH フィールド ID は必須です。"));
                else if (!ids.add(f.getId())) d.add(error("CFG_DUPLICATE", p + ".id", "BAH フィールド ID が重複しています。"));
                positiveNullable(f.getPosition(), p + ".position", d);
                positiveNullable(f.getLength(), p + ".length", d);
                if (f.getRole() != null) found.add(f.getRole());
                if (f.getPosition() != null && f.getLength() != null && f.getPosition() > 0 && f.getLength() > 0
                        && (long) f.getPosition() + f.getLength() - 1 > b.getTotalLength())
                    d.add(error("CFG_BAH_RANGE", p, "フィールドが BAH 範囲を超えています。"));
            }
            for (AppConfig.BahRole role : required) if (!found.contains(role))
                d.add(error("CFG_BAH_KEY", "$.bah.fields", "配対キーの役割がありません: " + role));
        }
    }

    private static void positive(int value, String path, List<Diagnostic> d) {
        if (value < 1) d.add(error("CFG_RANGE", path, "正の整数を指定してください。"));
    }
    private static void positiveNullable(Integer value, String path, List<Diagnostic> d) {
        if (value != null && value < 1) d.add(error("CFG_RANGE", path, "正の整数を指定してください。"));
    }
    private static boolean blank(String value) { return value == null || value.trim().isEmpty(); }
    private static Diagnostic error(String code, String path, String message) {
        return Diagnostic.error(code, "CONFIG", path + ": " + message, "設定 JSON の該当項目を修正してください。");
    }
}
