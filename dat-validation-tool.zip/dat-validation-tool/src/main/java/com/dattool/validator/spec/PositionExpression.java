package com.dattool.validator.spec;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** 整数、変数、括弧、四則演算だけを扱う安全な位置式です。 */
public final class PositionExpression {
    private PositionExpression() {}

    public static long evaluate(String expression, Map<String, Long> variables) throws ExpressionException {
        if (expression == null || expression.trim().isEmpty()) throw new ExpressionException("位置式が空です。");
        Parser p = new Parser(expression, variables == null ? Collections.emptyMap() : variables);
        long value = p.expression();
        p.skipSpaces();
        if (!p.end()) throw p.error("使用できない文字です: " + p.peek());
        return value;
    }

    public static Set<String> variables(String expression) throws ExpressionException {
        Set<String> result = new LinkedHashSet<>();
        Parser p = new Parser(expression, Collections.emptyMap());
        p.collectOnly = result;
        p.expression();
        p.skipSpaces();
        if (!p.end()) throw p.error("使用できない文字です: " + p.peek());
        return result;
    }

    public static final class ExpressionException extends Exception {
        ExpressionException(String message) { super(message); }
    }

    private static final class Parser {
        private final String text;
        private final Map<String, Long> vars;
        private int index;
        private Set<String> collectOnly;

        private Parser(String text, Map<String, Long> vars) { this.text = text; this.vars = vars; }

        private long expression() throws ExpressionException {
            long value = term();
            while (true) {
                skipSpaces();
                if (take('+')) value = add(value, term());
                else if (take('-')) value = subtract(value, term());
                else return value;
            }
        }

        private long term() throws ExpressionException {
            long value = unary();
            while (true) {
                skipSpaces();
                if (take('*')) value = multiply(value, unary());
                else if (take('/')) {
                    long divisor = unary();
                    if (divisor == 0) throw error("0 で除算できません。");
                    if (value % divisor != 0) throw error("除算結果が整数ではありません。");
                    value /= divisor;
                } else return value;
            }
        }

        private long unary() throws ExpressionException {
            skipSpaces();
            if (take('+')) return unary();
            if (take('-')) return negate(unary());
            if (take('(')) {
                long value = expression();
                skipSpaces();
                if (!take(')')) throw error("閉じ括弧がありません。");
                return value;
            }
            if (!end() && Character.isDigit(peek())) return number();
            if (!end() && (Character.isLetter(peek()) || peek() == '_')) return variable();
            throw error("整数、変数または括弧が必要です。");
        }

        private long number() throws ExpressionException {
            int start = index;
            while (!end() && Character.isDigit(peek())) index++;
            try { return Long.parseLong(text.substring(start, index)); }
            catch (NumberFormatException e) { throw error("整数が大きすぎます。"); }
        }

        private long variable() throws ExpressionException {
            int start = index++;
            while (!end() && (Character.isLetterOrDigit(peek()) || peek() == '_')) index++;
            String name = text.substring(start, index);
            if (collectOnly != null) { collectOnly.add(name); return 1; }
            Long value = vars.get(name);
            if (value == null) throw error("未設定の変数です: " + name);
            return value;
        }

        private long add(long a, long b) throws ExpressionException { try { return Math.addExact(a, b); } catch (ArithmeticException e) { throw error("加算がオーバーフローしました。"); } }
        private long subtract(long a, long b) throws ExpressionException { try { return Math.subtractExact(a, b); } catch (ArithmeticException e) { throw error("減算がオーバーフローしました。"); } }
        private long multiply(long a, long b) throws ExpressionException { try { return Math.multiplyExact(a, b); } catch (ArithmeticException e) { throw error("乗算がオーバーフローしました。"); } }
        private long negate(long a) throws ExpressionException { try { return Math.negateExact(a); } catch (ArithmeticException e) { throw error("符号反転がオーバーフローしました。"); } }
        private void skipSpaces() { while (!end() && Character.isWhitespace(peek())) index++; }
        private boolean take(char c) { if (!end() && peek() == c) { index++; return true; } return false; }
        private char peek() { return text.charAt(index); }
        private boolean end() { return index >= text.length(); }
        private ExpressionException error(String message) { return new ExpressionException(message + " (位置 " + (index + 1) + ")"); }
    }
}
