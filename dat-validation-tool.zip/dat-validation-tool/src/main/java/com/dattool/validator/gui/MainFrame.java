package com.dattool.validator.gui;

import com.dattool.validator.compare.ComparisonRunResult;
import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.AppConfigLoader;
import com.dattool.validator.config.ConfigException;
import com.dattool.validator.config.ConfigValidator;
import com.dattool.validator.config.PreflightValidator;
import com.dattool.validator.config.ResolvedRunConfiguration;
import com.dattool.validator.input.InputPreviewService;
import com.dattool.validator.input.InputProcessor;
import com.dattool.validator.input.InputSideResult;
import com.dattool.validator.input.ParsedRecord;
import com.dattool.validator.model.Diagnostic;
import com.dattool.validator.model.ExitCodeMapper;
import com.dattool.validator.service.ComparisonExecutionService;
import com.dattool.validator.service.ExecutionResult;
import com.dattool.validator.service.TaskContext;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.spec.LayoutSelector;
import com.dattool.validator.spec.SpecAnalysisResult;
import com.dattool.validator.spec.WorkbookSpecAnalyzer;
import net.miginfocom.swing.MigLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** 四つの主要パスを中心に、分析・プレビュー・比較を非同期実行する画面です。 */
public final class MainFrame extends JFrame {
    private final JTextField spec=new JTextField(),current=new JTextField(),newer=new JTextField(),output=new JTextField(),configPath=new JTextField();
    private final JTextField messageId=new JTextField(),bsCode=new JTextField(),sheet=new JTextField();
    private final JTextArea json=new JTextArea(18,80),log=new JTextArea(),preview=new JTextArea();private final DefaultTableModel fields=new DefaultTableModel(new Object[]{"instanceId","role","位置","長さ","名称","source"},0);
    private final JProgressBar progress=new JProgressBar(0,100);private final JLabel result=new JLabel("未実行");private final List<JButton> runControls=new ArrayList<>();private volatile boolean running;private Path lastReport,lastDirectory;
    public MainFrame(){super("DAT 固定長電文比較ツール");setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);setMinimumSize(new Dimension(980,680));setSize(1180,780);setLocationRelativeTo(null);build();loadDefault();addWindowListener(new WindowAdapter(){@Override public void windowClosing(WindowEvent e){if(running){JOptionPane.showMessageDialog(MainFrame.this,"処理中は強制終了しません。完了後に閉じてください。","処理中",JOptionPane.WARNING_MESSAGE);}else dispose();}});}
    private void build(){spec.setName("specificationPath");current.setName("currentPath");newer.setName("newPath");output.setName("outputPath");configPath.setName("configPath");messageId.setName("messageId");bsCode.setName("bsCode");sheet.setName("sheet");json.setName("advancedConfig");log.setName("taskLog");preview.setName("messagePreview");progress.setName("progress");result.setName("resultSummary");JPanel paths=new JPanel(new MigLayout("fillx,insets 10","[][grow,fill][]",""));addPath(paths,"STPCOM 仕様書",spec,false);addPath(paths,"現比較ファイル",current,false);addPath(paths,"新比較ファイル",newer,false);addPath(paths,"出力結果 (.xlsx)",output,true);addPath(paths,"共用設定 JSON",configPath,false);
        JPanel selectors=new JPanel(new MigLayout("fillx,insets 8","[][grow,fill][][grow,fill][][grow,fill]",""));selectors.setBorder(BorderFactory.createTitledBorder("対象電文タイプ"));selectors.add(new JLabel("message ID"));selectors.add(messageId);selectors.add(new JLabel("完全 BSCode"));selectors.add(bsCode);selectors.add(new JLabel("sheet"));selectors.add(sheet,"wrap");
        JButton load=button("設定読込",this::loadConfig),save=button("設定保存",this::saveConfig),analyze=button("仕様分析",this::analyze),previewCurrent=button("現をプレビュー",()->preview(true)),previewNew=button("新をプレビュー",()->preview(false)),clear=button("クリア",this::clear),start=button("比較開始",this::start),open=button("Excel を開く",this::openReport),openDir=button("結果フォルダー",this::openDirectory);JPanel actions=new JPanel(new MigLayout("insets 8","[][][][][][][grow][][]",""));actions.add(load);actions.add(save);actions.add(analyze);actions.add(previewCurrent);actions.add(previewNew);actions.add(clear);actions.add(start,"gapleft push");actions.add(open);actions.add(openDir);
        JTabbedPane tabs=new JTabbedPane();JTable table=new JTable(fields);table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);tabs.addTab("仕様フィールド",new JScrollPane(table));preview.setEditable(false);tabs.addTab("電文プレビュー",new JScrollPane(preview));json.setFont(new java.awt.Font(java.awt.Font.MONOSPACED,java.awt.Font.PLAIN,12));tabs.addTab("高度設定・mapping・BAH (JSON)",new JScrollPane(json));log.setEditable(false);log.setRows(8);JSplitPane split=new JSplitPane(JSplitPane.VERTICAL_SPLIT,tabs,new JScrollPane(log));split.setResizeWeight(.72);
        JPanel status=new JPanel(new MigLayout("fillx,insets 6","[grow,fill][]",""));progress.setStringPainted(true);status.add(progress);status.add(result);setLayout(new BorderLayout());JPanel north=new JPanel(new BorderLayout());north.add(paths,BorderLayout.NORTH);north.add(selectors,BorderLayout.CENTER);north.add(actions,BorderLayout.SOUTH);add(north,BorderLayout.NORTH);add(split,BorderLayout.CENTER);add(status,BorderLayout.SOUTH);}
    private void addPath(JPanel panel,String label,JTextField field,boolean save){panel.add(new JLabel(label));panel.add(field);JButton browse=button("参照...",()->choose(field,save));panel.add(browse,"wrap");}
    private JButton button(String text,Runnable action){JButton b=new JButton(text);b.setName("button."+text);b.addActionListener(e->action.run());runControls.add(b);return b;}
    private void choose(JTextField target,boolean save){JFileChooser fc=new JFileChooser(lastDirectory==null?Path.of("").toFile():lastDirectory.toFile());int answer=save?fc.showSaveDialog(this):fc.showOpenDialog(this);if(answer==JFileChooser.APPROVE_OPTION){target.setText(fc.getSelectedFile().getAbsolutePath());lastDirectory=fc.getSelectedFile().toPath().toAbsolutePath().getParent();}}
    private void loadDefault(){Path sample=Path.of("examples","synthetic","config.synthetic.json").toAbsolutePath();if(java.nio.file.Files.isRegularFile(sample)){configPath.setText(sample.toString());loadConfig();}}
    private void loadConfig(){try{Path p=Path.of(configPath.getText().trim()).toAbsolutePath();AppConfig c=AppConfigLoader.load(p);json.setText(AppConfigLoader.toJson(c));Path base=p.getParent();spec.setText(resolveDisplay(base,c.getPaths().getSpecification()));current.setText(resolveDisplay(base,c.getPaths().getCurrent()));newer.setText(resolveDisplay(base,c.getPaths().getNewer()));output.setText(resolveDisplay(base,c.getPaths().getOutput()));messageId.setText(nvl(c.getSpecification().getMessageId()));bsCode.setText(nvl(c.getSpecification().getBsCode()));sheet.setText(nvl(c.getSpecification().getSheet()));lastDirectory=base;append("設定を読み込みました: "+p);}catch(Exception e){error("設定読込",e);}}
    private void saveConfig(){try{AppConfig c=configFromUi();JFileChooser fc=new JFileChooser(lastDirectory==null?Path.of("").toFile():lastDirectory.toFile());if(!configPath.getText().trim().isEmpty())fc.setSelectedFile(Path.of(configPath.getText().trim()).toFile());if(fc.showSaveDialog(this)==JFileChooser.APPROVE_OPTION){Path p=fc.getSelectedFile().toPath().toAbsolutePath();AppConfigLoader.save(c,p);configPath.setText(p.toString());json.setText(AppConfigLoader.toJson(c));append("設定を保存しました: "+p);}}catch(Exception e){error("設定保存",e);}}
    private AppConfig configFromUi()throws ConfigException{AppConfig c=AppConfigLoader.fromJson(json.getText());c.getPaths().setSpecification(spec.getText().trim());c.getPaths().setCurrent(current.getText().trim());c.getPaths().setNewer(newer.getText().trim());c.getPaths().setOutput(output.getText().trim());c.getSpecification().setMessageId(empty(messageId.getText()));c.getSpecification().setBsCode(empty(bsCode.getText()));c.getSpecification().setSheet(empty(sheet.getText()));List<Diagnostic>d=ConfigValidator.validate(c);if(!d.isEmpty())throw new ConfigException(d.get(0).getMessage());json.setText(AppConfigLoader.toJson(c));return c;}
    private ResolvedRunConfiguration request(AppConfig c){return GuiRunRequestFactory.create(c,empty(configPath.getText())==null?null:Path.of(configPath.getText()).toAbsolutePath(),spec.getText(),current.getText(),newer.getText(),output.getText());}
    private void analyze(){background("仕様分析",()->{AppConfig c=configFromUi();SpecAnalysisResult a=new WorkbookSpecAnalyzer().analyze(request(c).getSpecification(),c);if(a.hasErrors())throw new IllegalArgumentException(a.getDiagnostics().get(0).getMessage());SwingUtilities.invokeLater(()->showLayouts(a,c));return null;});}
    private void showLayouts(SpecAnalysisResult a,AppConfig c){fields.setRowCount(0);for(CompiledLayout l:a.getCandidates()){for(com.dattool.validator.spec.ExpandedField f:l.getFields())fields.addRow(new Object[]{f.getInstanceId(),"BODY",f.getPosition(),f.getLength(),f.getDefinition().getName(),f.getDefinition().getSource().display()});}append("仕様候補="+a.getCandidates().size()+"。対象が複数なら message ID／完全 BSCode／sheet を明示してください。");}
    private void preview(boolean left){background("電文プレビュー",()->{AppConfig c=configFromUi();ResolvedRunConfiguration r=request(c);SpecAnalysisResult a=new WorkbookSpecAnalyzer().analyze(r.getSpecification(),c);CompiledLayout layout=LayoutSelector.select(a.getCandidates(),c.getSpecification().getMessageId(),c.getSpecification().getBsCode(),c.getSpecification().getVariant(),c.getSpecification().getSheet());InputSideResult ir=new InputProcessor().process(left?r.getCurrent():r.getNewer(),left?c.getCurrentInput():c.getNewInput(),c.getBah(),layout,c.getLimits());List<ParsedRecord> records=new InputPreviewService().first(ir,c.getLimits().getPreviewRecordLimit());StringBuilder b=new StringBuilder();b.append("separator=").append(ir.getDetectedSeparator()).append(" total=").append(ir.getStatistics().getTotalRecords()).append(" parsed=").append(ir.getStatistics().getParsedSelectedRecords()).append('\n');for(ParsedRecord x:records){b.append('#').append(x.getRecordNumber()).append(" fileOffset=").append(x.getOriginalFileOffset()).append(" removed=").append(x.getRemovedBytes()).append(" bodyStart(record,0-based)=").append(x.getRemovedBytes()+c.getBah().getBodyStart()-1).append(" key=").append(x.getKey()).append('\n');x.getStripTraces().forEach(t->b.append("  strip ").append(t.getStep()).append(' ').append(t.getType()).append(" original[").append(t.getOriginalStart()).append(',').append(t.getOriginalEndExclusive()).append(")\n"));x.getFields().stream().limit(12).forEach(f->b.append("  ").append(f.getInstanceId()).append(" pos=").append(f.getPosition()).append(" len=").append(f.getLength()).append(" value=").append(f.getDecoded().getVisible()).append('\n'));}ir.getDiagnostics().forEach(d->b.append("ERROR ").append(d.getCode()).append(' ').append(d.getMessage()).append('\n'));SwingUtilities.invokeLater(()->preview.setText(b.toString()));return null;});}
    private void start(){background("比較",()->{AppConfig c=configFromUi();ResolvedRunConfiguration r=request(c);List<Diagnostic> pre=PreflightValidator.validate(r,false);if(!pre.isEmpty())throw new IllegalArgumentException(pre.get(0).getMessage());TaskContext ctx=TaskContext.create(c,d->SwingUtilities.invokeLater(()->append(d.getCode()+": "+d.getMessage())),(p,s,m)->SwingUtilities.invokeLater(()->{progress.setValue(p);progress.setString(s+" "+m);}));ExecutionResult e=new ComparisonExecutionService().execute(r,ctx,true);lastReport=e.getReport();ComparisonRunResult cr=e.getComparison();int code=ExitCodeMapper.toExitCode(cr.getResult());SwingUtilities.invokeLater(()->result.setText("終了 "+code+" / "+cr.getResult().getEquality()+" / "+cr.getResult().getCompleteness()));return null;});}
    private void background(String name,Work work){if(running)return;running=true;setControls(false);progress.setValue(0);append(name+"を開始しました。");new SwingWorker<Void,Void>(){@Override protected Void doInBackground()throws Exception{return work.run();}@Override protected void done(){try{get();append(name+"が完了しました。");}catch(Exception e){Throwable x=e.getCause()==null?e:e.getCause();error(name,x);result.setText("失敗: "+x.getMessage());}finally{running=false;setControls(true);}}}.execute();}
    private void setControls(boolean enabled){for(JButton b:runControls)b.setEnabled(enabled);spec.setEnabled(enabled);current.setEnabled(enabled);newer.setEnabled(enabled);output.setEnabled(enabled);configPath.setEnabled(enabled);messageId.setEnabled(enabled);bsCode.setEnabled(enabled);sheet.setEnabled(enabled);json.setEditable(enabled);}
    private void clear(){spec.setText("");current.setText("");newer.setText("");output.setText("");messageId.setText("");bsCode.setText("");sheet.setText("");fields.setRowCount(0);preview.setText("");log.setText("");result.setText("未実行");progress.setValue(0);}
    private void openReport(){open(lastReport,false);}private void openDirectory(){open(lastReport==null?null:lastReport.getParent(),true);}private void open(Path p,boolean directory){try{if(p==null)throw new IllegalStateException("開く結果がありません。");if(!Desktop.isDesktopSupported())throw new IllegalStateException("Desktop API を利用できません。");if(directory)Desktop.getDesktop().open(p.toFile());else Desktop.getDesktop().open(p.toFile());}catch(Exception e){error("結果を開く",e);}}
    private void append(String text){log.append(text+System.lineSeparator());log.setCaretPosition(log.getDocument().getLength());}private void error(String title,Throwable e){append(title+"失敗: "+e.getMessage());JOptionPane.showMessageDialog(this,e.getMessage(),title,JOptionPane.ERROR_MESSAGE);}
    private String resolveDisplay(Path base,String value){if(value==null)return "";Path p=Path.of(value);return (p.isAbsolute()?p:base.resolve(p)).normalize().toString();}private String nvl(String s){return s==null?"":s;}private String empty(String s){return s==null||s.trim().isEmpty()?null:s.trim();}
    @FunctionalInterface private interface Work{Void run()throws Exception;}
}
