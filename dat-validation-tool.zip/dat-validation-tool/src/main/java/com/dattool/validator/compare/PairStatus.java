package com.dattool.validator.compare;

public enum PairStatus { PAIRED_EQUAL, PAIRED_DIFFERENT, CURRENT_ONLY, NEW_ONLY, AMBIGUOUS_KEY }
