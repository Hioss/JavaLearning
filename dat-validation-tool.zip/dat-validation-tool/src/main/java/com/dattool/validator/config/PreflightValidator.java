package com.dattool.validator.config;

import com.dattool.validator.model.Diagnostic;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** 入力を変更する前にパス衝突と上書き条件を検証します。 */
public final class PreflightValidator {
    private PreflightValidator() {}

    public static List<Diagnostic> validate(ResolvedRunConfiguration run, boolean analyzeOnly) {
        List<Diagnostic> result = new ArrayList<>();
        requireInput(run.getSpecification(), "--spec", result);
        if (!analyzeOnly) {
            requireInput(run.getCurrent(), "--current", result);
            requireInput(run.getNewer(), "--new", result);
            requireOutput(run.getOutput(), result);
        }
        Path output = normalized(run.getOutput());
        if (output != null) {
            checkConflict(output, run.getSpecification(), "仕様書", result);
            checkConflict(output, run.getCurrent(), "現行ファイル", result);
            checkConflict(output, run.getNewer(), "新ファイル", result);
            checkConflict(output, run.getConfigFile(), "設定ファイル", result);
            checkConflict(output, run.getBahSpecification(), "BAH 仕様書", result);
            if (Files.exists(output) && !run.getConfig().getOutput().isOverwrite())
                result.add(Diagnostic.error("OUTPUT_EXISTS", "PREFLIGHT", "出力ファイルは既に存在します: " + output,
                        "--overwrite または output.overwrite=true を明示してください。"));
        }
        return result;
    }

    private static void require(Path path, String option, List<Diagnostic> result) {
        if (path == null) result.add(Diagnostic.error("PATH_REQUIRED", "PREFLIGHT", "必須パスがありません: " + option, option + " を指定してください。"));
    }
    private static void requireInput(Path path,String option,List<Diagnostic> result){require(path,option,result);if(path!=null&&(!Files.isRegularFile(path)||!Files.isReadable(path)))result.add(Diagnostic.error("INPUT_UNREADABLE","PREFLIGHT","入力ファイルを読み取れません: "+path,"存在する読み取り可能なファイルを "+option+" に指定してください。"));}
    private static void requireOutput(Path path,List<Diagnostic> result){require(path,"--output",result);if(path==null)return;if(!path.getFileName().toString().toLowerCase().endsWith(".xlsx"))result.add(Diagnostic.error("OUTPUT_EXTENSION","PREFLIGHT","出力拡張子は .xlsx が必要です: "+path,"--output に .xlsx ファイルを指定してください。"));Path parent=path.toAbsolutePath().getParent();while(parent!=null&&!Files.exists(parent))parent=parent.getParent();if(parent==null||!Files.isDirectory(parent)||!Files.isWritable(parent))result.add(Diagnostic.error("OUTPUT_UNWRITABLE","PREFLIGHT","出力親ディレクトリへ書き込めません: "+path,"書込み可能な出力先を指定してください。"));}
    private static void checkConflict(Path output, Path input, String label, List<Diagnostic> result) {
        if (input != null && output.equals(normalized(input)))
            result.add(Diagnostic.error("OUTPUT_INPUT_CONFLICT", "PREFLIGHT", "出力先が " + label + " と同じです: " + output,
                    "別の出力ファイルを指定してください。"));
    }
    private static Path normalized(Path path) { return path == null ? null : path.toAbsolutePath().normalize(); }
}
