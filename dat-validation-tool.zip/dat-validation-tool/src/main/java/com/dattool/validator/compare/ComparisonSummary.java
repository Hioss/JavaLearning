package com.dattool.validator.compare;

/** 比較結果の数量。paired includes equal and different pairs. */
public final class ComparisonSummary {
    long paired; long equalPairs; long differentPairs; long currentOnly; long newOnly; long ambiguousGroups; long fieldDifferences;
    public long getPaired(){return paired;} public long getEqualPairs(){return equalPairs;} public long getDifferentPairs(){return differentPairs;}
    public long getCurrentOnly(){return currentOnly;} public long getNewOnly(){return newOnly;} public long getAmbiguousGroups(){return ambiguousGroups;} public long getFieldDifferences(){return fieldDifferences;}
}
