package com.dattool.validator.gui;

import com.formdev.flatlaf.FlatLightLaf;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;

/**
 * Standalone acceptance harness loaded with the packaged JAR and app-image runtime.
 * It intentionally has no JUnit dependency so the release command can run it directly.
 */
public final class GuiAppImageSmokeHarness {
    private GuiAppImageSmokeHarness() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("root, output and charset are required");
        Path root = Path.of(args[0]).toAbsolutePath();
        Path output = Path.of(args[1]).toAbsolutePath();
        String charset = args[2];
        Files.createDirectories(output.getParent());

        FlatLightLaf.setup();
        UIManager.put("defaultFont", new Font("Yu Gothic UI", Font.PLAIN, 13));
        AtomicReference<MainFrame> ref = new AtomicReference<>();
        SwingUtilities.invokeAndWait(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
            named(frame, JTextField.class, "currentPath").setText(root.resolve("examples/synthetic/messages/current.dat").toString());
            named(frame, JTextField.class, "newPath").setText(root.resolve("examples/synthetic/messages/new-equal-reordered.dat").toString());
            named(frame, JTextField.class, "outputPath").setText(output.toString());
            JTextArea json = named(frame, JTextArea.class, "advancedConfig");
            json.setText(json.getText().replace("\"charset\" : \"Shift_JIS\"", "\"charset\" : \"" + charset + "\""));
            ref.set(frame);
        });

        MainFrame frame = ref.get();
        try {
            JButton analyze = named(frame, JButton.class, "button.仕様分析");
            click(analyze);
            waitFor(() -> onEdt(analyze::isEnabled), Duration.ofSeconds(20));

            JButton preview = named(frame, JButton.class, "button.現をプレビュー");
            click(preview);
            waitFor(() -> onEdt(preview::isEnabled), Duration.ofSeconds(20));
            require(onEdt(() -> named(frame, JTextArea.class, "messagePreview").getText().contains("parsed=")), "preview did not complete");

            JButton start = named(frame, JButton.class, "button.比較開始");
            click(start);
            waitFor(() -> onEdt(start::isEnabled), Duration.ofSeconds(45));
            require(Files.isRegularFile(output), "report was not generated");
            String summary = text(frame, "resultSummary");
            require(summary.contains("EQUAL") && summary.contains("COMPLETE"), "unexpected result: " + summary);
            System.out.println("APP_IMAGE_GUI_SMOKE_OK charset=" + charset + " report=" + output);
        } finally {
            SwingUtilities.invokeAndWait(frame::dispose);
        }
    }

    private static void click(JButton button) throws Exception {
        SwingUtilities.invokeAndWait(button::doClick);
    }

    private static String text(MainFrame frame, String name) {
        AtomicReference<String> value = new AtomicReference<>();
        try {
            SwingUtilities.invokeAndWait(() -> value.set(named(frame, JLabel.class, name).getText()));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
        return value.get();
    }

    private static void waitFor(BooleanSupplier condition, Duration timeout) throws Exception {
        Instant deadline = Instant.now().plus(timeout);
        while (!condition.getAsBoolean() && Instant.now().isBefore(deadline)) Thread.sleep(50);
        require(condition.getAsBoolean(), "timed out waiting for Swing operation");
    }

    private static boolean onEdt(BooleanSupplier supplier) {
        if (SwingUtilities.isEventDispatchThread()) return supplier.getAsBoolean();
        AtomicReference<Boolean> value = new AtomicReference<>();
        try {
            SwingUtilities.invokeAndWait(() -> value.set(supplier.getAsBoolean()));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
        return value.get();
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }

    private static <T extends Component> T named(Container root, Class<T> type, String name) {
        for (Component component : root.getComponents()) {
            if (type.isInstance(component) && name.equals(component.getName())) return type.cast(component);
            if (component instanceof Container) {
                try {
                    return named((Container) component, type, name);
                } catch (IllegalArgumentException ignored) {
                    // Continue with the next branch.
                }
            }
        }
        throw new IllegalArgumentException("Component not found: " + type.getSimpleName() + " / " + name);
    }
}
