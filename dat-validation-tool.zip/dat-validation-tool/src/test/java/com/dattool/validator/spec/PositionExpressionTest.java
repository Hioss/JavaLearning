package com.dattool.validator.spec;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PositionExpressionTest {
    @Test void evaluatesPrecedenceParenthesesAndExactDivision() throws Exception {
        assertEquals(764, PositionExpression.evaluate("39+25*(a-1)", Map.of("a", 30L)));
        assertEquals(9, PositionExpression.evaluate("(4+5)*2/2", Map.of()));
        assertThrows(PositionExpression.ExpressionException.class, () -> PositionExpression.evaluate("5/2", Map.of()));
    }
    @Test void rejectsUnknownFunctionsVariablesSymbolsAndOverflow() {
        assertThrows(PositionExpression.ExpressionException.class, () -> PositionExpression.evaluate("max(1,2)", Map.of()));
        assertThrows(PositionExpression.ExpressionException.class, () -> PositionExpression.evaluate("1+a", Map.of()));
        assertThrows(PositionExpression.ExpressionException.class, () -> PositionExpression.evaluate("1;2", Map.of()));
        assertThrows(PositionExpression.ExpressionException.class, () -> PositionExpression.evaluate("9223372036854775807+1", Map.of()));
    }
}
