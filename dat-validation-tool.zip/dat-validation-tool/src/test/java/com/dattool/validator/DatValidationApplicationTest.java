package com.dattool.validator;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class DatValidationApplicationTest {
    @Test void helpIsRealAndSuccessful() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int code = DatValidationApplication.run(new String[]{"--help"}, new PrintStream(out), System.err, Path.of("."));
        assertEquals(0, code);
        assertTrue(out.toString().contains("--analyze-spec"));
    }
    @Test void rejectsUnknownArgument() {
        int code = DatValidationApplication.run(new String[]{"--unknown"}, System.out, System.err, Path.of("."));
        assertEquals(2, code);
    }
    @Test void compiledApplicationTargetsJava11Bytecode() throws Exception {
        byte[] bytes = DatValidationApplication.class.getResourceAsStream("/com/dattool/validator/DatValidationApplication.class").readAllBytes();
        int major = ((bytes[6] & 0xff) << 8) | (bytes[7] & 0xff);
        assertEquals(55, major);
    }
}
