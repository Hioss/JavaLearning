package com.dattool.validator.report;

import com.dattool.validator.compare.ComparisonEngine;
import com.dattool.validator.compare.ComparisonRunResult;
import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.AppConfigLoader;
import com.dattool.validator.input.InputProcessor;
import com.dattool.validator.input.InputSideResult;
import com.dattool.validator.service.TaskContext;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.spec.LayoutSelector;
import com.dattool.validator.spec.SpecAnalysisResult;
import com.dattool.validator.spec.WorkbookSpecAnalyzer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class ComparisonReportWriterTest {
    @TempDir Path temp;
    @Test void writesReadablePagedWorkbookManifestAndLosslessIntermediateData() throws Exception {
        Fixture f=fixture();f.config.getOutput().setInlineCellTextLimit(32767);TaskContext context=TaskContext.create(f.config,d->{},(p,s,m)->{});Path report=temp.resolve("比較 結果.xlsx");
        ReportOutputs outputs=new ComparisonReportWriter(new ReportLimits(4,8)).write(report,f.result,f.layout,f.config,context);
        assertTrue(Files.isRegularFile(outputs.getReport()));assertTrue(Files.isRegularFile(outputs.getManifest()));
        try(Workbook wb=WorkbookFactory.create(outputs.getReport().toFile())){
            assertNotNull(wb.getSheet("実行概要"));assertNotNull(wb.getSheet("項目定義"));assertNotNull(wb.getSheet("差異明細"));
            long comparisonSheets=java.util.stream.IntStream.range(0,wb.getNumberOfSheets()).mapToObj(wb::getSheetAt).filter(s->s.getSheetName().startsWith("電文対照")).count();assertTrue(comparisonSheets>1);
            assertEquals(CellType.STRING,wb.getSheet("項目定義").getRow(1).getCell(3).getCellType());
            assertTrue(wb.getNumCellStyles()<20);
        }
        JsonNode manifest=new ObjectMapper().readTree(outputs.getManifest().toFile());assertEquals("DIFFERENT",manifest.path("result").path("equality").asText());assertEquals(1,manifest.path("result").path("differentPairs").asInt());
        Path data=outputs.getAssetsDirectory().resolve("current.bin"),index=outputs.getAssetsDirectory().resolve("current-index.csv");assertTrue(Files.size(data)>0);try(BufferedReader reader=Files.newBufferedReader(index,StandardCharsets.UTF_8)){assertEquals("messageId,fullBsCode,documentId,start,length,sourceFile,recordNumber,sourceFileOffset",reader.readLine());assertNotNull(reader.readLine());}
        byte[] concatenated=Files.readAllBytes(data);int expected=f.result.getCurrentInput().getRecords().stream().mapToInt(r->r.getProcessedBytes().length).sum();assertEquals(expected,concatenated.length);
    }
    @Test void realExcelLimitsAreEnforcedAndExistingOutputSurvivesFailedPublish() throws Exception {
        assertEquals(1_048_576,SpreadsheetVersion.EXCEL2007.getMaxRows());assertEquals(16_384,SpreadsheetVersion.EXCEL2007.getMaxColumns());assertThrows(IllegalArgumentException.class,()->new ReportLimits(1_048_577,16_384));
        Fixture f=fixture();Path output=Files.write(temp.resolve("existing.xlsx"),new byte[]{1,2,3});byte[] before=Files.readAllBytes(output);TaskContext context=TaskContext.create(f.config,d->{},(p,s,m)->{});
        assertThrows(Exception.class,()->new ComparisonReportWriter().write(output,f.result,f.layout,f.config,context));assertArrayEquals(before,Files.readAllBytes(output));
    }
    @Test void messageValuesRemainLiteralStringsWithLeadingAndTrailingSpaces() throws Exception {
        Path sample=Path.of("").toAbsolutePath().resolve("examples/synthetic"),source=sample.resolve("messages/current.dat");byte[] all=Files.readAllBytes(source);int end=0;while(end+1<all.length&&!(all[end]=='\r'&&all[end+1]=='\n'))end++;byte[] record=Arrays.copyOf(all,end);record[104]='=';record[105]='1';record[106]=' ';record[107]=' ';
        Path current=Files.write(temp.resolve("formula-current.dat"),record),newer=Files.write(temp.resolve("formula-new.dat"),record);AppConfig config=AppConfigLoader.load(sample.resolve("config.synthetic.json"));SpecAnalysisResult a=new WorkbookSpecAnalyzer().analyze(sample.resolve("specification/synthetic-normal.xlsx"),config);CompiledLayout layout=LayoutSelector.select(a.getCandidates(),config.getSpecification().getMessageId(),config.getSpecification().getBsCode(),config.getSpecification().getVariant(),config.getSpecification().getSheet());InputProcessor p=new InputProcessor();ComparisonRunResult result=new ComparisonEngine().compare(p.process(current,config.getCurrentInput(),config.getBah(),layout,config.getLimits()),p.process(newer,config.getNewInput(),config.getBah(),layout,config.getLimits()),config.getBah().getMode());
        TaskContext context=TaskContext.create(config,d->{},(x,y,z)->{});Path report=temp.resolve("literal.xlsx");new ComparisonReportWriter().write(report,result,layout,config,context);
        try(Workbook wb=WorkbookFactory.create(report.toFile())){
            org.apache.poi.ss.usermodel.Sheet sh=wb.getSheet("電文対照");int body=-1,sender=-1;
            for(int c=FIXED_COLUMNS_FOR_TEST;c<sh.getRow(0).getLastCellNum();c++){String v=sh.getRow(1).getCell(c).getStringCellValue();if("=1  ".equals(v))body=c;if(v.startsWith("SENDER"))sender=c;}
            assertTrue(body>0,"literal body value");assertTrue(sender>0,"sender value");
            assertEquals(CellType.STRING,sh.getRow(1).getCell(body).getCellType());
            assertEquals("=1  ",sh.getRow(1).getCell(body).getStringCellValue());
            assertEquals(35,sh.getRow(1).getCell(4).getStringCellValue().length());
            assertTrue(sh.getRow(1).getCell(sender).getStringCellValue().endsWith(" "),"BAH trailing spaces");
        }
    }
    private static final int FIXED_COLUMNS_FOR_TEST=6;
    private Fixture fixture() throws Exception {Path sample=Path.of("").toAbsolutePath().resolve("examples/synthetic");AppConfig config=AppConfigLoader.load(sample.resolve("config.synthetic.json"));SpecAnalysisResult a=new WorkbookSpecAnalyzer().analyze(sample.resolve("specification/synthetic-normal.xlsx"),config);CompiledLayout layout=LayoutSelector.select(a.getCandidates(),config.getSpecification().getMessageId(),config.getSpecification().getBsCode(),config.getSpecification().getVariant(),config.getSpecification().getSheet());InputProcessor p=new InputProcessor();InputSideResult c=p.process(sample.resolve("messages/current.dat"),config.getCurrentInput(),config.getBah(),layout,config.getLimits());InputSideResult n=p.process(sample.resolve("messages/new.dat"),config.getNewInput(),config.getBah(),layout,config.getLimits());return new Fixture(config,layout,new ComparisonEngine().compare(c,n,config.getBah().getMode()));}
    private static final class Fixture{final AppConfig config;final CompiledLayout layout;final ComparisonRunResult result;Fixture(AppConfig c,CompiledLayout l,ComparisonRunResult r){config=c;layout=l;result=r;}}
}
