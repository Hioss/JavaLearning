package com.dattool.validator.spec;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LayoutCompilerTest {
    @Test void expandsExplicitNestedGroupsAndPreservesGaps() {
        AppConfig.MappingConfig m = new AppConfig.MappingConfig();
        AppConfig.RepeatBinding outer = binding("O", "i", 2, null);
        AppConfig.RepeatBinding inner = binding("I", "j", 3, "O");
        m.setRepeatBindings(List.of(outer, inner));
        SpecFieldDefinition f = field("nested", "1+10*(i-1)+2*(j-1)", 1, "I", null, null, null);
        List<Diagnostic> d = new ArrayList<>();
        CompiledLayout l = new LayoutCompiler().compile("m", "b", "v", null, null, "BODY", "S", List.of(f), m,
                new AppConfig.ResourceLimits(), d);
        assertTrue(d.isEmpty());
        assertEquals(List.of(1, 3, 5, 11, 13, 15), l.getFields().stream().map(ExpandedField::getPosition).collect(java.util.stream.Collectors.toList()));
        assertFalse(l.getGaps().isEmpty());
    }

    @Test void rejectsOverlapUnknownVariableAndExpansionLimit() {
        AppConfig.MappingConfig m = new AppConfig.MappingConfig();
        List<SpecFieldDefinition> fields = List.of(field("a", "1", 4, null, null, null, null), field("b", "3", 2, null, null, null, null),
                field("c", "x+1", 1, null, null, null, null));
        AppConfig.ResourceLimits limits = new AppConfig.ResourceLimits(); limits.setMaxExpandedFields(2);
        List<Diagnostic> d = new ArrayList<>();
        new LayoutCompiler().compile("m", "b", "v", null, null, "BODY", "S", fields, m, limits, d);
        assertTrue(d.stream().anyMatch(x -> "SPEC_OVERLAP".equals(x.getCode())));
        assertTrue(d.stream().anyMatch(x -> "SPEC_EXPANSION_LIMIT".equals(x.getCode()) || "SPEC_VARIABLE_UNKNOWN".equals(x.getCode())));

        AppConfig.MappingConfig allowed = new AppConfig.MappingConfig();
        allowed.setSharedRanges(List.of("a|b"));
        List<Diagnostic> allowedDiagnostics = new ArrayList<>();
        new LayoutCompiler().compile("m", "b", "v", null, null, "BODY", "S", fields.subList(0, 2), allowed,
                new AppConfig.ResourceLimits(), allowedDiagnostics);
        assertFalse(allowedDiagnostics.stream().anyMatch(x -> "SPEC_OVERLAP".equals(x.getCode())));
    }

    @Test void selectorUsesFullBsCodeAndRejectsAmbiguity() {
        LayoutCompiler compiler = new LayoutCompiler();
        AppConfig.MappingConfig m = new AppConfig.MappingConfig();
        AppConfig.ResourceLimits limits = new AppConfig.ResourceLimits();
        List<Diagnostic> d = new ArrayList<>();
        CompiledLayout a = compiler.compile("same", "99-00000001-00001", "v1", null, null, "BODY", "A",
                List.of(field("same-name", "1", 1, null, null, null, null), field("same-name", "2", 1, null, null, null, null)), m, limits, d);
        CompiledLayout b = compiler.compile("same", "99-00000001-00002", "v1", null, null, "BODY", "B",
                List.of(field("same-name", "1", 1, null, null, null, null)), m, limits, d);
        assertSame(b, LayoutSelector.select(List.of(a, b), "same", "99-00000001-00002", null, null));
        assertThrows(IllegalArgumentException.class, () -> LayoutSelector.select(List.of(a, a), "same", "99-00000001-00001", null, null));
        assertEquals(2, a.getDefinitions().size(), "同名フィールドを上書きしない");
    }

    private static AppConfig.RepeatBinding binding(String id, String variable, int max, String parent) {
        AppConfig.RepeatBinding b = new AppConfig.RepeatBinding(); b.setId(id); b.setVariable(variable); b.setMaxCount(max); b.setParentId(parent); return b;
    }
    private static SpecFieldDefinition field(String id, String pos, int len, String repeat, Integer max, String variable, String parent) {
        return new SpecFieldDefinition(id, id, id, "/" + id, "", pos, len, repeat, max, variable, parent, false, "C", "", "MAI", "TEXT",
                new SpecSource(Path.of("synthetic.xlsx"), "S", 1, 1));
    }
}
