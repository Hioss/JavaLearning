package com.dattool.validator.input;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.util.ByteText;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class InputProcessorTest {
    @TempDir Path temp;
    @Test void preservesShiftJisHalfWidthKanaTrailingSpacesAndOffsets() throws Exception {
        byte[] body=new byte[12];Arrays.fill(body,(byte)' ');InputTestSupport.put(body,0,4,"日本",Charset.forName("Shift_JIS"));InputTestSupport.put(body,4,4,"ｱｲｳｴ",Charset.forName("Shift_JIS"));
        byte[] record=InputTestSupport.message96("synt.001.001.01","99-99000001-00001","00000000000000000000000000000000001",body,"MQHEAD08".getBytes());
        Path file=temp.resolve("日本 語.dat");Files.write(file,record);
        AppConfig.InputConfig input=InputTestSupport.lineWithFixed8();input.setFraming(AppConfig.Framing.SINGLE_MESSAGE);
        InputSideResult r=new InputProcessor().process(file,input,InputTestSupport.bah96(),InputTestSupport.normal(),new AppConfig.ResourceLimits());
        assertTrue(r.getStatistics().isConserved());assertEquals(1,r.getStatistics().getParsedSelectedRecords());
        ParsedRecord p=r.getRecords().get(0);assertEquals(8,p.getRemovedBytes());assertArrayEquals(body,p.getBodyBytes());
        ByteFieldValue first=p.getFields().stream().filter(x->"f1".equals(x.getInstanceId())).findFirst().orElseThrow();
        assertEquals("日本",first.getDecoded().getText());assertEquals(104,first.getRecordOffset());assertEquals(104,first.getFileOffset());
        assertTrue(p.getFields().stream().anyMatch(x->"BODY_RAW".equals(x.getRole())&&x.getPosition()==9));
    }
    @Test void explicitWindows31jDoesNotFallBackFromShiftJis() {
        byte[] b="①".getBytes(Charset.forName("windows-31j"));
        assertTrue(ByteText.decode(b,"windows-31j").isValid());assertFalse(ByteText.decode(b,"Shift_JIS").isValid());
    }
    @Test void invalidDoubleByteAndLengthErrorsKeepHexAndCounts() throws Exception {
        byte[] body=new byte[12];Arrays.fill(body,(byte)' ');body[3]=(byte)0x82;
        byte[] invalid=InputTestSupport.message96("synt.001.001.01","99-99000001-00001","00000000000000000000000000000000001",body,"MQHEAD08".getBytes());
        byte[] longBody=Arrays.copyOf(body,13);longBody[12]='X';byte[] tooLong=InputTestSupport.message96("synt.001.001.01","99-99000001-00001","00000000000000000000000000000000002",longBody,"MQHEAD08".getBytes());
        Path f=temp.resolve("bad.dat");Files.write(f,joinLines(invalid,tooLong));
        InputSideResult r=new InputProcessor().process(f,InputTestSupport.lineWithFixed8(),InputTestSupport.bah96(),InputTestSupport.normal(),new AppConfig.ResourceLimits());
        assertEquals(2,r.getStatistics().getSelectedRecords());assertEquals(2,r.getStatistics().getFailedSelectedRecords());
        assertTrue(r.getDiagnostics().stream().anyMatch(x->"FIELD_DECODE".equals(x.getCode())&&x.getMessage().contains("82")));
        assertTrue(r.getDiagnostics().stream().anyMatch(x->"BODY_LENGTH".equals(x.getCode())));assertTrue(r.getStatistics().isConserved());
    }
    @Test void filtersOtherTypeBeforeBodyLengthAndKeepsUnknownAsFailure() throws Exception {
        byte[] body=new byte[12];Arrays.fill(body,(byte)' ');
        byte[] selected=InputTestSupport.message96("synt.001.001.01","99-99000001-00001","00000000000000000000000000000000001",body,"MQHEAD08".getBytes());
        byte[] other=InputTestSupport.message96("synt.999.001.01","99-99000999-00001","00000000000000000000000000000000002",new byte[]{'X'},"MQHEAD08".getBytes());
        byte[] unknown=other.clone();Arrays.fill(unknown,8+57,8+72,(byte)'#');
        Path f=temp.resolve("mixed.dat");Files.write(f,joinLines(selected,other,unknown));
        InputSideResult r=new InputProcessor().process(f,InputTestSupport.lineWithFixed8(),InputTestSupport.bah96(),InputTestSupport.normal(),new AppConfig.ResourceLimits());
        assertEquals(3,r.getStatistics().getTotalRecords());assertEquals(1,r.getStatistics().getParsedSelectedRecords());assertEquals(1,r.getStatistics().getOtherTypeRecords());assertEquals(1,r.getStatistics().getRecognitionFailures());assertTrue(r.getStatistics().isConserved());
    }
    @Test void fixedEightBah96RepeatFieldHasRequiredRecordAndFileOffset() throws Exception {
        byte[] body=new byte[788];Arrays.fill(body,(byte)' ');byte[] record=InputTestSupport.message96("synt.002.001.01","99-99000002-00001","00000000000000000000000000000000001",body,"MQHEAD08".getBytes());
        Path f=temp.resolve("repeat.dat");Files.write(f,record);AppConfig.InputConfig input=InputTestSupport.lineWithFixed8();input.setFraming(AppConfig.Framing.SINGLE_MESSAGE);
        InputSideResult r=new InputProcessor().process(f,input,InputTestSupport.bah96(),InputTestSupport.repeat(),new AppConfig.ResourceLimits());
        ByteFieldValue v=r.getRecords().get(0).getFields().stream().filter(x->x.getInstanceId().startsWith("isin[a=30]")).findFirst().orElseThrow();
        assertEquals(867,v.getRecordOffset());assertEquals(867,v.getFileOffset());assertEquals(12,v.getLength());
        assertArrayEquals("            ".getBytes(),v.getBytes());
        assertEquals(1,r.getRecords().get(0).getStripTraces().size());
        assertArrayEquals(record,r.getRecords().get(0).getOriginalBytes());
    }
    @Test void supportsExplicitNon96BahAndDoesNotGuessMarkerInBody() throws Exception {
        AppConfig.BahConfig b=new AppConfig.BahConfig();b.setTotalLength(20);b.setBodyStart(21);b.setFields(java.util.List.of(InputTestSupport.bf("doc",AppConfig.BahRole.DOCUMENT_ID,1,5,true),InputTestSupport.bf("msg",AppConfig.BahRole.MESSAGE_ID,6,7,true),InputTestSupport.bf("bs",AppConfig.BahRole.BS_CODE,13,8,true)));
        CompiledLayout l=InputTestSupport.layout("MSG0001","BS000001",3,java.util.List.of(InputTestSupport.field("body","1",3)));
        byte[] rec="D0001MSG0001BS000001MSG".getBytes();Path f=temp.resolve("bah20.dat");Files.write(f,rec);AppConfig.InputConfig input=new AppConfig.InputConfig();input.setFraming(AppConfig.Framing.SINGLE_MESSAGE);
        InputSideResult r=new InputProcessor().process(f,input,b,l,new AppConfig.ResourceLimits());assertEquals(1,r.getStatistics().getParsedSelectedRecords());assertEquals(20,r.getRecords().get(0).getBahBytes().length);
        b.setTotalLength(null);InputSideResult missing=new InputProcessor().process(f,input,b,l,new AppConfig.ResourceLimits());assertEquals(1,missing.getStatistics().getRecognitionFailures());assertTrue(missing.getDiagnostics().stream().anyMatch(x->"BAH_CONFIG_REQUIRED".equals(x.getCode())));
    }
    @Test void shortBodyAndStripFailureAreFailuresAndCountsRemainConserved() throws Exception {
        byte[] shortBody=new byte[11];Arrays.fill(shortBody,(byte)' ');
        byte[] shortRecord=InputTestSupport.message96("synt.001.001.01","99-99000001-00001","00000000000000000000000000000000001",shortBody,"MQHEAD08".getBytes());
        Path shortFile=temp.resolve("short.dat");Files.write(shortFile,shortRecord);
        AppConfig.InputConfig single=InputTestSupport.lineWithFixed8();single.setFraming(AppConfig.Framing.SINGLE_MESSAGE);
        InputSideResult shortResult=new InputProcessor().process(shortFile,single,InputTestSupport.bah96(),InputTestSupport.normal(),new AppConfig.ResourceLimits());
        assertEquals(1,shortResult.getStatistics().getFailedSelectedRecords());assertTrue(shortResult.getStatistics().isConserved());

        AppConfig.StripStep missing=new AppConfig.StripStep();missing.setType(AppConfig.StripType.PREFIX);missing.setLiteral("NOT-THERE");
        single.setStripSteps(java.util.List.of(missing));
        InputSideResult stripResult=new InputProcessor().process(shortFile,single,InputTestSupport.bah96(),InputTestSupport.normal(),new AppConfig.ResourceLimits());
        assertEquals(1,stripResult.getStatistics().getRecognitionFailures());assertTrue(stripResult.getStatistics().isConserved());
        assertTrue(stripResult.getDiagnostics().stream().anyMatch(x->"STRIP_PREFIX".equals(x.getCode())));
    }
    @Test void invalidBytesInUnassignedTailAreDiagnosedWithoutTruncation() throws Exception {
        byte[] body=new byte[12];Arrays.fill(body,(byte)' ');body[8]=(byte)0x82;
        byte[] record=InputTestSupport.message96("synt.001.001.01","99-99000001-00001","00000000000000000000000000000000001",body,"MQHEAD08".getBytes());
        Path file=temp.resolve("raw-invalid.dat");Files.write(file,record);
        AppConfig.InputConfig input=InputTestSupport.lineWithFixed8();input.setFraming(AppConfig.Framing.SINGLE_MESSAGE);
        InputSideResult result=new InputProcessor().process(file,input,InputTestSupport.bah96(),InputTestSupport.normal(),new AppConfig.ResourceLimits());
        assertEquals(1,result.getStatistics().getFailedSelectedRecords());
        assertTrue(result.getDiagnostics().stream().anyMatch(x->"RAW_DECODE".equals(x.getCode())&&x.getMessage().contains("82")));
        assertTrue(result.getStatistics().isConserved());
    }
    private byte[] joinLines(byte[]...records){ByteArrayOutputStream out=new ByteArrayOutputStream();for(int i=0;i<records.length;i++){out.write(records[i],0,records[i].length);if(i+1<records.length){out.write('\r');out.write('\n');}}return out.toByteArray();}
}
