package com.dattool.validator.config;

import com.dattool.validator.model.Diagnostic;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AppConfigLoaderTest {
    @Test void validConfigurationRoundTripsWithoutLosingMeaning() throws Exception {
        AppConfig original = new AppConfig();
        original.getSpecification().setMessageId("semt.021.001.08");
        original.getSpecification().setBsCode("04-04010011-00101");
        original.getCurrentInput().setCharset("windows-31j");
        String json = AppConfigLoader.toJson(original);
        AppConfig loaded = AppConfigLoader.fromJson(json);
        assertEquals(1, loaded.getSchemaVersion());
        assertEquals("semt.021.001.08", loaded.getSpecification().getMessageId());
        assertEquals("04-04010011-00101", loaded.getSpecification().getBsCode());
        assertEquals("windows-31j", loaded.getCurrentInput().getCharset());
        assertTrue(ConfigValidator.validate(loaded).isEmpty());
    }

    @Test void rejectsUnknownKeyWithPath() {
        ConfigException ex = assertThrows(ConfigException.class,
                () -> AppConfigLoader.fromJson("{\"schemaVersion\":1,\"mystery\":true}"));
        assertTrue(ex.getMessage().contains("mystery"));
    }

    @Test void reportsUnsupportedSchemaAndInvalidPositiveNumber() throws Exception {
        AppConfig c = AppConfigLoader.fromJson("{\"schemaVersion\":99,\"limits\":{\"maxRecordBytes\":0,\"maxExpandedFields\":1,\"previewRecordLimit\":1,\"maxRecordsInMemory\":1}} ");
        List<Diagnostic> diagnostics = ConfigValidator.validate(c);
        assertTrue(diagnostics.stream().anyMatch(x -> x.getMessage().contains("$.schemaVersion")));
        assertTrue(diagnostics.stream().anyMatch(x -> x.getMessage().contains("$.limits.maxRecordBytes")));
    }

    @Test void rejectsMutuallyExclusiveStripValues() {
        AppConfig c = new AppConfig();
        AppConfig.StripStep step = new AppConfig.StripStep();
        step.setType(AppConfig.StripType.PREFIX);
        step.setLiteral("ABC");
        step.setHex("414243");
        c.getCurrentInput().getStripSteps().add(step);
        assertTrue(ConfigValidator.validate(c).stream().anyMatch(x -> "CFG_EXCLUSIVE".equals(x.getCode())));
    }
}
