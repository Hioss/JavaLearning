package com.dattool.validator.model;

import org.junit.jupiter.api.Test;

import static com.dattool.validator.model.ComparisonResult.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ExitCodeMapperTest {
    private Builder reliable() {
        return ComparisonResult.builder().dataPresent(true).validity(Validity.VALID)
                .completeness(Completeness.COMPLETE).interpretation(Interpretation.FULL);
    }
    @Test void mapsAllPublicExitClasses() {
        assertEquals(0, ExitCodeMapper.toExitCode(reliable().equality(Equality.EQUAL).build()));
        assertEquals(1, ExitCodeMapper.toExitCode(reliable().equality(Equality.DIFFERENT).build()));
        assertEquals(2, ExitCodeMapper.toExitCode(reliable().configurationError(true).build()));
        assertEquals(4, ExitCodeMapper.toExitCode(reliable().dataPresent(false).equality(Equality.EQUAL).build()));
        assertEquals(4, ExitCodeMapper.toExitCode(reliable().validity(Validity.INVALID).equality(Equality.EQUAL).build()));
        assertEquals(4, ExitCodeMapper.toExitCode(reliable().ambiguous(true).equality(Equality.DIFFERENT).build()));
        assertEquals(9, ExitCodeMapper.toExitCode(reliable().internalError(true).build()));
    }
}
