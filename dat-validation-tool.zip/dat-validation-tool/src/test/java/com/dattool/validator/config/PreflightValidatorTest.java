package com.dattool.validator.config;

import com.dattool.validator.model.Diagnostic;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PreflightValidatorTest {
    @TempDir Path temp;

    @Test void rejectsNormalizedInputOutputConflictWithoutChangingSource() throws Exception {
        Path source = temp.resolve("source.dat");
        Files.write(source, new byte[]{1, 2, 3, 4});
        byte[] before = MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(source));
        AppConfig c = new AppConfig();
        ResolvedRunConfiguration run = new ResolvedRunConfiguration(c, null, temp.resolve("spec.xlsx"), source,
                temp.resolve("new.dat"), temp.resolve("folder/../source.dat"), null);
        List<Diagnostic> d = PreflightValidator.validate(run, false);
        assertTrue(d.stream().anyMatch(x -> "OUTPUT_INPUT_CONFLICT".equals(x.getCode())));
        assertArrayEquals(before, MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(source)));
    }

    @Test void existingOutputNeedsExplicitOverwrite() throws Exception {
        Path output = Files.write(temp.resolve("report.xlsx"), new byte[]{9});
        AppConfig c = new AppConfig();
        ResolvedRunConfiguration run = new ResolvedRunConfiguration(c, null, temp.resolve("spec.xlsx"), temp.resolve("a.dat"),
                temp.resolve("b.dat"), output, null);
        assertTrue(PreflightValidator.validate(run, false).stream().anyMatch(x -> "OUTPUT_EXISTS".equals(x.getCode())));
        c.getOutput().setOverwrite(true);
        assertFalse(PreflightValidator.validate(run, false).stream().anyMatch(x -> "OUTPUT_EXISTS".equals(x.getCode())));
    }
}
