package com.dattool.validator.spec;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.AppConfigLoader;
import com.dattool.validator.sample.SyntheticSpecificationGenerator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WorkbookSpecAnalyzerTest {
    @TempDir Path temp;
    private final WorkbookSpecAnalyzer analyzer = new WorkbookSpecAnalyzer();

    @Test void xlsAndXlsxCompileEquivalentShiftedMergedSparseLayoutWithoutModification() throws Exception {
        Path xlsx = temp.resolve("同値 仕様.xlsx");
        Path xls = temp.resolve("同値 仕様.xls");
        SyntheticSpecificationGenerator.writeNormal(xlsx, new XSSFWorkbook());
        SyntheticSpecificationGenerator.writeNormal(xls, new HSSFWorkbook());
        byte[] before = digest(xlsx);
        SpecAnalysisResult a = analyzer.analyze(xlsx, new AppConfig());
        SpecAnalysisResult b = analyzer.analyze(xls, new AppConfig());
        assertFalse(a.hasErrors(), codes(a)); assertFalse(b.hasErrors(), codes(b));
        assertEquals(1, a.getCandidates().size()); assertEquals(1, b.getCandidates().size());
        CompiledLayout la = a.getCandidates().get(0), lb = b.getCandidates().get(0);
        assertEquals("改名された固定長仕様", la.getSheet());
        assertEquals(3, la.getFields().size());
        assertEquals(12, la.getExpectedLength());
        assertEquals(List.of(1, 5, 10), la.getFields().stream().map(ExpandedField::getPosition).collect(java.util.stream.Collectors.toList()));
        assertEquals(9, la.getGaps().get(0).getPosition());
        assertEquals(la.getExpectedLength(), lb.getExpectedLength());
        assertEquals(la.getDefinitions().get(1).getPositionValueKind(), "FORMULA");
        assertEquals(List.of("MAI", "MAJ", "OPJ"), la.getDefinitions().stream().map(SpecFieldDefinition::getRequiredCode).collect(java.util.stream.Collectors.toList()));
        assertTrue(la.getDefinitions().get(2).isCurrency());
        assertArrayEquals(before, digest(xlsx));
    }

    @Test void repeatSampleExpandsToIndependentKnownBoundaries() throws Exception {
        Path spec = temp.resolve("repeat.xlsx");
        SyntheticSpecificationGenerator.writeRepeat(spec, new XSSFWorkbook());
        SpecAnalysisResult result = analyzer.analyze(spec, new AppConfig());
        assertFalse(result.hasErrors(), codes(result) + "\n" + result.getCandidates().stream().flatMap(x -> x.getDefinitions().stream())
                .map(x -> x.getName() + "|" + x.getRepeatId() + "|" + x.getMaxCount() + "|" + x.getRepeatVariable())
                .collect(java.util.stream.Collectors.joining("\n")));
        CompiledLayout l = result.getCandidates().get(0);
        assertEquals(788, l.getExpectedLength());
        assertEquals(96, l.getFields().size());
        assertEquals(39, find(l, "ISIN 銘柄コード", 1).getPosition());
        assertEquals(64, find(l, "ISIN 銘柄コード", 2).getPosition());
        assertEquals(764, find(l, "ISIN 銘柄コード", 30).getPosition());
        assertEquals(776, find(l, "現行銘柄コード", 30).getPosition());
        assertEquals(785, find(l, "外部コードリスト", 30).getPosition());
    }

    @Test void savedManualMappingReproducesLayout() throws Exception {
        Path spec = temp.resolve("manual.xlsx");
        SyntheticSpecificationGenerator.writeNormal(spec, new XSSFWorkbook());
        AppConfig c = new AppConfig();
        c.getSpecification().setSheet("改名された固定長仕様");
        AppConfig.MappingConfig m = c.getSpecification().getMapping();
        m.setHeaderEndRow(10); m.setDataStartRow(11); m.setDataEndRow(14);
        String[] keys={"required","itemNumber","itemName","setting","fixedNumber","position","size","ccy","repeatId","maxCount","repeatVariable","parentRepeatId","attribute","notes","path"};
        for(int i=0;i<keys.length;i++) m.getColumns().put(keys[i],5+i);
        Path json=temp.resolve("mapping.json"); AppConfigLoader.save(c,json);
        AppConfig reloaded=AppConfigLoader.load(json);
        SpecAnalysisResult result=analyzer.analyze(spec,reloaded);
        assertFalse(result.hasErrors(), codes(result));
        assertEquals(3,result.getCandidates().get(0).getFields().size());
    }

    @Test void rejectsExtensionContentMismatchWithClearDiagnostic() throws Exception {
        Path real=temp.resolve("real.xlsx"); SyntheticSpecificationGenerator.writeNormal(real,new XSSFWorkbook());
        Path wrong=temp.resolve("wrong.xls"); Files.copy(real,wrong);
        SpecAnalysisResult result=analyzer.analyze(wrong,new AppConfig());
        assertTrue(result.hasErrors());
        assertTrue(result.getDiagnostics().stream().anyMatch(x->x.getMessage().contains("内部形式")));
    }

    @Test void refusesExternalFormulaAndReportsExactCell() throws Exception {
        Path source=temp.resolve("external-source.xlsx"); SyntheticSpecificationGenerator.writeNormal(source,new XSSFWorkbook());
        Path spec=temp.resolve("external.xlsx");
        try (Workbook wb=WorkbookFactory.create(source.toFile())) {
            wb.getSheet("改名された固定長仕様").getRow(12).getCell(9).setCellFormula("HYPERLINK(\"https://example.invalid\",\"5\")");
            try(java.io.OutputStream out=Files.newOutputStream(spec)){wb.write(out);}
        }
        SpecAnalysisResult result=analyzer.analyze(spec,new AppConfig());
        assertTrue(result.getDiagnostics().stream().anyMatch(x->"SPEC_EXTERNAL_FORMULA".equals(x.getCode())
                && x.getSource()!=null && x.getSource().getRow()==13 && x.getSource().getColumn()==10));
    }

    private ExpandedField find(CompiledLayout l,String name,int index){return l.getFields().stream().filter(f->name.equals(f.getDefinition().getName())&&Integer.valueOf(index).equals(f.getRepeatIndexes().get("a"))).findFirst().orElseThrow();}
    private byte[] digest(Path p)throws Exception{return MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p));}
    private String codes(SpecAnalysisResult r){return r.getDiagnostics().stream().map(x->x.getCode()+":"+x.getMessage()).collect(java.util.stream.Collectors.joining("\n"));}
}
