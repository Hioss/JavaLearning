package com.dattool.validator.service;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TaskContextTest {
    @Test void snapshotsAndLogsAreIsolatedPerTask() throws Exception {
        AppConfig config = new AppConfig();
        config.getSpecification().setMessageId("before");
        List<Diagnostic> firstLog = new ArrayList<>();
        List<Diagnostic> secondLog = new ArrayList<>();
        TaskContext first = TaskContext.create(config, firstLog::add, (p, s, m) -> {});
        TaskContext second = TaskContext.create(config, secondLog::add, (p, s, m) -> {});
        config.getSpecification().setMessageId("after");
        first.getLog().accept(Diagnostic.error("ONE", "TEST", "一件", null));
        assertEquals("before", first.getConfigSnapshot().getSpecification().getMessageId());
        assertNotEquals(first.getRunId(), second.getRunId());
        assertEquals(1, firstLog.size());
        assertTrue(secondLog.isEmpty());
    }
}
