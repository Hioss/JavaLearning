package com.dattool.validator.gui;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.AppConfigLoader;
import com.dattool.validator.config.ResolvedRunConfiguration;
import com.dattool.validator.service.ComparisonExecutionService;
import com.dattool.validator.service.ExecutionResult;
import com.dattool.validator.service.TaskContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class GuiRunRequestFactoryTest {
    @TempDir Path temp;
    @Test void mapsJapaneseAndSpacePathsAndUsesTheSharedExecutionService() throws Exception {
        Path root=Path.of("").toAbsolutePath(),sample=root.resolve("examples/synthetic");AppConfig config=AppConfigLoader.load(sample.resolve("config.synthetic.json"));Path folder=Files.createDirectories(temp.resolve("日本 語 folder"));Path current=Files.copy(sample.resolve("messages/current.dat"),folder.resolve("現 比較.dat"));Path newer=Files.copy(sample.resolve("messages/new-equal-reordered.dat"),folder.resolve("新 比較.dat"));Path output=folder.resolve("結果 比較.xlsx");
        ResolvedRunConfiguration request=GuiRunRequestFactory.create(config,sample.resolve("config.synthetic.json"),sample.resolve("specification/synthetic-normal.xlsx").toString(),current.toString(),newer.toString(),output.toString());
        assertEquals(current.toAbsolutePath(),request.getCurrent());assertEquals(output.toAbsolutePath(),request.getOutput());TaskContext context=TaskContext.create(config,d->{},(p,s,m)->{});ExecutionResult result=new ComparisonExecutionService().execute(request,context,false);
        assertEquals(com.dattool.validator.model.ComparisonResult.Equality.EQUAL,result.getComparison().getResult().getEquality());assertNull(result.getReport());
    }
}
