package com.dattool.validator.input;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.model.Diagnostic;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.spec.LayoutCompiler;
import com.dattool.validator.spec.SpecFieldDefinition;
import com.dattool.validator.spec.SpecSource;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

final class InputTestSupport {
    static AppConfig.BahConfig bah96(){
        AppConfig.BahConfig b=new AppConfig.BahConfig();b.setMode(AppConfig.BahMode.BAH_RAW);b.setTotalLength(96);b.setBodyStart(97);b.setVariant("SYNTHETIC-96");
        b.setFields(List.of(bf("sender",AppConfig.BahRole.SENDER,1,11,true),bf("receiver",AppConfig.BahRole.RECEIVER,12,11,true),
                bf("doc",AppConfig.BahRole.DOCUMENT_ID,23,35,true),bf("msg",AppConfig.BahRole.MESSAGE_ID,58,15,true),
                bf("bs",AppConfig.BahRole.BS_CODE,73,17,false),bf("reserved",AppConfig.BahRole.RESERVED,90,7,false)));
        return b;
    }
    static AppConfig.BahField bf(String id,AppConfig.BahRole role,int pos,int len,boolean trim){AppConfig.BahField f=new AppConfig.BahField();f.setId(id);f.setName(id);f.setRole(role);f.setPosition(pos);f.setLength(len);f.setTrimHalfWidthSpacePadding(trim);return f;}
    static CompiledLayout normal(){return layout("synt.001.001.01","99-99000001-00001",12,List.of(field("f1","1",4),field("f2","5",4),field("f3","10",3)));}
    static CompiledLayout repeat(){
        List<SpecFieldDefinition> f=new ArrayList<>();int[] p={1,5,9,20,28,32},len={4,4,11,8,4,7};for(int i=0;i<6;i++)f.add(field("f"+(i+1),Integer.toString(p[i]),len[i]));
        f.add(repeatField("isin","39+25*(a-1)",12));f.add(repeatField("current","51+25*(a-1)",9));f.add(repeatField("external","60+25*(a-1)",4));
        AppConfig.MappingConfig m=new AppConfig.MappingConfig();m.setExpectedBodyLength(788);
        List<Diagnostic>d=new ArrayList<>();return new LayoutCompiler().compile("synt.002.001.01","99-99000002-00001","v",null,null,"BODY","S",f,m,new AppConfig.ResourceLimits(),d);
    }
    static CompiledLayout layout(String msg,String bs,int expected,List<SpecFieldDefinition> fields){AppConfig.MappingConfig m=new AppConfig.MappingConfig();m.setExpectedBodyLength(expected);return new LayoutCompiler().compile(msg,bs,"v",null,null,"BODY","S",fields,m,new AppConfig.ResourceLimits(),new ArrayList<>());}
    static SpecFieldDefinition field(String id,String pos,int len){return new SpecFieldDefinition(id,id,id,"/"+id,"",pos,len,null,null,null,null,false,"C","","MAI","TEXT",new SpecSource(Path.of("s.xlsx"),"S",1,1));}
    static SpecFieldDefinition repeatField(String id,String pos,int len){return new SpecFieldDefinition(id,id,id,"/"+id,"",pos,len,"L1",30,"a",null,false,"C","","OPJ","TEXT",new SpecSource(Path.of("s.xlsx"),"S",1,1));}
    static byte[] message96(String msg,String bs,String doc,byte[] body,byte[] prefix){
        byte[] bah=new byte[96];java.util.Arrays.fill(bah,(byte)' ');put(bah,0,11,"SENDER",Charset.forName("Shift_JIS"));put(bah,11,11,"RECEIVER",Charset.forName("Shift_JIS"));
        put(bah,22,35,doc,Charset.forName("Shift_JIS"));put(bah,57,15,msg,Charset.forName("Shift_JIS"));put(bah,72,17,bs,Charset.forName("Shift_JIS"));
        ByteArrayOutputStream out=new ByteArrayOutputStream();if(prefix!=null)out.write(prefix,0,prefix.length);out.write(bah,0,bah.length);out.write(body,0,body.length);return out.toByteArray();
    }
    static void put(byte[] target,int start,int len,String value,Charset cs){byte[] b=value.getBytes(cs);if(b.length>len)throw new IllegalArgumentException(value);System.arraycopy(b,0,target,start,b.length);}
    static AppConfig.InputConfig lineWithFixed8(){AppConfig.InputConfig i=new AppConfig.InputConfig();AppConfig.StripStep s=new AppConfig.StripStep();s.setType(AppConfig.StripType.FIXED_LENGTH);s.setLength(8);i.setStripSteps(List.of(s));return i;}
    private InputTestSupport(){}
}
