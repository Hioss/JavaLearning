package com.dattool.validator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class CliEndToEndTest {
    @TempDir Path temp;
    @Test void realEntryPointCoversEqualDifferentNoDataAndPublishFailure() throws Exception {
        Path root=Path.of("").toAbsolutePath(),sample=root.resolve("examples/synthetic"),config=sample.resolve("config.synthetic.json");
        assertEquals(0,run(root,"--config",config.toString(),"--new",sample.resolve("messages/new-equal-reordered.dat").toString(),"--output",temp.resolve("equal.xlsx").toString()));
        assertEquals(1,run(root,"--config",config.toString(),"--output",temp.resolve("different.xlsx").toString()));
        Path emptyCurrent=Files.createFile(temp.resolve("empty-current.dat")),emptyNew=Files.createFile(temp.resolve("empty-new.dat"));
        assertEquals(4,run(root,"--config",config.toString(),"--current",emptyCurrent.toString(),"--new",emptyNew.toString(),"--output",temp.resolve("no-data.xlsx").toString()));
        Path impossible=Files.createDirectory(temp.resolve("publish-failure.xlsx"));Files.write(impossible.resolve("keep.txt"),new byte[]{7});
        assertEquals(9,run(root,"--config",config.toString(),"--output",impossible.toString(),"--overwrite"));assertArrayEquals(new byte[]{7},Files.readAllBytes(impossible.resolve("keep.txt")));
    }
    private int run(Path working,String...args){ByteArrayOutputStream out=new ByteArrayOutputStream(),err=new ByteArrayOutputStream();return DatValidationApplication.run(args,new PrintStream(out),new PrintStream(err),working);}
}
