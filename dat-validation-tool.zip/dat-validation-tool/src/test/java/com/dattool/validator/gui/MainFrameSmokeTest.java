package com.dattool.validator.gui;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.Component;
import java.awt.Container;
import java.awt.GraphicsEnvironment;
import java.awt.Window;
import java.awt.event.WindowEvent;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Visible-window smoke test for the real Swing event wiring and shared execution service. */
class MainFrameSmokeTest {
    @TempDir Path temp;

    @Test
    void visibleWindowAnalyzesPreviewsAndComparesJapaneseSpacePaths() throws Exception {
        Assumptions.assumeFalse(GraphicsEnvironment.isHeadless(), "A desktop session is required");
        Path root = Path.of("").toAbsolutePath();
        Path folder = Files.createDirectories(temp.resolve("日本 語 GUI"));
        Path current = Files.copy(root.resolve("examples/synthetic/messages/current.dat"), folder.resolve("現 比較.dat"));
        Path newer = Files.copy(root.resolve("examples/synthetic/messages/new-equal-reordered.dat"), folder.resolve("新 比較.dat"));
        Path output = folder.resolve("結果 比較.xlsx");

        AtomicReference<MainFrame> ref = new AtomicReference<>();
        SwingUtilities.invokeAndWait(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
            named(frame, JTextField.class, "currentPath").setText(current.toString());
            named(frame, JTextField.class, "newPath").setText(newer.toString());
            named(frame, JTextField.class, "outputPath").setText(output.toString());
            ref.set(frame);
        });
        MainFrame frame = ref.get();
        try {
            assertTrue(onEdt(frame::isShowing));

            JButton analyze = named(frame, JButton.class, "button.仕様分析");
            click(analyze);
            assertFalse(onEdt(analyze::isEnabled));
            waitFor(() -> onEdt(analyze::isEnabled), Duration.ofSeconds(15));
            assertTrue(onEdt(() -> named(frame, JTable.class, null).getRowCount() > 0));

            JButton preview = named(frame, JButton.class, "button.現をプレビュー");
            click(preview);
            waitFor(() -> onEdt(preview::isEnabled), Duration.ofSeconds(15));
            assertTrue(onEdt(() -> named(frame, JTextArea.class, "messagePreview").getText().contains("parsed=")));

            JButton start = named(frame, JButton.class, "button.比較開始");
            click(start);
            assertFalse(onEdt(() -> named(frame, JTextField.class, "messageId").isEnabled()));
            assertFalse(onEdt(() -> named(frame, JTextField.class, "configPath").isEnabled()));
            waitFor(() -> onEdt(start::isEnabled), Duration.ofSeconds(30));
            assertTrue(Files.isRegularFile(output));
            assertTrue(onEdt(() -> named(frame, JLabel.class, "resultSummary").getText().contains("EQUAL")));

            Path secondOutput = folder.resolve("閉じる確認.xlsx");
            SwingUtilities.invokeLater(() -> {
                named(frame, JTextField.class, "outputPath").setText(secondOutput.toString());
                start.doClick();
                frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
            });
            JDialog closingDialog = waitForDialog(Duration.ofSeconds(5));
            assertTrue(onEdt(frame::isShowing));
            SwingUtilities.invokeAndWait(() -> named(closingDialog, JButton.class, null).doClick());
            waitFor(() -> onEdt(start::isEnabled), Duration.ofSeconds(30));
            assertTrue(Files.isRegularFile(secondOutput));
        } finally {
            SwingUtilities.invokeAndWait(frame::dispose);
        }
    }

    @Test
    void visibleWindowRecoversAfterCorrectableConfigurationFailure() throws Exception {
        Assumptions.assumeFalse(GraphicsEnvironment.isHeadless(), "A desktop session is required");
        Path root = Path.of("").toAbsolutePath();
        Path folder = Files.createDirectories(temp.resolve("再 実行"));
        Path validCurrent = root.resolve("examples/synthetic/messages/current.dat");
        Path equalNew = root.resolve("examples/synthetic/messages/new-equal-reordered.dat");
        Path output = folder.resolve("修正後.xlsx");

        AtomicReference<MainFrame> ref = new AtomicReference<>();
        SwingUtilities.invokeAndWait(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
            named(frame, JTextField.class, "currentPath").setText(folder.resolve("存在しない.dat").toString());
            named(frame, JTextField.class, "newPath").setText(equalNew.toString());
            named(frame, JTextField.class, "outputPath").setText(output.toString());
            ref.set(frame);
        });
        MainFrame frame = ref.get();
        try {
            JButton start = named(frame, JButton.class, "button.比較開始");
            click(start);
            JDialog dialog = waitForDialog(Duration.ofSeconds(15));
            SwingUtilities.invokeAndWait(() -> named(dialog, JButton.class, null).doClick());
            waitFor(() -> onEdt(start::isEnabled), Duration.ofSeconds(5));
            assertTrue(onEdt(() -> named(frame, JLabel.class, "resultSummary").getText().startsWith("失敗:")));

            SwingUtilities.invokeAndWait(() -> named(frame, JTextField.class, "currentPath").setText(validCurrent.toString()));
            click(start);
            waitFor(() -> onEdt(start::isEnabled), Duration.ofSeconds(30));
            assertTrue(Files.isRegularFile(output));
            assertTrue(onEdt(() -> named(frame, JLabel.class, "resultSummary").getText().contains("EQUAL")));
        } finally {
            SwingUtilities.invokeAndWait(frame::dispose);
        }
    }

    private static void click(JButton button) throws Exception {
        SwingUtilities.invokeAndWait(button::doClick);
    }

    private static void waitFor(BooleanSupplier condition, Duration timeout) throws Exception {
        Instant deadline = Instant.now().plus(timeout);
        while (!condition.getAsBoolean() && Instant.now().isBefore(deadline)) {
            Thread.sleep(50);
        }
        assertTrue(condition.getAsBoolean(), "Timed out waiting for Swing operation");
    }

    private static JDialog waitForDialog(Duration timeout) throws Exception {
        AtomicReference<JDialog> dialog = new AtomicReference<>();
        waitFor(() -> onEdt(() -> {
            for (Window window : Window.getWindows()) {
                if (window instanceof JDialog && window.isShowing()) {
                    dialog.set((JDialog) window);
                    return true;
                }
            }
            return false;
        }), timeout);
        return dialog.get();
    }

    private static boolean onEdt(BooleanSupplier supplier) {
        if (SwingUtilities.isEventDispatchThread()) return supplier.getAsBoolean();
        AtomicReference<Boolean> result = new AtomicReference<>();
        try {
            SwingUtilities.invokeAndWait(() -> result.set(supplier.getAsBoolean()));
        } catch (Exception e) {
            throw new AssertionError(e);
        }
        return result.get();
    }

    private static <T extends Component> T named(Container root, Class<T> type, String name) {
        for (Component component : root.getComponents()) {
            if (type.isInstance(component) && (name == null || name.equals(component.getName()))) {
                return type.cast(component);
            }
            if (component instanceof Container) {
                try {
                    return named((Container) component, type, name);
                } catch (IllegalArgumentException ignored) {
                    // Continue with the next branch.
                }
            }
        }
        throw new IllegalArgumentException("Component not found: " + type.getSimpleName() + " / " + name);
    }
}
