package com.dattool.validator.input;

import com.dattool.validator.config.AppConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RecordFramerTest {
    @TempDir Path temp;
    @Test void handlesCrLfLfNoFinalSeparatorEmptyAndSpaceRecords() throws Exception {
        Path p=temp.resolve("mixed.dat");Files.write(p,"A  \r\n\r\n   \nB".getBytes(StandardCharsets.US_ASCII));
        AppConfig.InputConfig c=new AppConfig.InputConfig();c.setLineSeparator(AppConfig.LineSeparator.MIXED);
        FrameResult r=new RecordFramer().frame(p,c,new AppConfig.ResourceLimits());
        assertEquals(4,r.getPhysicalRecordCount()); assertEquals(4,r.getRecords().size());
        assertArrayEquals("A  ".getBytes(StandardCharsets.US_ASCII),r.getRecords().get(0).getBytes());
        assertEquals(0,r.getRecords().get(1).getLength()); assertEquals(3,r.getRecords().get(2).getLength());
        assertArrayEquals("B".getBytes(StandardCharsets.US_ASCII),r.getRecords().get(3).getBytes());

        c.setIgnoreEmptyLines(true);FrameResult ignored=new RecordFramer().frame(p,c,new AppConfig.ResourceLimits());
        assertEquals(3,ignored.getRecords().size());assertEquals(1,ignored.getIgnoredEmptyRecords());
    }
    @Test void trailingSeparatorAddsNoRecordAndAutoDiagnosesMixed() throws Exception {
        Path p=temp.resolve("auto.dat");Files.write(p,"A\r\nB\n".getBytes(StandardCharsets.US_ASCII));
        AppConfig.InputConfig c=new AppConfig.InputConfig();
        FrameResult r=new RecordFramer().frame(p,c,new AppConfig.ResourceLimits());
        assertEquals(2,r.getRecords().size());assertEquals("CRLF",r.getDetectedSeparator());
        assertTrue(r.getDiagnostics().stream().anyMatch(x->"FRAME_MIXED_SEPARATOR".equals(x.getCode())));
    }
    @Test void singleMessagePreservesCrLfAsData() throws Exception {
        Path p=temp.resolve("one.dat");byte[] bytes="A\r\nB\n".getBytes(StandardCharsets.US_ASCII);Files.write(p,bytes);
        AppConfig.InputConfig c=new AppConfig.InputConfig();c.setFraming(AppConfig.Framing.SINGLE_MESSAGE);
        FrameResult r=new RecordFramer().frame(p,c,new AppConfig.ResourceLimits());
        assertEquals(1,r.getRecords().size());assertArrayEquals(bytes,r.getRecords().get(0).getBytes());
    }
    @Test void recordLimitDoesNotAppendThePartialRecordTwice() throws Exception {
        Path p=temp.resolve("limit.dat");Files.write(p,"A\nB\nC\n".getBytes(StandardCharsets.US_ASCII));
        AppConfig.InputConfig c=new AppConfig.InputConfig();c.setLineSeparator(AppConfig.LineSeparator.LF);
        AppConfig.ResourceLimits limits=new AppConfig.ResourceLimits();limits.setMaxRecordsInMemory(1);
        FrameResult r=new RecordFramer().frame(p,c,limits);
        assertEquals(2,r.getRecords().size());
        assertTrue(r.getDiagnostics().stream().anyMatch(x->"FRAME_RECORD_COUNT_LIMIT".equals(x.getCode())));
    }
}
