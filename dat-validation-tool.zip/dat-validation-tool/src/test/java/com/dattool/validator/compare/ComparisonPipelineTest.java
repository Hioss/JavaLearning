package com.dattool.validator.compare;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.config.AppConfigLoader;
import com.dattool.validator.input.InputProcessor;
import com.dattool.validator.input.InputSideResult;
import com.dattool.validator.model.ComparisonResult;
import com.dattool.validator.spec.CompiledLayout;
import com.dattool.validator.spec.LayoutSelector;
import com.dattool.validator.spec.SpecAnalysisResult;
import com.dattool.validator.spec.WorkbookSpecAnalyzer;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class ComparisonPipelineTest {
    @Test void realWorkbookAndShiftJisSamplesFlowThroughProductionPipeline() throws Exception {
        Path root=Path.of("").toAbsolutePath();Path sample=root.resolve("examples/synthetic");
        AppConfig config=AppConfigLoader.load(sample.resolve("config.synthetic.json"));
        SpecAnalysisResult analysis=new WorkbookSpecAnalyzer().analyze(sample.resolve("specification/synthetic-normal.xlsx"),config);
        assertFalse(analysis.hasErrors());CompiledLayout layout=LayoutSelector.select(analysis.getCandidates(),config.getSpecification().getMessageId(),config.getSpecification().getBsCode(),config.getSpecification().getVariant(),config.getSpecification().getSheet());
        InputProcessor processor=new InputProcessor();InputSideResult current=processor.process(sample.resolve("messages/current.dat"),config.getCurrentInput(),config.getBah(),layout,config.getLimits());
        InputSideResult equal=processor.process(sample.resolve("messages/new-equal-reordered.dat"),config.getNewInput(),config.getBah(),layout,config.getLimits());
        ComparisonRunResult equalRun=new ComparisonEngine().compare(current,equal,config.getBah().getMode());
        assertEquals(2,equalRun.getSummary().getEqualPairs());assertEquals(ComparisonResult.Equality.EQUAL,equalRun.getResult().getEquality());
        InputSideResult changed=processor.process(sample.resolve("messages/new.dat"),config.getNewInput(),config.getBah(),layout,config.getLimits());
        ComparisonRunResult changedRun=new ComparisonEngine().compare(current,changed,config.getBah().getMode());
        assertEquals(1,changedRun.getSummary().getDifferentPairs());assertEquals(ComparisonResult.Equality.DIFFERENT,changedRun.getResult().getEquality());
    }
}
