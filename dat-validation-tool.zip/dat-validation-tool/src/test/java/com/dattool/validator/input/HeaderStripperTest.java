package com.dattool.validator.input;

import com.dattool.validator.config.AppConfig;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HeaderStripperTest {
    @Test void fixedLengthZeroEightAndOutOfRange() {
        HeaderStripper s=new HeaderStripper();FramedRecord r=record("12345678BAH");
        assertArrayEquals(r.getBytes(),s.strip(r,config(fixed(0))).getRemainingBytes());
        StripResult eight=s.strip(r,config(fixed(8)));assertEquals(8,eight.getRemovedBytes());assertArrayEquals("BAH".getBytes(StandardCharsets.US_ASCII),eight.getRemainingBytes());
        assertFalse(s.strip(r,config(fixed(99))).isSuccess());
    }
    @Test void prefixAndBoundedUniqueMarkerDoNotDeleteBodyOccurrences() {
        HeaderStripper s=new HeaderStripper();
        AppConfig.StripStep prefix=new AppConfig.StripStep();prefix.setType(AppConfig.StripType.PREFIX);prefix.setLiteral("HEAD");
        assertArrayEquals("BAHXHEAD".getBytes(StandardCharsets.US_ASCII),s.strip(record("HEADBAHXHEAD"),config(prefix)).getRemainingBytes());
        AppConfig.StripStep marker=marker("BAH",8,false);
        StripResult kept=s.strip(record("xxBAHbodyBAH"),config(marker));assertEquals(2,kept.getRemovedBytes());assertArrayEquals("BAHbodyBAH".getBytes(StandardCharsets.US_ASCII),kept.getRemainingBytes());
        marker.setIncludeMarker(true);assertArrayEquals("bodyBAH".getBytes(StandardCharsets.US_ASCII),s.strip(record("xxBAHbodyBAH"),config(marker)).getRemainingBytes());
        assertFalse(s.strip(record("BAHxxBAHbody"),config(marker("BAH",8,false))).isSuccess());
        assertFalse(s.strip(record("xxxxbody"),config(marker("BAH",4,false))).isSuccess());
    }
    @Test void secondStepFailureKeepsCumulativeOriginalCoordinate() {
        AppConfig.StripStep prefix=new AppConfig.StripStep();prefix.setType(AppConfig.StripType.PREFIX);prefix.setHex("4142");
        AppConfig.StripStep missing=new AppConfig.StripStep();missing.setType(AppConfig.StripType.PREFIX);missing.setLiteral("ZZ");
        StripResult r=new HeaderStripper().strip(record("ABCD"),config(prefix,missing));
        assertFalse(r.isSuccess());assertEquals(2,r.getRemovedBytes());assertEquals(1,r.getTraces().size());assertEquals(2,r.getTraces().get(0).getOriginalEndExclusive());
    }
    @Test void rejectsMalformedPatternConfigurationWithActionableDiagnostic() {
        AppConfig.StripStep odd=new AppConfig.StripStep();odd.setType(AppConfig.StripType.PREFIX);odd.setHex("ABC");
        StripResult result=new HeaderStripper().strip(record("ABC"),config(odd));
        assertFalse(result.isSuccess());assertEquals("STRIP_PATTERN",result.getDiagnostic().getCode());
    }
    private FramedRecord record(String s){return new FramedRecord(1,100,s.getBytes(StandardCharsets.US_ASCII));}
    private AppConfig.InputConfig config(AppConfig.StripStep...steps){AppConfig.InputConfig c=new AppConfig.InputConfig();c.setStripSteps(List.of(steps));return c;}
    private AppConfig.StripStep fixed(int n){AppConfig.StripStep x=new AppConfig.StripStep();x.setType(AppConfig.StripType.FIXED_LENGTH);x.setLength(n);return x;}
    private AppConfig.StripStep marker(String text,int window,boolean include){AppConfig.StripStep x=new AppConfig.StripStep();x.setType(AppConfig.StripType.MARKER);x.setLiteral(text);x.setSearchWindow(window);x.setIncludeMarker(include);return x;}
}
