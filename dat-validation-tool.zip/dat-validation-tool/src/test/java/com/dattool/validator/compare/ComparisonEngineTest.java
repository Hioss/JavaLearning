package com.dattool.validator.compare;

import com.dattool.validator.config.AppConfig;
import com.dattool.validator.input.ByteFieldValue;
import com.dattool.validator.input.DecodedBytes;
import com.dattool.validator.input.InputSideResult;
import com.dattool.validator.input.InputStatistics;
import com.dattool.validator.input.MessageKey;
import com.dattool.validator.input.ParsedRecord;
import com.dattool.validator.model.ComparisonResult;
import com.dattool.validator.model.Diagnostic;
import com.dattool.validator.util.ByteText;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ComparisonEngineTest {
    @Test void inputOrderDoesNotAffectFullBusinessKeyPairing() {
        ParsedRecord a=record("c",1,key("00001","99-00000001-00001"),'H',"001".getBytes(),true);
        ParsedRecord b=record("c",2,key("00002","99-00000001-00002"),'H',"ABC".getBytes(),true);
        ComparisonRunResult r=compare(List.of(a,b),List.of(copy("n",b,1),copy("n",a,2)));
        assertEquals(ComparisonResult.Equality.EQUAL,r.getResult().getEquality());assertEquals(2,r.getSummary().getEqualPairs());
        assertEquals("00001",r.getRecords().get(0).getKey().getDocumentId());
    }
    @Test void detectsBodyBahAndUnmappedReservedDifferencesStrictly() {
        MessageKey k=key("00001","99-00000001-00001");
        RecordComparison body=compare(List.of(record("c",1,k,'H',"001".getBytes(),true)),List.of(record("n",1,k,'H',"1  ".getBytes(),true))).getRecords().get(0);
        assertEquals(PairStatus.PAIRED_DIFFERENT,body.getStatus());assertTrue(body.getFields().stream().anyMatch(f->!f.isEqual()&&"BODY".equals(f.getRole())));
        RecordComparison bah=compare(List.of(record("c",1,k,'H',"ABC".getBytes(),true)),List.of(record("n",1,k,'X',"ABC".getBytes(),true))).getRecords().get(0);
        assertTrue(bah.getFields().stream().anyMatch(f->!f.isEqual()&&"BAH".equals(f.getRole())));
        RecordComparison raw=compare(List.of(record("c",1,k,'H',new byte[]{'A',' '},false)),List.of(record("n",1,k,'H',new byte[]{'A','X'},false))).getRecords().get(0);
        assertTrue(raw.getFields().stream().anyMatch(f->f.getInstanceId().startsWith("RAW:UNMAPPED")));
    }
    @Test void duplicateCopiesAreNotLostAndOneResidualPairIsDeterministic() {
        MessageKey k=key("00001","99-00000001-00001");ParsedRecord a=record("c",1,k,'H',"AAA".getBytes(),true);
        ComparisonRunResult extra=compare(List.of(a,copy("c",a,2)),List.of(copy("n",a,3)));
        assertEquals(1,extra.getSummary().getEqualPairs());assertEquals(1,extra.getSummary().getCurrentOnly());assertEquals(2,extra.getRecords().size());
        ComparisonRunResult residual=compare(List.of(a,record("c",2,k,'H',"BBB".getBytes(),true)),List.of(copy("n",a,4),record("n",5,k,'H',"CCC".getBytes(),true)));
        assertEquals(1,residual.getSummary().getEqualPairs());assertEquals(1,residual.getSummary().getDifferentPairs());assertFalse(residual.getResult().isAmbiguous());
    }
    @Test void multipleUnequalDuplicateCandidatesAreExplicitlyAmbiguous() {
        MessageKey k=key("00001","99-00000001-00001");
        ComparisonRunResult r=compare(List.of(record("c",1,k,'H',"AAA".getBytes(),true),record("c",2,k,'H',"BBB".getBytes(),true)),List.of(record("n",1,k,'H',"CCC".getBytes(),true),record("n",2,k,'H',"DDD".getBytes(),true)));
        assertTrue(r.getResult().isAmbiguous());assertEquals(ComparisonResult.Completeness.INCOMPLETE,r.getResult().getCompleteness());assertEquals(ComparisonResult.Equality.UNKNOWN,r.getResult().getEquality());
        assertEquals(2,r.getRecords().get(0).getCurrentCandidates().size());assertTrue(r.getDiagnostics().stream().anyMatch(d->"AMBIGUOUS_KEY".equals(d.getCode())));
    }
    @Test void structuralErrorCannotBeHiddenByEqualBytesAndNoDataIsDistinct() {
        MessageKey k=key("00001","99-00000001-00001");ParsedRecord a=record("c",1,k,'H',"AAA".getBytes(),true);
        Diagnostic error=Diagnostic.error("BROKEN","INPUT","broken","fix it");
        ComparisonRunResult invalid=new ComparisonEngine().compare(side(List.of(a),List.of(error)),side(List.of(copy("n",a,1)),List.of()),AppConfig.BahMode.BAH_RAW);
        assertEquals(ComparisonResult.Validity.INVALID,invalid.getResult().getValidity());assertEquals(ComparisonResult.Equality.UNKNOWN,invalid.getResult().getEquality());
        ComparisonRunResult empty=compare(List.of(),List.of());assertFalse(empty.getResult().isDataPresent());assertEquals(ComparisonResult.Equality.UNKNOWN,empty.getResult().getEquality());assertTrue(empty.getDiagnostics().stream().anyMatch(d->"NO_DATA".equals(d.getCode())));
    }
    private ComparisonRunResult compare(List<ParsedRecord> left,List<ParsedRecord> right){return new ComparisonEngine().compare(side(left,List.of()),side(right,List.of()),AppConfig.BahMode.BAH_RAW);}
    private InputSideResult side(List<ParsedRecord> records,List<Diagnostic> diagnostics){return new InputSideResult(new InputStatistics(),new ArrayList<>(records),new ArrayList<>(diagnostics),"NONE");}
    private MessageKey key(String doc,String bs){return new MessageKey("synt.001.001.01",bs,doc);}
    private ParsedRecord record(String file,long line,MessageKey key,char bah,byte[] body,boolean coverAll){
        byte[] processed=new byte[1+body.length];processed[0]=(byte)bah;System.arraycopy(body,0,processed,1,body.length);List<ByteFieldValue> fields=new ArrayList<>();
        fields.add(value("bah","BAH",0,new byte[]{(byte)bah}));fields.add(value("body","BODY",1,coverAll?body:new byte[]{body[0]}));
        return new ParsedRecord(Path.of(file+".dat"),line,line*100,processed.length,0,key,processed,processed,new byte[]{(byte)bah},body,fields,List.of());
    }
    private ByteFieldValue value(String id,String role,int offset,byte[] bytes){DecodedBytes decoded=ByteText.decode(bytes,"Shift_JIS");return new ByteFieldValue(id,role,id,offset+1,bytes.length,offset,offset,bytes,decoded);}
    private ParsedRecord copy(String file,ParsedRecord source,long line){return new ParsedRecord(Path.of(file+".dat"),line,line*100,source.getOriginalLength(),source.getRemovedBytes(),source.getKey(),source.getOriginalBytes(),source.getProcessedBytes(),source.getBahBytes(),source.getBodyBytes(),source.getFields(),source.getStripTraces());}
}
