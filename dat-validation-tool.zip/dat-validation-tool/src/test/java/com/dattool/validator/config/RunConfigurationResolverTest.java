package com.dattool.validator.config;

import com.dattool.validator.cli.CliArguments;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RunConfigurationResolverTest {
    @TempDir Path temp;

    @Test void configPathsUseConfigDirectoryAndCliPathsUseWorkingDirectory() throws Exception {
        Path configDir = Files.createDirectory(temp.resolve("configuration"));
        Path cwd = Files.createDirectory(temp.resolve("working"));
        AppConfig c = new AppConfig();
        c.getPaths().setSpecification("from-config/spec.xlsx");
        c.getPaths().setCurrent("from-config/current.dat");
        c.getSpecification().setMessageId("old");
        Path config = configDir.resolve("settings.json");
        AppConfigLoader.save(c, config);
        CliArguments cli = CliArguments.parse(new String[]{"--config", config.toString(), "--current", "from-cli/current.dat", "--message-id", "new"});
        ResolvedRunConfiguration run = RunConfigurationResolver.resolve(cli, cwd);
        assertEquals(configDir.resolve("from-config/spec.xlsx").toAbsolutePath().normalize(), run.getSpecification());
        assertEquals(cwd.resolve("from-cli/current.dat").toAbsolutePath().normalize(), run.getCurrent());
        assertEquals("new", run.getConfig().getSpecification().getMessageId());
    }
}
