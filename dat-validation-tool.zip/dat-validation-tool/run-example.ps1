# 公開合成データで実際の差分レポートを生成します（期待終了コード 1）。
$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $projectRoot
if (-not (Test-Path -LiteralPath "$projectRoot\target\dat-validation-tool.jar")) {
    & "$projectRoot\build.ps1"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
& java -jar "$projectRoot\target\dat-validation-tool.jar" --config "$projectRoot\examples\synthetic\config.synthetic.json" --overwrite
$code = $LASTEXITCODE
if ($code -ne 0 -and $code -ne 1) { throw "Example failed with exit code $code" }
Write-Host "Synthetic comparison completed (expected difference). Report: $projectRoot\examples\synthetic\results\comparison.xlsx"
exit 0
