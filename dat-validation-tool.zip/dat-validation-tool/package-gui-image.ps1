$ErrorActionPreference = "Stop"
$projectRoot = [System.IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$distRoot = [System.IO.Path]::GetFullPath((Join-Path $projectRoot "dist-image"))
$appImage = [System.IO.Path]::GetFullPath((Join-Path $distRoot "dat-validation-tool"))
$targetRoot = [System.IO.Path]::GetFullPath((Join-Path $projectRoot "target"))
$inputDir = [System.IO.Path]::GetFullPath((Join-Path $projectRoot "target\jpackage-input"))
if (-not $appImage.StartsWith($distRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Unsafe app-image path: $appImage" }
if (-not $inputDir.StartsWith($targetRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Unsafe jpackage input path: $inputDir" }
Set-Location -LiteralPath $projectRoot
& "$projectRoot\build.ps1"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (Test-Path -LiteralPath $inputDir) { Remove-Item -LiteralPath $inputDir -Recurse -Force }
New-Item -ItemType Directory -Path $inputDir | Out-Null
Copy-Item -LiteralPath "$projectRoot\target\dat-validation-tool.jar" -Destination "$inputDir\dat-validation-tool.jar"
if (Test-Path -LiteralPath $appImage) { Remove-Item -LiteralPath $appImage -Recurse -Force }
New-Item -ItemType Directory -Path $distRoot -Force | Out-Null
& jpackage --type app-image --name dat-validation-tool --dest $distRoot --input $inputDir --main-jar dat-validation-tool.jar --main-class com.dattool.validator.gui.DatValidationGui --description "STPCOM DAT fixed-length comparison tool" --vendor "DAT Tool"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "GUI app-image: $appImage"
