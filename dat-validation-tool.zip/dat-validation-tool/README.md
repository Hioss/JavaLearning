# DAT 固定長電文比較ツール

JASDECGW と STPCOM シミュレーターの固定長 DAT 電文を、選択した STPCOM 仕様書に基づいて比較するオフラインツールです。Swing デスクトップ画面と CLI は同じ比較サービスを使用します。Web 版、会社 MQ 接続、外部送信はありません。

## すぐに使う

Windows 配布版は `dist-image\dat-validation-tool\dat-validation-tool.exe` を起動します。

1. `STPCOM 仕様書`、`現比較ファイル`、`新比較ファイル`、`出力結果`を選びます。
2. 必要なら共用 JSON で sheet／電文タイプ、ヘッダー除去、BAH、文字セットを指定します。
3. `仕様分析`と`電文プレビュー`で byte 位置と 3 キーを確認します。
4. `比較開始`を押し、終了後に Excel または結果フォルダーを開きます。

複雑な設定は画面の「高度設定・mapping・BAH (JSON)」で編集できます。保存した JSON は CLI でもそのまま利用できます。操作確認の詳細は [GUI チェックリスト](docs/GUI-ACCEPTANCE-CHECKLIST.ja.md)を参照してください。

## CLI

```powershell
java -jar target\dat-validation-tool.jar --config examples\synthetic\config.synthetic.json --overwrite

java -jar target\dat-validation-tool.jar `
  --config examples\synthetic\config.synthetic.json `
  --spec examples\synthetic\specification\synthetic-normal.xlsx `
  --current examples\synthetic\messages\current.dat `
  --new examples\synthetic\messages\new.dat `
  --output examples\synthetic\results\comparison.xlsx `
  --overwrite

java -jar target\dat-validation-tool.jar `
  --spec examples\synthetic\specification\synthetic-repeat.xlsx `
  --analyze-spec
```

`--help` は日文ヘルプ、`--validate-config` は設定だけ、`--analyze-spec` は電文なしで仕様だけを検証します。相対パスは JSON 内では JSON の所在ディレクトリ、CLI 引数では実行時ディレクトリを基準にします。

終了コードは次のとおりです。

| code | 意味 |
| ---: | --- |
| 0 | 比較一致、または分析／設定検証成功 |
| 1 | 比較完了・差分あり |
| 2 | 引数、設定、入力／出力の事前検証エラー |
| 4 | NO_DATA、構造不正、不完全、曖昧など比較不能 |
| 9 | 実行中の I/O、報告公開、予期しない内部エラー |

## 入力と比較規則

- フィールド位置は 1 起の byte、`fileOffset` は CRLF／LF を含む原ファイル基準の 0 起 byte です。
- 既定文字セットは厳格な `Shift_JIS` です。`windows-31j` は JSON または CLI で明示した場合だけ使い、自動フォールバックしません。
- LINE は CRLF／LF／AUTO を byte 単位で分割し、SINGLE_MESSAGE は CR/LF も本文として保持します。
- FIXED_LENGTH／PREFIX／MARKER のヘッダー除去は左右で独立し、記述順に適用されます。
- BAH の境界と message ID＋完全 BSCode＋document ID の 3 キーは明示設定します。96 byte BAH と 8 byte 前置ヘッダーは合成例専用であり、本番既定ではありません。
- 比較は原始 byte の厳格一致です。先頭ゼロ、末尾空白、大小文字、全半角、数値表記を勝手に同値化しません。
- 重複キーは同一 byte の副本を先に相殺し、残りが左右 1 件なら比較します。複数候補が残る場合は `AMBIGUOUS_KEY` とし、任意にペアリングしません。

## 出力

結果 `.xlsx` には実行概要、展開項目定義、現／新／判定の三行対照、差異明細、単側／曖昧、診断、実行設定を収録します。Excel の行／列／セル制限を超える結果は分割し、完全値は附属ファイルへ保存します。

同時に `*-assets-<runId>` ディレクトリへ UTF-8 `manifest.json`、`current.bin`／`new.bin`、各 CSV index、必要に応じて `values/*.bin` を出力します。index の `start` と `length` から、改行を含む削除後レコードを無損失で復元できます。詳しくは [比較レポートの読み方](docs/REPORT-GUIDE.ja.md)を参照してください。

## ビルドと配布

```powershell
.\build.ps1
.\run-example.ps1
.\run-gui.ps1
.\package-gui-image.ps1
```

各スクリプトは自身のディレクトリを基準にするため、任意の作業ディレクトリから実行できます。Maven ビルドは Java 11 bytecode を生成します。`package-gui-image.ps1` は JDK 17 の `jpackage` で Windows app-image と専用 runtime を作成します。

## 資料と合成データ

- [機能設計（Markdown）](docs/FUNCTIONAL-DESIGN.ja.md)
- `README.xlsx` と `機能設計書.xlsx`
- [中国語コードレビュー資料](review.txt)
- [SYNTHETIC サンプル説明](examples/synthetic/README.md)
- [開発・受入進捗](docs/development/PROGRESS.md)
- [交付物一覧と SHA-256](docs/DELIVERABLES.ja.md)

会社内部の仕様書や電文をアップロードする必要はありません。`examples/synthetic/` はすべて公開試験用の合成定義です。MAI／MAJ／OPJ の業務必須判定、数値同値化、日付置換、ignore フィールドは、正式ルールがないため実装していません。
