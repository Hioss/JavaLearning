# DAT 项目：Codex 短指令入口

项目根目录：`D:\CX\_dat\_tool\dat-validation-tool`。本项目开发 Swing 桌面界面版和 CLI，用 STPCOM 规格比较现／新两个 DAT 电文文件，不开发 Web 版。完整需求和实现约束在 `docs/development/`。

## 识别用户的开始指令

用户实际发出 `开始 文件名.md`，即表示执行该文件定义的开发任务，包含实现、测试、修复、验收和进度记录。不要只解释文件、重新询问是否开发或要求用户复述需求。

用户在讨论、引用示例或要求修改提示词时，即使消息包含“开始 文件名.md”，也不因此启动程序开发。读取本文件或某份提示词本身同样不构成启动授权。

文件名按下表定位，用户不需要输入目录；也接受指向同一文件的相对或绝对路径。

| 用户交互词 | 文件位置 | 执行范围 |
| --- | --- | --- |
| 开始 00-MASTER.md | `docs/development/00-MASTER.md` | 从首个未完成阶段起，依次完成 Phase 01～07 |
| 开始 phase-01-foundation.md | `docs/development/phase-01-foundation.md` | 只执行 Phase 01 |
| 开始 phase-02-specification.md | `docs/development/phase-02-specification.md` | 只执行 Phase 02 |
| 开始 phase-03-message-input.md | `docs/development/phase-03-message-input.md` | 只执行 Phase 03 |
| 开始 phase-04-comparison.md | `docs/development/phase-04-comparison.md` | 只执行 Phase 04 |
| 开始 phase-05-report-cli.md | `docs/development/phase-05-report-cli.md` | 只执行 Phase 05 |
| 开始 phase-06-desktop-gui.md | `docs/development/phase-06-desktop-gui.md` | 只执行 Phase 06 |
| 开始 phase-07-release.md | `docs/development/phase-07-release.md` | 只执行 Phase 07 |

## 每次执行必须做的事

先读取 `docs/development/00-MASTER.md`、`REQUIREMENTS.md`、`ACCEPTANCE.md`、`PROGRESS.md` 和选定阶段文件；这里四个公共文件均位于 `docs/development/`。核对实际源码、产物和验收证据后再继续。不能依赖原聊天记录，需求已经写在这些文件中。

读取总控文件作为共同规则，不会把单阶段请求扩张成全部阶段。执行范围以用户实际指定的入口为准。

重复收到同一阶段的开始指令时，从现有成果继续；已完成则核对证据并报告状态，不删除重建、不无理由重做。中途停止或发生上下文压缩后，根据进度与实际代码恢复。

前置阶段整体未完成时，不跳过门槛，也不擅自执行未请求的阶段；指出最早需要完成的阶段并给出对应的一句开始指令。已经完成阶段中的局部缺陷可以在当前阶段修复并补充回归。

一个阶段完成后，更新 `PROGRESS.md`，简明报告交付物、验收结果和下一句开始指令。只有用户启动总控时，才在每阶段通过验收后自动继续下一阶段，不重复请求继续许可。

公司内部文件不能上传。使用显式本地配置、公开资料和合成样本完成实现，不以索取公司文件作为继续开发的前置条件。已确定的 Swing、Java 11、Shift-JIS、BAH 保留等要求不再重复确认。

## 工作边界

原始规格和电文只读；参考项目 `D:\CX_xml_tool\xml-validation-tool` 只读。保留现有文件与用户修改。用户的开始指令授权相应范围内的开发和验收，不授权推送仓库、外部发布、部署 Web 或连接公司 MQ。

遵守当前环境的权限要求。遇到真实权限或环境阻塞时，记录具体问题和已完成成果，不能跳过验收或伪称完成。
