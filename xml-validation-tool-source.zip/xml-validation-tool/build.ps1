$ErrorActionPreference = "Stop"
mvn clean test package
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Build succeeded: target/xml-validation-tool.jar"
