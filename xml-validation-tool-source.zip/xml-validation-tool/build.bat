@echo off
chcp 65001 >nul
mvn clean test package
if errorlevel 1 (
  echo Build failed.
  exit /b 1
)
echo Build succeeded: target\xml-validation-tool.jar
