$ErrorActionPreference = "Stop"
java -jar target/xml-validation-tool.jar `
  --current examples/current.xml `
  --new examples/new.xml `
  --xsd examples/order.xsd `
  --config examples/compare.properties `
  --json output/comparison-result.json `
  --csv output/comparison-result.csv
$code = $LASTEXITCODE
Write-Host "Exit code: $code"
exit $code
