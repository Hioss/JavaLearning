package com.hioss.xmltool;

import com.hioss.xmltool.compare.XmlMessageComparator;
import com.hioss.xmltool.config.CompareConfig;
import com.hioss.xmltool.model.ComparisonReport;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class XmlMessageComparatorTest {
    @Test
    void sameXmlShouldReturnSame() {
        XmlMessageComparator comparator = new XmlMessageComparator(new CompareConfig(), null);
        ComparisonReport report = comparator.compare(
                Path.of("src/test/resources/same-a.xml"),
                Path.of("src/test/resources/same-b.xml"));
        assertEquals("SAME", report.getResult());
        assertEquals(0, report.getDifferenceCount());
    }

    @Test
    void changedValueShouldReturnDifferenceAndXpath() {
        XmlMessageComparator comparator = new XmlMessageComparator(new CompareConfig(), null);
        ComparisonReport report = comparator.compare(
                Path.of("src/test/resources/diff-a.xml"),
                Path.of("src/test/resources/diff-b.xml"));
        assertEquals("DIFFERENT", report.getResult());
        assertTrue(report.getDifferenceCount() > 0);
        assertNotNull(report.getDifferences().get(0).getCurrentXPath());
    }
}
