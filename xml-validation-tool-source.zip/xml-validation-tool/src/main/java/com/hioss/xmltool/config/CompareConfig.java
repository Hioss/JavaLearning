package com.hioss.xmltool.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class CompareConfig {
    private boolean ignoreWhitespace = true;
    private boolean ignoreComments = true;
    private boolean normalizeWhitespace = false;
    private boolean trimText = true;
    private boolean checkForIdentical = false;
    private List<String> ignoreXpaths = new ArrayList<>();

    public static CompareConfig from(Properties p) {
        CompareConfig c = new CompareConfig();
        c.ignoreWhitespace = bool(p, "ignoreWhitespace", true);
        c.ignoreComments = bool(p, "ignoreComments", true);
        c.normalizeWhitespace = bool(p, "normalizeWhitespace", false);
        c.trimText = bool(p, "trimText", true);
        c.checkForIdentical = bool(p, "checkForIdentical", false);
        String ignores = p.getProperty("ignoreXpaths", "").trim();
        if (!ignores.isEmpty()) {
            for (String s : ignores.split(";")) {
                if (!s.trim().isEmpty()) c.ignoreXpaths.add(s.trim());
            }
        }
        return c;
    }

    private static boolean bool(Properties p, String key, boolean def) {
        return Boolean.parseBoolean(p.getProperty(key, String.valueOf(def)));
    }

    public boolean isIgnoreWhitespace() { return ignoreWhitespace; }
    public boolean isIgnoreComments() { return ignoreComments; }
    public boolean isNormalizeWhitespace() { return normalizeWhitespace; }
    public boolean isTrimText() { return trimText; }
    public boolean isCheckForIdentical() { return checkForIdentical; }
    public List<String> getIgnoreXpaths() { return ignoreXpaths; }
}
