package com.hioss.xmltool.cli;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Arguments {
    private final Map<String, String> values = new HashMap<>();
    private boolean help;

    public static Arguments parse(String[] args) {
        Arguments a = new Arguments();
        for (int i = 0; i < args.length; i++) {
            String token = args[i];
            if ("--help".equals(token) || "-h".equals(token)) { a.help = true; continue; }
            if (!token.startsWith("--")) throw new IllegalArgumentException("未知参数: " + token);
            if (i + 1 >= args.length) throw new IllegalArgumentException("参数缺少值: " + token);
            a.values.put(token.substring(2), args[++i]);
        }
        return a;
    }

    public boolean isHelp() { return help; }
    public Path requiredPath(String name) {
        String v = values.get(name);
        if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException("缺少必需参数 --" + name);
        return Paths.get(v);
    }
    public Path optionalPath(String name) {
        String v = values.get(name);
        return v == null || v.trim().isEmpty() ? null : Paths.get(v);
    }
}
