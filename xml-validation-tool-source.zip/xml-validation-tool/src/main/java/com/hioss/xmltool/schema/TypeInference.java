package com.hioss.xmltool.schema;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;

public final class TypeInference {
    private TypeInference() {}

    public static String infer(String value) {
        if (value == null) return null;
        String v = value.trim();
        if (v.isEmpty()) return "string";
        if ("true".equalsIgnoreCase(v) || "false".equalsIgnoreCase(v)) return "boolean";
        try { Integer.parseInt(v); return "integer"; } catch (NumberFormatException ignored) {}
        try { new BigDecimal(v); return "decimal"; } catch (NumberFormatException ignored) {}
        try { LocalDate.parse(v); return "date"; } catch (DateTimeParseException ignored) {}
        try { OffsetDateTime.parse(v); return "dateTime"; } catch (DateTimeParseException ignored) {}
        return "string";
    }
}
