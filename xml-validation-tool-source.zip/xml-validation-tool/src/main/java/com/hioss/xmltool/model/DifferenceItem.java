package com.hioss.xmltool.model;

public class DifferenceItem {
    private String differenceType;
    private String currentXPath;
    private String newXPath;
    private String dataType;
    private String dataTypeSource;
    private String currentValue;
    private String newValue;
    private String description;

    public DifferenceItem() {}

    public DifferenceItem(String differenceType, String currentXPath, String newXPath,
                          String dataType, String dataTypeSource,
                          String currentValue, String newValue, String description) {
        this.differenceType = differenceType;
        this.currentXPath = currentXPath;
        this.newXPath = newXPath;
        this.dataType = dataType;
        this.dataTypeSource = dataTypeSource;
        this.currentValue = currentValue;
        this.newValue = newValue;
        this.description = description;
    }

    public String getDifferenceType() { return differenceType; }
    public void setDifferenceType(String differenceType) { this.differenceType = differenceType; }
    public String getCurrentXPath() { return currentXPath; }
    public void setCurrentXPath(String currentXPath) { this.currentXPath = currentXPath; }
    public String getNewXPath() { return newXPath; }
    public void setNewXPath(String newXPath) { this.newXPath = newXPath; }
    public String getDataType() { return dataType; }
    public void setDataType(String dataType) { this.dataType = dataType; }
    public String getDataTypeSource() { return dataTypeSource; }
    public void setDataTypeSource(String dataTypeSource) { this.dataTypeSource = dataTypeSource; }
    public String getCurrentValue() { return currentValue; }
    public void setCurrentValue(String currentValue) { this.currentValue = currentValue; }
    public String getNewValue() { return newValue; }
    public void setNewValue(String newValue) { this.newValue = newValue; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
