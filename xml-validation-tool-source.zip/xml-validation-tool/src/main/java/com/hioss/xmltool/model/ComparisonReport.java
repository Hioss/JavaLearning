package com.hioss.xmltool.model;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

public class ComparisonReport {
    private String result;
    private String generatedAt = OffsetDateTime.now().toString();
    private String currentFile;
    private String newFile;
    private String xsdFile;
    private int differenceCount;
    private List<String> warnings = new ArrayList<>();
    private List<DifferenceItem> differences = new ArrayList<>();

    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }
    public String getGeneratedAt() { return generatedAt; }
    public void setGeneratedAt(String generatedAt) { this.generatedAt = generatedAt; }
    public String getCurrentFile() { return currentFile; }
    public void setCurrentFile(String currentFile) { this.currentFile = currentFile; }
    public String getNewFile() { return newFile; }
    public void setNewFile(String newFile) { this.newFile = newFile; }
    public String getXsdFile() { return xsdFile; }
    public void setXsdFile(String xsdFile) { this.xsdFile = xsdFile; }
    public int getDifferenceCount() { return differenceCount; }
    public void setDifferenceCount(int differenceCount) { this.differenceCount = differenceCount; }
    public List<String> getWarnings() { return warnings; }
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
    public List<DifferenceItem> getDifferences() { return differences; }
    public void setDifferences(List<DifferenceItem> differences) { this.differences = differences; }
}
