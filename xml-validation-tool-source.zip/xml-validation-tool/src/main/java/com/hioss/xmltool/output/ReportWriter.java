package com.hioss.xmltool.output;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.hioss.xmltool.model.ComparisonReport;
import com.hioss.xmltool.model.DifferenceItem;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ReportWriter {
    private ReportWriter() {}

    public static void writeJson(ComparisonReport report, Path output) throws IOException {
        ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
        mapper.writeValue(output.toFile(), report);
    }

    public static void writeCsv(ComparisonReport report, Path output) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            w.write('\ufeff');
            w.write("差异类型,现行XPath,新版XPath,数据类型,类型来源,现行值,新版值,差异说明\n");
            for (DifferenceItem d : report.getDifferences()) {
                w.write(csv(d.getDifferenceType()) + ',' + csv(d.getCurrentXPath()) + ',' +
                        csv(d.getNewXPath()) + ',' + csv(d.getDataType()) + ',' +
                        csv(d.getDataTypeSource()) + ',' + csv(d.getCurrentValue()) + ',' +
                        csv(d.getNewValue()) + ',' + csv(d.getDescription()) + "\n");
            }
        }
    }

    private static String csv(String s) {
        if (s == null) return "";
        return '"' + s.replace("\"", "\"\"") + '"';
    }
}
