package com.hioss.xmltool;

import com.hioss.xmltool.cli.Arguments;
import com.hioss.xmltool.compare.XmlMessageComparator;
import com.hioss.xmltool.config.CompareConfig;
import com.hioss.xmltool.config.CompareConfigLoader;
import com.hioss.xmltool.model.ComparisonReport;
import com.hioss.xmltool.output.ReportWriter;
import com.hioss.xmltool.schema.XsdSupport;

import java.nio.file.Files;
import java.nio.file.Path;

public class XmlValidationApplication {
    public static void main(String[] args) {
        int code = run(args);
        if (code != 0) System.exit(code);
    }

    static int run(String[] args) {
        try {
            Arguments arguments = Arguments.parse(args);
            if (arguments.isHelp()) { printHelp(); return 0; }

            Path current = arguments.requiredPath("current");
            Path newer = arguments.requiredPath("new");
            Path xsd = arguments.optionalPath("xsd");
            Path configPath = arguments.optionalPath("config");
            Path json = arguments.optionalPath("json");
            Path csv = arguments.optionalPath("csv");

            checkReadable(current, "现行XML");
            checkReadable(newer, "新版XML");
            if (xsd != null) checkReadable(xsd, "XSD");
            if (configPath != null) checkReadable(configPath, "配置文件");
            if (json == null) json = Path.of("comparison-result.json");

            CompareConfig config = CompareConfigLoader.load(configPath);
            XsdSupport xsdSupport = xsd == null ? null : new XsdSupport(xsd);
            if (xsdSupport != null) {
                xsdSupport.validate(current);
                xsdSupport.validate(newer);
            }

            XmlMessageComparator comparator = new XmlMessageComparator(config, xsdSupport);
            ComparisonReport report = comparator.compare(current, newer);
            if (xsd != null) report.setXsdFile(xsd.toAbsolutePath().toString());

            ensureParent(json);
            ReportWriter.writeJson(report, json);
            if (csv != null) { ensureParent(csv); ReportWriter.writeCsv(report, csv); }

            System.out.println("比较结果: " + report.getResult());
            System.out.println("差异数量: " + report.getDifferenceCount());
            System.out.println("JSON报告: " + json.toAbsolutePath());
            if (csv != null) System.out.println("CSV报告: " + csv.toAbsolutePath());
            return report.getDifferenceCount() == 0 ? 0 : 1;
        } catch (IllegalArgumentException e) {
            System.err.println("参数错误: " + e.getMessage());
            printHelp();
            return 2;
        } catch (org.xml.sax.SAXException e) {
            System.err.println("XML/XSD验证错误: " + e.getMessage());
            return 4;
        } catch (Exception e) {
            System.err.println("执行失败: " + e.getMessage());
            e.printStackTrace(System.err);
            return 9;
        }
    }

    private static void checkReadable(Path p, String label) {
        if (!Files.isRegularFile(p) || !Files.isReadable(p)) {
            throw new IllegalArgumentException(label + "不存在或不可读: " + p);
        }
    }

    private static void ensureParent(Path p) throws Exception {
        Path parent = p.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
    }

    private static void printHelp() {
        System.out.println("XML报文验证工具\n" +
                "用法:\n" +
                "  java -jar xml-validation-tool.jar --current old.xml --new new.xml [选项]\n\n" +
                "必需参数:\n" +
                "  --current <文件>   现行XML文件\n" +
                "  --new <文件>       新版XML文件\n\n" +
                "可选参数:\n" +
                "  --xsd <文件>       XSD验证及数据类型解析\n" +
                "  --config <文件>    properties比较配置\n" +
                "  --json <文件>      JSON输出，默认 comparison-result.json\n" +
                "  --csv <文件>       CSV输出\n" +
                "  --help             显示帮助\n\n" +
                "退出码: 0=一致, 1=存在差异, 2=参数错误, 4=XML/XSD错误, 9=内部错误");
    }
}
