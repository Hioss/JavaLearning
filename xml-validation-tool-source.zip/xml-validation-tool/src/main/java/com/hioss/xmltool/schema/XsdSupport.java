package com.hioss.xmltool.schema;

import com.hioss.xmltool.util.SecureXml;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class XsdSupport {
    private static final String XSD_NS = XMLConstants.W3C_XML_SCHEMA_NS_URI;
    private final Path xsdPath;
    private final Map<String, String> elementTypes = new HashMap<>();

    public XsdSupport(Path xsdPath) throws Exception {
        this.xsdPath = xsdPath;
        if (xsdPath != null) loadTypes();
    }

    public void validate(Path xmlPath) throws SAXException, IOException {
        if (xsdPath == null) return;
        SchemaFactory factory = SchemaFactory.newInstance(XSD_NS);
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        Schema schema = factory.newSchema(xsdPath.toFile());
        Validator validator = schema.newValidator();
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        validator.validate(new StreamSource(xmlPath.toFile()));
    }

    public String resolveType(String xpath) {
        if (xpath == null) return null;
        String[] parts = xpath.split("/");
        for (int i = parts.length - 1; i >= 0; i--) {
            String p = parts[i];
            if (p.isEmpty() || p.startsWith("text()") || p.startsWith("@")) continue;
            String name = p.replaceFirst("\\[.*$", "");
            int colon = name.indexOf(':');
            if (colon >= 0) name = name.substring(colon + 1);
            String type = elementTypes.get(name);
            if (type != null) return type;
        }
        return null;
    }

    private void loadTypes() throws Exception {
        Document doc = SecureXml.newDocumentBuilderFactory().newDocumentBuilder().parse(xsdPath.toFile());
        NodeList elements = doc.getElementsByTagNameNS(XSD_NS, "element");
        for (int i = 0; i < elements.getLength(); i++) {
            Element e = (Element) elements.item(i);
            String name = e.getAttribute("name");
            if (name.isEmpty()) continue;
            String type = e.getAttribute("type");
            if (type.isEmpty()) type = findInlineType(e);
            if (!type.isEmpty()) elementTypes.putIfAbsent(name, type);
        }
    }

    private String findInlineType(Element e) {
        NodeList children = e.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node n = children.item(i);
            if (n.getNodeType() != Node.ELEMENT_NODE) continue;
            Element child = (Element) n;
            if (!XSD_NS.equals(child.getNamespaceURI())) continue;
            if ("simpleType".equals(child.getLocalName())) {
                NodeList restrictions = child.getElementsByTagNameNS(XSD_NS, "restriction");
                if (restrictions.getLength() > 0) {
                    String base = ((Element) restrictions.item(0)).getAttribute("base");
                    return base.isEmpty() ? "xsd:simpleType" : base;
                }
                return "xsd:simpleType";
            }
            if ("complexType".equals(child.getLocalName())) return "xsd:complexType";
        }
        return "";
    }
}
