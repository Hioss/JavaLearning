package com.hioss.xmltool.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class CompareConfigLoader {
    private CompareConfigLoader() {}

    public static CompareConfig load(Path path) throws IOException {
        if (path == null) return new CompareConfig();
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            p.load(in);
        }
        return CompareConfig.from(p);
    }
}
