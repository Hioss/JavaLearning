package com.hioss.xmltool.compare;

import com.hioss.xmltool.config.CompareConfig;
import com.hioss.xmltool.model.ComparisonReport;
import com.hioss.xmltool.model.DifferenceItem;
import com.hioss.xmltool.schema.TypeInference;
import com.hioss.xmltool.schema.XsdSupport;
import org.w3c.dom.Node;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.*;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class XmlMessageComparator {
    private final CompareConfig config;
    private final XsdSupport xsdSupport;

    public XmlMessageComparator(CompareConfig config, XsdSupport xsdSupport) {
        this.config = config;
        this.xsdSupport = xsdSupport;
    }

    public ComparisonReport compare(Path currentXml, Path newXml) {
        DiffBuilder builder = DiffBuilder.compare(currentXml.toFile()).withTest(newXml.toFile())
                .withNodeMatcher(new DefaultNodeMatcher(ElementSelectors.byName))
                .withDifferenceEvaluator(this::evaluateDifference);

        if (config.isCheckForIdentical()) builder.checkForIdentical();
        else builder.checkForSimilar();
        if (config.isIgnoreWhitespace()) builder.ignoreWhitespace();
        if (config.isNormalizeWhitespace()) builder.normalizeWhitespace();
        if (config.isIgnoreComments()) builder.ignoreComments();

        Diff diff = builder.build();
        List<DifferenceItem> items = new ArrayList<>();
        for (Difference difference : diff.getDifferences()) {
            Comparison c = difference.getComparison();
            String currentXPath = c.getControlDetails().getXPath();
            String newXPath = c.getTestDetails().getXPath();
            String currentValue = valueToString(c.getControlDetails().getValue());
            String newValue = valueToString(c.getTestDetails().getValue());
            String type = xsdSupport == null ? null : xsdSupport.resolveType(firstNonNull(currentXPath, newXPath));
            String source = type == null ? "INFERRED" : "XSD";
            if (type == null) type = TypeInference.infer(firstNonNull(currentValue, newValue));

            items.add(new DifferenceItem(
                    c.getType().name(), currentXPath, newXPath, type, source,
                    currentValue, newValue, difference.toString()));
        }

        ComparisonReport report = new ComparisonReport();
        report.setCurrentFile(currentXml.toAbsolutePath().toString());
        report.setNewFile(newXml.toAbsolutePath().toString());
        report.setResult(items.isEmpty() ? "SAME" : "DIFFERENT");
        report.setDifferences(items);
        report.setDifferenceCount(items.size());
        return report;
    }

    private ComparisonResult evaluateDifference(Comparison comparison, ComparisonResult outcome) {
        if (outcome == ComparisonResult.EQUAL) return outcome;
        String currentXPath = comparison.getControlDetails().getXPath();
        String newXPath = comparison.getTestDetails().getXPath();
        if (matchesIgnored(currentXPath) || matchesIgnored(newXPath)) return ComparisonResult.SIMILAR;

        if (config.isTrimText() && comparison.getType() == ComparisonType.TEXT_VALUE) {
            String a = valueToString(comparison.getControlDetails().getValue());
            String b = valueToString(comparison.getTestDetails().getValue());
            if (a != null && b != null && a.trim().equals(b.trim())) return ComparisonResult.SIMILAR;
        }
        return outcome;
    }

    private boolean matchesIgnored(String xpath) {
        if (xpath == null) return false;
        for (String pattern : config.getIgnoreXpaths()) {
            if (xpath.equals(pattern) || xpath.matches(pattern)) return true;
        }
        return false;
    }

    private static String valueToString(Object value) {
        if (value == null) return null;
        if (value instanceof Node) {
            Node n = (Node) value;
            return n.getNodeValue() != null ? n.getNodeValue() : n.getNodeName();
        }
        return String.valueOf(value);
    }

    private static String firstNonNull(String a, String b) { return a != null ? a : b; }
}
