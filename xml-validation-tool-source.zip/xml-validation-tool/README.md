# XML报文验证工具

基于 Java 11 和 XMLUnit 的命令行工具，用于比较现行 XML 报文与新版 XML 报文，并输出差异 XPath、数据类型、旧值、新值和差异说明。

## 环境

- JDK 11 或更高版本
- Maven 3.8 或更高版本

## 编译

```bash
mvn clean test package
```

编译完成后生成：

```text
target/xml-validation-tool.jar
```

## 执行示例

Windows PowerShell：

```powershell
java -jar target/xml-validation-tool.jar `
  --current examples/current.xml `
  --new examples/new.xml `
  --xsd examples/order.xsd `
  --config examples/compare.properties `
  --json output/comparison-result.json `
  --csv output/comparison-result.csv
```

也可以直接运行：

```powershell
./run-example.ps1
```

## 参数

- `--current`：现行 XML，必需
- `--new`：新版 XML，必需
- `--xsd`：可选。进行 XSD 验证，并从 XSD 读取元素类型
- `--config`：可选。properties 格式的比较配置
- `--json`：可选。JSON 输出路径，默认 `comparison-result.json`
- `--csv`：可选。CSV 输出路径
- `--help`：显示帮助

## 配置文件

```properties
ignoreWhitespace=true
ignoreComments=true
normalizeWhitespace=false
trimText=true
checkForIdentical=false
ignoreXpaths=.*/generatedAt\[1\]/text\(\)\[1\]
```

`ignoreXpaths` 使用英文分号分隔多个 XPath/正则表达式。

## 数据类型

- 提供 XSD 时，优先使用 XSD 中元素的 `type`
- 未提供 XSD 或无法取得类型时，根据值推断 `integer`、`decimal`、`boolean`、`date`、`dateTime` 或 `string`
- 报告中的 `dataTypeSource` 为 `XSD` 或 `INFERRED`

## 安全

工具禁用 DOCTYPE、外部实体、外部 DTD 和外部 Schema 访问，以降低 XXE 风险。

## 退出码

- `0`：XML 一致
- `1`：存在差异
- `2`：参数或输入文件错误
- `4`：XML/XSD 验证错误
- `9`：程序内部错误

## 当前限制

- XSD 类型解析按元素名称匹配；如果不同层级存在同名元素且类型不同，需要扩展为完整 schema path 匹配
- 默认按元素名称和位置匹配重复节点；需要按业务主键匹配时，可扩展 `NodeMatcher`
- 大型 XML 当前使用 DOM/XMLUnit 全量载入，超大文件建议后续实现流式比较
