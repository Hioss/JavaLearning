@echo off
chcp 65001 >nul
java -jar target\xml-validation-tool.jar ^
  --current examples\current.xml ^
  --new examples\new.xml ^
  --xsd examples\order.xsd ^
  --config examples\compare.properties ^
  --json output\comparison-result.json ^
  --csv output\comparison-result.csv
set EXIT_CODE=%ERRORLEVEL%
echo Exit code: %EXIT_CODE%
pause
exit /b %EXIT_CODE%
